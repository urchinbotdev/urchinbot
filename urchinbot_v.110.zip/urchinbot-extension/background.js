/* background.js — UrchinLoop service worker */
importScripts('lib/jszip.min.js');
importScripts('lib/nacl-fast.min.js');
importScripts('lib/solana-lite.js');

/* ── Side Panel setup ── */
chrome.runtime.onInstalled.addListener(() => {
  if (chrome.sidePanel) {
    chrome.storage.local.get('sidePanelOnClick', (data) => {
      const enabled = !!data.sidePanelOnClick;
      chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: enabled }).catch(() => {});
      if (enabled) chrome.action.setPopup({ popup: '' });
    });
  }
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.sidePanelOnClick && chrome.sidePanel) {
    const enabled = !!changes.sidePanelOnClick.newValue;
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: enabled }).catch(() => {});
    chrome.action.setPopup({ popup: enabled ? '' : 'popup.html' });
  }
});

/* ── Side Panel open/close tracking via port ── */
function broadcastSidePanelState(open) {
  chrome.tabs.query({}, tabs => {
    for (const tab of tabs) {
      try { chrome.tabs.sendMessage(tab.id, { action: 'SIDE_PANEL_STATE', open }); } catch {}
    }
  });
}

chrome.runtime.onConnect.addListener(port => {
  if (port.name === 'urchin-sidepanel') {
    broadcastSidePanelState(true);
    port.onDisconnect.addListener(() => { broadcastSidePanelState(false); });
  }
});

/* ── Context budget — prevent context window overflow ── */
const MAX_CONTEXT_CHARS = 80000;
function trimMessagesToBudget(messages, budget = MAX_CONTEXT_CHARS) {
  let total = messages.reduce((s, m) => s + (m.content || '').length, 0);
  let i = 0;
  while (total > budget && i < messages.length - 2) {
    const old = messages[i].content.length;
    messages[i].content = messages[i].content.slice(0, 200) + '…[trimmed]';
    total -= old - messages[i].content.length;
    i++;
  }
  return messages;
}

/* ── Tool result summarizer — compress oversized tool outputs ── */
function summarizeToolResult(toolName, result) {
  const raw = JSON.stringify(result);
  if (raw.length <= 3000) return raw;
  if (toolName === 'FETCH_URL') return raw.slice(0, 2500) + '…[truncated]';
  if (toolName === 'GET_WALLET_BALANCE' && result.topTokens) {
    result.topTokens = result.topTokens.slice(0, 5);
    return JSON.stringify(result);
  }
  if (toolName === 'GET_WALLET_HISTORY' && result.recentTransactions) {
    result.recentTransactions = result.recentTransactions.slice(0, 5);
    return JSON.stringify(result);
  }
  if (toolName === 'REVERSE_IMAGE_SEARCH' && result.searchResults) {
    result.searchResults = result.searchResults.slice(0, 3).map(r => ({ query: r.query, results: (r.results || []).slice(0, 2) }));
    return JSON.stringify(result);
  }
  if (toolName === 'LIST_SITES' && Array.isArray(result)) {
    return JSON.stringify(result.slice(0, 15));
  }
  if (toolName === 'X_SEARCH' && result.results) {
    result.results = result.results.slice(0, 10).map(t => ({ ...t, text: (t.text || '').slice(0, 200) }));
    return JSON.stringify(result);
  }
  if (toolName === 'X_USER_TWEETS' && result.tweets) {
    result.tweets = result.tweets.slice(0, 10).map(t => ({ ...t, text: (t.text || '').slice(0, 200) }));
    return JSON.stringify(result);
  }
  return raw.slice(0, 2500) + '…[truncated]';
}

/* ── Context Menus ── */
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: 'urchin-selection', title: 'Send selection to urchinbot (Ask)', contexts: ['selection'] });
  chrome.contextMenus.create({ id: 'urchin-link',      title: 'Send link to urchinbot (Ask)',      contexts: ['link'] });
  chrome.contextMenus.create({ id: 'urchin-image',     title: 'Send image to urchinbot (Build/Deploy)', contexts: ['image'] });
  chrome.contextMenus.create({ id: 'urchin-page',      title: 'Capture current page',              contexts: ['page'] });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  let payload = {};
  switch (info.menuItemId) {
    case 'urchin-selection': payload = { type: 'text', value: info.selectionText }; break;
    case 'urchin-link':      payload = { type: 'link', value: info.linkUrl };       break;
    case 'urchin-image':     payload = { type: 'image', value: info.srcUrl };       break;
    case 'urchin-page':      payload = { type: 'page', value: tab.url, title: tab.title }; break;
  }
  try {
    await chrome.tabs.sendMessage(tab.id, { action: 'CONTEXT_CAPTURE', payload });
  } catch (_) { /* content script may not be loaded */ }
});

/* ── Settings helper ── */
async function getSettings() {
  const defaults = {
    llmProvider: 'openai', llmApiKey: '', llmModel: 'gpt-4o-mini', llmBaseUrl: '',
    solanaRpc: '', enableSummaries: true, enableAllSites: false,
    companionMode: false,
    netlifyToken: '',
    pumpTokenName: '', pumpTokenSymbol: '', pumpUseImage: true
  };
  const stored = await chrome.storage.local.get(Object.keys(defaults));
  return { ...defaults, ...stored };
}

/* ── LLM Caller (single message — used by Build/Deploy/Scan) ── */
async function callLLM(systemPrompt, userMessage, settings) {
  return callLLMChat(systemPrompt, [{ role: 'user', content: userMessage }], settings);
}

/* ── Vision LLM call — sends image + text to a vision-capable model ── */
async function callLLMVision(systemPrompt, textPrompt, imageDataUrl, settings) {
  const provider = settings.llmProvider || 'openai';
  const mimeMatch = imageDataUrl.match(/^data:([^;]+);/);
  const mimeType = mimeMatch ? mimeMatch[1] : 'image/png';
  const b64Data = imageDataUrl.split(',')[1];

  if (provider === 'anthropic') {
    const messages = [{
      role: 'user',
      content: [
        { type: 'image', source: { type: 'base64', media_type: mimeType, data: b64Data } },
        { type: 'text', text: textPrompt }
      ]
    }];
    return callLLMChat(systemPrompt, messages, settings);
  } else {
    const messages = [{
      role: 'user',
      content: [
        { type: 'image_url', image_url: { url: imageDataUrl } },
        { type: 'text', text: textPrompt }
      ]
    }];
    return callLLMChat(systemPrompt, messages, settings);
  }
}

/* ── Screenshot capture ── */
async function captureScreenshot() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error('No active tab');
  const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 70 });
  return dataUrl;
}

/* ── LLM Caller (conversation — used by ASK agent) ── */
async function callLLMChat(systemPrompt, messages, settings) {
  const provider = settings.llmProvider || 'openai';
  let baseUrl, headers, body;

  const model = settings.llmModel || (provider === 'anthropic' ? 'claude-sonnet-4-20250514' : 'gpt-4.1');
  const maxTok = /claude-opus-4-6/i.test(model) ? 32768
    : /claude-opus-4-5/i.test(model) ? 32768
    : /claude-3-opus/i.test(model) ? 4096
    : /claude-3-5-haiku|haiku/i.test(model) ? 8192
    : /claude/i.test(model) ? 16384
    : /o3-mini|o4-mini/i.test(model) ? 16384
    : /o3|o4/i.test(model) ? 32768
    : /gpt-4\.1-nano/i.test(model) ? 16384
    : /gpt-4\.1/i.test(model) ? 32768
    : /gpt-4o/i.test(model) ? 16384
    : 8192;

  if (provider === 'anthropic') {
    baseUrl = 'https://api.anthropic.com/v1/messages';
    headers = { 'Content-Type': 'application/json', 'x-api-key': settings.llmApiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' };
    body = JSON.stringify({
      model,
      max_tokens: maxTok,
      system: systemPrompt,
      messages
    });
  } else {
    baseUrl = (provider === 'openai_compatible' && settings.llmBaseUrl) ? settings.llmBaseUrl : 'https://api.openai.com/v1/chat/completions';
    headers = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${settings.llmApiKey}` };
    const isReasoning = /^o[0-9]/.test(model);
    const oaiBody = { model, messages: [{ role: 'system', content: systemPrompt }, ...messages] };
    if (isReasoning) { oaiBody.max_completion_tokens = maxTok; }
    else { oaiBody.temperature = 0.7; oaiBody.max_tokens = maxTok; }
    body = JSON.stringify(oaiBody);
  }

  for (let attempt = 0; attempt < 3; attempt++) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 180000);
    let res;
    try {
      res = await fetch(baseUrl, { method: 'POST', headers, body, signal: controller.signal });
    } catch (e) {
      clearTimeout(timeout);
      if (e.name === 'AbortError') throw new Error('LLM request timed out (180s). Try a simpler prompt or faster model.');
      throw e;
    }
    clearTimeout(timeout);
    if (res.status === 429 && attempt < 2) {
      const retryAfter = parseFloat(res.headers.get('retry-after')) || 0;
      const bodyText = await res.text();
      const waitMatch = bodyText.match(/try again in ([\d.]+)s/i);
      const waitSec = retryAfter || (waitMatch ? parseFloat(waitMatch[1]) : (attempt + 1) * 5);
      console.log(`[urchin] LLM 429 rate limit — retrying in ${waitSec.toFixed(1)}s (attempt ${attempt + 1}/3)`);
      await new Promise(r => setTimeout(r, waitSec * 1000));
      continue;
    }
    if (!res.ok) throw new Error(`LLM API ${res.status}: ${(await res.text()).slice(0, 300)}`);
    const data = await res.json();
    if (provider === 'anthropic') return data.content?.[0]?.text || '';
    return data.choices?.[0]?.message?.content || '';
  }
}

/* ── Streaming LLM call — sends chunks to content.js in real-time ── */
async function callLLMChatStream(systemPrompt, messages, settings, onChunk) {
  const provider = settings.llmProvider || 'openai';
  const model = settings.llmModel || (provider === 'anthropic' ? 'claude-sonnet-4-20250514' : 'gpt-4.1');
  const maxTok = /claude-opus-4-6/i.test(model) ? 32768
    : /claude-opus-4-5/i.test(model) ? 32768
    : /claude-3-opus/i.test(model) ? 4096
    : /claude-3-5-haiku|haiku/i.test(model) ? 8192
    : /claude/i.test(model) ? 16384
    : /o3-mini|o4-mini/i.test(model) ? 16384
    : /o3|o4/i.test(model) ? 32768
    : /gpt-4\.1-nano/i.test(model) ? 16384
    : /gpt-4\.1/i.test(model) ? 32768
    : /gpt-4o/i.test(model) ? 16384
    : 8192;

  let baseUrl, headers, body;
  if (provider === 'anthropic') {
    baseUrl = 'https://api.anthropic.com/v1/messages';
    headers = { 'Content-Type': 'application/json', 'x-api-key': settings.llmApiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' };
    body = JSON.stringify({ model, max_tokens: maxTok, system: systemPrompt, messages, stream: true });
  } else {
    baseUrl = (provider === 'openai_compatible' && settings.llmBaseUrl) ? settings.llmBaseUrl : 'https://api.openai.com/v1/chat/completions';
    headers = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${settings.llmApiKey}` };
    const isReasoning = /^o[0-9]/.test(model);
    const oaiBody = { model, messages: [{ role: 'system', content: systemPrompt }, ...messages], stream: true };
    if (isReasoning) { oaiBody.max_completion_tokens = maxTok; }
    else { oaiBody.temperature = 0.7; oaiBody.max_tokens = maxTok; }
    body = JSON.stringify(oaiBody);
  }

  let res;
  for (let attempt = 0; attempt < 3; attempt++) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 180000);
    try {
      res = await fetch(baseUrl, { method: 'POST', headers, body, signal: controller.signal });
    } catch (e) {
      clearTimeout(timeout);
      if (e.name === 'AbortError') throw new Error('LLM request timed out (180s).');
      throw e;
    }
    if (res.status === 429 && attempt < 2) {
      clearTimeout(timeout);
      const retryAfter = parseFloat(res.headers.get('retry-after')) || 0;
      const bodyText = await res.text();
      const waitMatch = bodyText.match(/try again in ([\d.]+)s/i);
      const waitSec = retryAfter || (waitMatch ? parseFloat(waitMatch[1]) : (attempt + 1) * 5);
      console.log(`[urchin] LLM stream 429 rate limit — retrying in ${waitSec.toFixed(1)}s (attempt ${attempt + 1}/3)`);
      await new Promise(r => setTimeout(r, waitSec * 1000));
      continue;
    }
    if (!res.ok) { clearTimeout(timeout); throw new Error(`LLM API ${res.status}: ${(await res.text()).slice(0, 300)}`); }
    clearTimeout(timeout);
    break;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let full = '';
  let buffer = '';
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop();
      for (const line of lines) {
        if (!line.startsWith('data: ') || line === 'data: [DONE]') continue;
        try {
          const json = JSON.parse(line.slice(6));
          let chunk = '';
          if (provider === 'anthropic') {
            if (json.type === 'content_block_delta') chunk = json.delta?.text || '';
          } else {
            chunk = json.choices?.[0]?.delta?.content || '';
          }
          if (chunk) { full += chunk; onChunk(chunk, full); }
        } catch (_) {}
      }
    }
  } finally { clearTimeout(timeout); }
  return full;
}

/* ── Broadcast live progress to content script ── */
async function broadcastProgress(data) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) chrome.tabs.sendMessage(tab.id, { action: 'URCHIN_PROGRESS', ...data });
  } catch (_) {}
}

/* ── Web Search (uses DuckDuckGo Instant Answer or Google Custom Search if configured) ── */
async function webSearch(query, settings) {
  try {
    const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`;
    const res = await fetch(url);
    const data = await res.json();
    const results = [];
    if (data.AbstractText) results.push({ title: data.Heading || query, snippet: data.AbstractText, url: data.AbstractURL });
    if (data.RelatedTopics) {
      for (const topic of data.RelatedTopics.slice(0, 5)) {
        if (topic.Text) results.push({ snippet: topic.Text, url: topic.FirstURL || '' });
        if (topic.Topics) {
          for (const sub of topic.Topics.slice(0, 2)) {
            if (sub.Text) results.push({ snippet: sub.Text, url: sub.FirstURL || '' });
          }
        }
      }
    }
    if (results.length === 0) results.push({ snippet: data.Abstract || 'No results found. Try a more specific query.', url: '' });
    return results.slice(0, 8);
  } catch (e) {
    return [{ snippet: `Search error: ${e.message}`, url: '' }];
  }
}

/* ── Token Price (uses Jupiter aggregator API for Solana tokens) ── */
async function getTokenPrice(mintOrSymbol, settings) {
  try {
    const ids = mintOrSymbol.trim();
    const res = await fetch(`https://api.jup.ag/price/v2?ids=${encodeURIComponent(ids)}`);
    if (!res.ok) throw new Error(`Jupiter API ${res.status}`);
    const data = await res.json();
    if (data.data && Object.keys(data.data).length > 0) {
      const entry = Object.values(data.data)[0];
      return {
        mint: entry.id,
        symbol: entry.mintSymbol || ids,
        price: entry.price,
        type: entry.type || 'token'
      };
    }
    return { error: 'Token not found. Make sure you use the correct mint address.' };
  } catch (e) {
    return { error: e.message };
  }
}

/* ── First-Scan Price Tracker — records the first time urchinbot sees a token ── */
async function recordFirstScan(mint, price, symbol, via) {
  if (!mint || !price) return;
  try {
    const { urchinFirstScans = {} } = await chrome.storage.local.get('urchinFirstScans');
    if (urchinFirstScans[mint]) return;
    urchinFirstScans[mint] = { price: parseFloat(price), symbol: symbol || mint.slice(0, 8), scannedAt: Date.now(), via: via || 'unknown' };
    const keys = Object.keys(urchinFirstScans);
    if (keys.length > 100) delete urchinFirstScans[keys[0]];
    await chrome.storage.local.set({ urchinFirstScans });
  } catch (_) {}
}

async function buildPnlCard(mint, settings) {
  const { urchinFirstScans = {} } = await chrome.storage.local.get('urchinFirstScans');
  const first = urchinFirstScans[mint];
  if (!first) return { error: `No scan history for ${mint.slice(0, 8)}... — scan or check the price first, then check back later for PnL.` };

  const [priceData, dexData, walletData] = await Promise.all([
    getTokenPrice(mint, settings),
    fetchDexScreenerData(mint).catch(() => null),
    (async () => {
      try {
        const { urchinMyWallet } = await chrome.storage.local.get('urchinMyWallet');
        if (!urchinMyWallet || !settings.solanaRpc) return null;
        return await getWalletBalance(urchinMyWallet, settings.solanaRpc);
      } catch (_) { return null; }
    })()
  ]);

  if (priceData.error || !priceData.price) return { error: priceData.error || 'Could not fetch current price.' };
  const currentPrice = parseFloat(priceData.price);
  const entryPrice = first.price;
  const pctChange = ((currentPrice - entryPrice) / entryPrice) * 100;
  const isGain = pctChange >= 0;
  const elapsed = Date.now() - first.scannedAt;
  const days = Math.floor(elapsed / 86400000);
  const hours = Math.floor((elapsed % 86400000) / 3600000);
  const heldFor = days > 0 ? `${days}d ${hours}h` : `${hours}h`;

  let pairAge = null, deployDate = null;
  if (Array.isArray(dexData) && dexData[0]) {
    pairAge = dexData[0].pairAge || null;
    if (dexData[0].pairAge && dexData[0].pairAge !== 'unknown') {
      const ageDays = parseInt(dexData[0].pairAge);
      if (!isNaN(ageDays)) {
        const deployTs = Date.now() - ageDays * 86400000;
        deployDate = new Date(deployTs).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
      }
    }
  }

  let holdings = null;
  if (walletData && walletData.topTokens) {
    const held = walletData.topTokens.find(t => t.mint === mint);
    if (held) {
      const tokenAmount = parseFloat(held.amount);
      const currentValue = tokenAmount * currentPrice;
      const entryValue = tokenAmount * entryPrice;
      const solPrice = await getSolPrice(settings);
      holdings = {
        tokenAmount,
        currentValueUsd: Math.round(currentValue * 100) / 100,
        entryValueUsd: Math.round(entryValue * 100) / 100,
        investedSol: solPrice > 0 ? Math.round((entryValue / solPrice) * 1000) / 1000 : null,
        currentSol: solPrice > 0 ? Math.round((currentValue / solPrice) * 1000) / 1000 : null,
        profitUsd: Math.round((currentValue - entryValue) * 100) / 100
      };
    }
  }

  return {
    success: true,
    card: {
      mint, symbol: priceData.symbol || first.symbol, entryPrice, currentPrice,
      pctChange: Math.round(pctChange * 100) / 100, isGain,
      scannedAt: new Date(first.scannedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      heldFor, via: first.via,
      pairAge: pairAge || null,
      deployDate: deployDate || null,
      holdings: holdings || null
    },
    _pnlCardRender: true
  };
}

async function getSolPrice(settings) {
  try {
    const res = await fetch('https://api.jup.ag/price/v2?ids=So11111111111111111111111111111111111111112');
    const data = await res.json();
    const entry = data.data && Object.values(data.data)[0];
    return entry ? parseFloat(entry.price) : 0;
  } catch (_) { return 0; }
}

/* ── Deployer Wallet — encrypted private key storage for on-chain ops ── */
async function setDeployerKey(privateKeyB58, pin) {
  const kp = SolanaLite.Keypair.fromSecretKey(privateKeyB58);
  const pubkey = kp.publicKey.toBase58();
  const encrypted = await SolanaLite.encryptWithPin(privateKeyB58, pin);
  await chrome.storage.local.set({ urchinDeployerKey: encrypted, urchinDeployerPub: pubkey });
  return { success: true, publicKey: pubkey, message: `Deployer wallet set: ${pubkey.slice(0, 6)}...${pubkey.slice(-4)}. Keep your PIN safe — you'll need it for every transaction.` };
}

async function getDeployerKeypair(pin) {
  const { urchinDeployerKey } = await chrome.storage.local.get('urchinDeployerKey');
  if (!urchinDeployerKey) throw new Error('No deployer wallet set. Use SET_DEPLOYER_KEY first.');
  if (!pin || typeof pin !== 'string') throw new Error('PIN must be a non-empty string.');
  let pkB58;
  try {
    pkB58 = await SolanaLite.decryptWithPin(urchinDeployerKey, String(pin));
  } catch (e) {
    if (e.name === 'OperationError' || (e instanceof DOMException)) {
      throw new Error('Wrong PIN — decryption failed. Make sure you are using the same PIN you set with SET_DEPLOYER_KEY.');
    }
    throw new Error(`Decryption error: ${e.message || e.name || e}`);
  }
  return SolanaLite.Keypair.fromSecretKey(pkB58);
}

async function getDeployerPubkey() {
  const { urchinDeployerPub } = await chrome.storage.local.get('urchinDeployerPub');
  return urchinDeployerPub || null;
}

/* ── Pump.fun API Client ── */
async function pumpGetCoinInfo(mint) {
  const res = await fetch(`https://frontend-api-v3.pump.fun/coins/${mint}`);
  if (!res.ok) {
    if (res.status === 404) return { error: `Token ${mint.slice(0, 8)}... not found on pump.fun` };
    throw new Error(`Pump.fun API ${res.status}`);
  }
  const d = await res.json();
  const virtualSol = d.virtual_sol_reserves ? Number(d.virtual_sol_reserves) / 1e9 : 0;
  const virtualTokens = d.virtual_token_reserves ? Number(d.virtual_token_reserves) / 1e6 : 0;
  const realSol = d.real_sol_reserves ? Number(d.real_sol_reserves) / 1e9 : 0;
  const realTokens = d.real_token_reserves ? Number(d.real_token_reserves) / 1e6 : 0;
  const totalSupply = d.total_supply ? Number(d.total_supply) / 1e6 : 1e9;
  const spotPrice = virtualTokens > 0 ? virtualSol / virtualTokens : 0;
  const marketCapSol = spotPrice * totalSupply;
  const initialRealTokens = 793_100_000;
  const tokensSold = initialRealTokens - realTokens;
  const graduationPct = Math.min(100, Math.max(0, (tokensSold / initialRealTokens) * 100));

  return {
    mint: d.mint, name: d.name, symbol: d.symbol,
    description: (d.description || '').slice(0, 300),
    imageUri: d.image_uri, creator: d.creator,
    createdAt: d.created_timestamp ? new Date(d.created_timestamp).toISOString() : null,
    marketCapUsd: d.usd_market_cap ? Math.round(d.usd_market_cap) : null,
    marketCapSol: Math.round(marketCapSol * 100) / 100,
    pricePerToken: spotPrice,
    isGraduated: !!d.complete || !!d.raydium_pool,
    bondingCurve: {
      virtualSolReserves: virtualSol,
      virtualTokenReserves: virtualTokens,
      realSolReserves: realSol,
      realTokenReserves: realTokens,
      graduationPct: Math.round(graduationPct * 100) / 100
    },
    replyCount: d.reply_count || 0,
    website: d.website || null, twitter: d.twitter || null, telegram: d.telegram || null,
    kingOfTheHill: d.king_of_the_hill_timestamp ? new Date(d.king_of_the_hill_timestamp).toISOString() : null
  };
}

async function pumpTrade(action, mint, amount, pin, settings) {
  if (!settings.solanaRpc) throw new Error('Solana RPC URL required. Go to Settings → paste your RPC URL (Helius, QuickNode, etc.).');
  const kp = await getDeployerKeypair(pin);
  const pubKey = kp.publicKey.toBase58();

  const bal = await SolanaLite.getBalance(pubKey, settings.solanaRpc);
  if (action === 'buy' && bal < amount + 0.01) throw new Error(`Insufficient SOL. Deployer has ${bal.toFixed(4)} SOL, need ~${(amount + 0.01).toFixed(4)} SOL.`);

  const body = {
    publicKey: pubKey,
    action,
    mint,
    amount,
    denominatedInSol: action === 'buy' ? 'true' : 'false',
    slippage: 15,
    priorityFee: 0.0005,
    pool: 'pump'
  };

  const res = await fetch('https://pumpportal.fun/api/trade-local', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Trade API error (${res.status}): ${errText.slice(0, 200)}`);
  }

  const txB64 = (await res.text()).trim();
  const signed = SolanaLite.signBase64Tx(txB64, [kp]);
  const txSig = await SolanaLite.sendRawTx(signed, settings.solanaRpc);

  return {
    success: true, action, mint, amount,
    signature: txSig,
    explorer: `https://solscan.io/tx/${txSig}`,
    pump: `https://pump.fun/coin/${mint}`
  };
}

async function resolveImageBlob(image) {
  if (!image) return null;
  if (image.startsWith('data:')) {
    const [header, b64] = image.split(',');
    const mime = header.match(/data:([^;]+)/)?.[1] || 'image/png';
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new Blob([arr], { type: mime });
  }
  const res = await fetch(image);
  if (!res.ok) throw new Error(`Failed to fetch image (${res.status})`);
  return res.blob();
}

async function uploadToCatbox(blob, filename) {
  const form = new FormData();
  form.append('reqtype', 'fileupload');
  form.append('fileToUpload', blob, filename);
  let res;
  try {
    res = await fetch('https://catbox.moe/user/api.php', { method: 'POST', body: form });
  } catch (e) {
    throw new Error(`Catbox.moe unreachable (${e.message || e}). Try providing a "uri" field with your own metadata URL.`);
  }
  if (!res.ok) throw new Error(`Catbox upload HTTP ${res.status}`);
  const url = (await res.text()).trim();
  if (!url.startsWith('http')) throw new Error(`Catbox returned invalid URL: "${url.slice(0, 100)}"`);
  return url;
}

async function fallbackMetadataUpload(params, imageBlob) {
  let imageUrl = '';
  if (imageBlob) {
    const ext = (imageBlob.type || 'image/png').split('/')[1] || 'png';
    imageUrl = await uploadToCatbox(imageBlob, `token.${ext}`);
    console.log('[urchin] Fallback image uploaded to catbox:', imageUrl);
  }
  const metadata = {
    name: params.name, symbol: params.symbol,
    description: params.description || '',
    image: imageUrl, showName: true, createdOn: 'https://pump.fun'
  };
  if (params.twitter) metadata.twitter = params.twitter;
  if (params.telegram) metadata.telegram = params.telegram;
  if (params.website) metadata.website = params.website;
  const metaBlob = new Blob([JSON.stringify(metadata)], { type: 'application/json' });
  const metaUrl = await uploadToCatbox(metaBlob, 'metadata.json');
  console.log('[urchin] Fallback metadata uploaded to catbox:', metaUrl);
  return metaUrl;
}

/* ── Direct on-chain Pump.fun deploy (pump-fun-sdk port) ── */
const PUMP_PROGRAM = new SolanaLite.PublicKey('6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P');
const MAYHEM_PROGRAM = new SolanaLite.PublicKey('MAyhSmzXzV1pTf7LsNkrNwkWKTo4ougAJ1PPg47MD4e');
const FEE_PROGRAM = new SolanaLite.PublicKey('pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ');
const COMPUTE_BUDGET = new SolanaLite.PublicKey('ComputeBudget111111111111111111111111111111');
const te = (s) => new TextEncoder().encode(s);

async function fetchPumpGlobal(globalPda, rpcUrl) {
  const info = await SolanaLite.rpc('getAccountInfo', [
    globalPda.toBase58(), { encoding: 'base64', commitment: 'confirmed' }
  ], rpcUrl);
  if (!info?.value?.data) throw new Error('Could not fetch Pump global account — check your RPC URL');
  const raw = Uint8Array.from(atob(info.value.data[0]), c => c.charCodeAt(0));
  const dv = new DataView(raw.buffer, raw.byteOffset, raw.byteLength);
  const feeRecipients = [new SolanaLite.PublicKey(raw.slice(41, 73))];
  for (let i = 0; i < 7; i++) {
    const off = 162 + i * 32;
    const pk = new SolanaLite.PublicKey(raw.slice(off, off + 32));
    if (pk.toBase58() !== '11111111111111111111111111111111') feeRecipients.push(pk);
  }
  return {
    feeRecipient: feeRecipients[Math.floor(Math.random() * feeRecipients.length)],
    initialVirtualTokenReserves: dv.getBigUint64(73, true),
    initialVirtualSolReserves: dv.getBigUint64(81, true),
    initialRealTokenReserves: dv.getBigUint64(89, true),
    tokenTotalSupply: dv.getBigUint64(97, true),
    feeBasisPoints: dv.getBigUint64(105, true),
    creatorFeeBasisPoints: dv.getBigUint64(154, true),
  };
}

async function pumpDirectDeploy(params, kp, mintKp, metadataUri, settings) {
  const { PublicKey, Keypair, findProgramAddress: fpda, getAssociatedTokenAddress: gata,
    concatBytes: cat, borshString: bStr, borshU64: bU64, buildLegacyTransaction, signSerializedTx,
    sendRawTx, getLatestBlockhash } = SolanaLite;

  const user = kp.publicKey;
  const mint = mintKp.publicKey;
  const TOKEN_2022 = PublicKey.TOKEN_2022;
  const SYSTEM = PublicKey.SYSTEM_PROGRAM;
  const ATA_PROG = PublicKey.ASSOCIATED_TOKEN;

  console.log('[urchin] Direct SDK deploy: deriving PDAs...');
  const [mintAuthority] = await fpda([te('mint-authority')], PUMP_PROGRAM);
  const [bondingCurve] = await fpda([te('bonding-curve'), mint.toBytes()], PUMP_PROGRAM);
  const assocBondingCurve = await gata(mint, bondingCurve, TOKEN_2022);
  const [global] = await fpda([te('global')], PUMP_PROGRAM);
  const [eventAuthority] = await fpda([te('__event_authority')], PUMP_PROGRAM);
  const [globalParams] = await fpda([te('global-params')], MAYHEM_PROGRAM);
  const [solVault] = await fpda([te('sol-vault')], MAYHEM_PROGRAM);
  const [mayhemState] = await fpda([te('mayhem-state'), mint.toBytes()], MAYHEM_PROGRAM);
  const mayhemTokenVault = await gata(mint, solVault, TOKEN_2022);

  const instructions = [];

  const cuLimit = 600000;
  const priorityFeeSol = params.priorityFee || 0.0005;
  const microLamportsPerCu = BigInt(Math.round(priorityFeeSol * 1e15 / cuLimit));
  const cuLimitData = new Uint8Array(5);
  cuLimitData[0] = 2;
  new DataView(cuLimitData.buffer).setUint32(1, cuLimit, true);
  instructions.push({ programId: COMPUTE_BUDGET, keys: [], data: cuLimitData });
  const cuPriceData = new Uint8Array(9);
  cuPriceData[0] = 3;
  cuPriceData.set(bU64(microLamportsPerCu), 1);
  instructions.push({ programId: COMPUTE_BUDGET, keys: [], data: cuPriceData });

  const createData = cat(
    new Uint8Array([214, 144, 76, 236, 95, 139, 49, 180]),
    bStr(params.name), bStr(params.symbol), bStr(metadataUri),
    user.toBytes(),
    new Uint8Array([0]),
    new Uint8Array([0])
  );
  instructions.push({
    programId: PUMP_PROGRAM,
    keys: [
      { pubkey: mint, isSigner: true, isWritable: true },
      { pubkey: mintAuthority, isSigner: false, isWritable: false },
      { pubkey: bondingCurve, isSigner: false, isWritable: true },
      { pubkey: assocBondingCurve, isSigner: false, isWritable: true },
      { pubkey: global, isSigner: false, isWritable: false },
      { pubkey: user, isSigner: true, isWritable: true },
      { pubkey: SYSTEM, isSigner: false, isWritable: false },
      { pubkey: TOKEN_2022, isSigner: false, isWritable: false },
      { pubkey: ATA_PROG, isSigner: false, isWritable: false },
      { pubkey: MAYHEM_PROGRAM, isSigner: false, isWritable: true },
      { pubkey: globalParams, isSigner: false, isWritable: false },
      { pubkey: solVault, isSigner: false, isWritable: true },
      { pubkey: mayhemState, isSigner: false, isWritable: true },
      { pubkey: mayhemTokenVault, isSigner: false, isWritable: true },
      { pubkey: eventAuthority, isSigner: false, isWritable: false },
      { pubkey: PUMP_PROGRAM, isSigner: false, isWritable: false },
    ],
    data: createData
  });

  const devBuy = params.initialBuy || 0;
  if (devBuy > 0) {
    const associatedUser = await gata(mint, user, TOKEN_2022);
    instructions.push({
      programId: ATA_PROG,
      keys: [
        { pubkey: user, isSigner: true, isWritable: true },
        { pubkey: associatedUser, isSigner: false, isWritable: true },
        { pubkey: user, isSigner: false, isWritable: false },
        { pubkey: mint, isSigner: false, isWritable: false },
        { pubkey: SYSTEM, isSigner: false, isWritable: false },
        { pubkey: TOKEN_2022, isSigner: false, isWritable: false },
      ],
      data: new Uint8Array([1])
    });

    console.log('[urchin] Fetching pump.fun global state for buy params...');
    const globalData = await fetchPumpGlobal(global, settings.solanaRpc);

    const solLamports = BigInt(Math.round(devBuy * 1e9));
    const vtr = globalData.initialVirtualTokenReserves;
    const vsr = globalData.initialVirtualSolReserves;
    const totalFeeBps = globalData.feeBasisPoints + globalData.creatorFeeBasisPoints;
    const adjustedSol = (solLamports - 1n) * 10000n / (10000n + totalFeeBps);
    const tokenAmount = adjustedSol * vtr / (vsr + adjustedSol);
    const slippagePct = BigInt(params.slippage || 25);
    const maxSolCost = solLamports + solLamports * slippagePct / 100n;

    const [creatorVault] = await fpda([te('creator-vault'), user.toBytes()], PUMP_PROGRAM);
    const [globalVolAccum] = await fpda([te('global_volume_accumulator')], PUMP_PROGRAM);
    const [userVolAccum] = await fpda([te('user_volume_accumulator'), user.toBytes()], PUMP_PROGRAM);
    const [feeConfig] = await fpda([te('fee_config'), PUMP_PROGRAM.toBytes()], FEE_PROGRAM);
    const [bondingCurveV2] = await fpda([te('bonding-curve-v2'), mint.toBytes()], PUMP_PROGRAM);

    const buyData = cat(
      new Uint8Array([102, 6, 61, 18, 1, 218, 235, 234]),
      bU64(tokenAmount),
      bU64(maxSolCost),
      new Uint8Array([1])
    );
    instructions.push({
      programId: PUMP_PROGRAM,
      keys: [
        { pubkey: global, isSigner: false, isWritable: false },
        { pubkey: globalData.feeRecipient, isSigner: false, isWritable: true },
        { pubkey: mint, isSigner: false, isWritable: false },
        { pubkey: bondingCurve, isSigner: false, isWritable: true },
        { pubkey: assocBondingCurve, isSigner: false, isWritable: true },
        { pubkey: associatedUser, isSigner: false, isWritable: true },
        { pubkey: user, isSigner: true, isWritable: true },
        { pubkey: SYSTEM, isSigner: false, isWritable: false },
        { pubkey: TOKEN_2022, isSigner: false, isWritable: false },
        { pubkey: creatorVault, isSigner: false, isWritable: true },
        { pubkey: eventAuthority, isSigner: false, isWritable: false },
        { pubkey: PUMP_PROGRAM, isSigner: false, isWritable: false },
        { pubkey: globalVolAccum, isSigner: false, isWritable: false },
        { pubkey: userVolAccum, isSigner: false, isWritable: true },
        { pubkey: feeConfig, isSigner: false, isWritable: false },
        { pubkey: FEE_PROGRAM, isSigner: false, isWritable: false },
        { pubkey: bondingCurveV2, isSigner: false, isWritable: false },
      ],
      data: buyData
    });
    console.log(`[urchin] Buy ix: ${tokenAmount} tokens for max ${maxSolCost} lamports (${devBuy} SOL + ${slippagePct}% slippage)`);
  }

  console.log(`[urchin] Building tx with ${instructions.length} instructions...`);
  const blockhash = await getLatestBlockhash(settings.solanaRpc);
  const tx = buildLegacyTransaction(user, blockhash, instructions);
  const signed = signSerializedTx(tx, [kp, mintKp]);
  const txSig = await sendRawTx(signed, settings.solanaRpc);
  console.log('[urchin] Direct deploy tx:', txSig);
  return txSig;
}

async function pumpDeploy(params, pin, settings) {
  if (!settings.solanaRpc) throw new Error('Solana RPC URL required. Go to Settings → paste your RPC URL.');
  const kp = await getDeployerKeypair(pin);
  const pubKey = kp.publicKey.toBase58();

  let mintKp;
  if (params.mintKey) {
    mintKp = SolanaLite.Keypair.fromSecretKey(SolanaLite.bs58decode(params.mintKey));
  } else {
    mintKp = SolanaLite.Keypair.generate();
  }
  const mintPub = mintKp.publicKey.toBase58();

  const bal = await SolanaLite.getBalance(pubKey, settings.solanaRpc);
  const needSol = (params.initialBuy || 0) + 0.02;
  if (bal < needSol) throw new Error(`Insufficient SOL. Deployer has ${bal.toFixed(4)} SOL, need ~${needSol.toFixed(4)} SOL.`);

  let imageBlob = null;
  try { imageBlob = await resolveImageBlob(params.image); } catch (e) {
    throw new Error(`Could not load image: ${e.message}`);
  }

  let metadataUri = params.uri;
  if (!metadataUri) {
    const formData = new FormData();
    formData.append('name', params.name);
    formData.append('symbol', params.symbol);
    formData.append('description', params.description || '');
    formData.append('showName', 'true');
    if (params.twitter) formData.append('twitter', params.twitter);
    if (params.telegram) formData.append('telegram', params.telegram);
    if (params.website) formData.append('website', params.website);
    if (imageBlob) {
      const ext = (imageBlob.type || 'image/png').split('/')[1] || 'png';
      formData.append('file', imageBlob, `token.${ext}`);
    }

    let pumpIpfsOk = false;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const ipfsRes = await fetch('https://pump.fun/api/ipfs', { method: 'POST', body: formData });
        if (ipfsRes.ok) {
          const ipfsData = await ipfsRes.json();
          metadataUri = ipfsData.metadataUri;
          pumpIpfsOk = true;
          break;
        }
        if (ipfsRes.status >= 500 && attempt < 2) {
          console.log(`[urchin] pump.fun IPFS ${ipfsRes.status} — retry ${attempt + 1}/3`);
          await new Promise(r => setTimeout(r, (attempt + 1) * 3000));
          continue;
        }
      } catch (e) {
        console.log(`[urchin] pump.fun IPFS network error — retry ${attempt + 1}/3`);
        if (attempt < 2) { await new Promise(r => setTimeout(r, (attempt + 1) * 3000)); continue; }
      }
    }

    if (!pumpIpfsOk) {
      console.log('[urchin] pump.fun IPFS down — using catbox.moe fallback');
      try {
        metadataUri = await fallbackMetadataUpload(params, imageBlob);
      } catch (fbErr) {
        throw new Error(`Metadata upload failed: pump.fun IPFS is down and fallback also failed (${fbErr.message}). Provide a "uri" field directly.`);
      }
    }
  }

  // --- Direct on-chain deploy (primary path, uses pump-fun-sdk logic) ---
  try {
    console.log('[urchin] Attempting direct on-chain deploy...');
    const txSig = await pumpDirectDeploy(params, kp, mintKp, metadataUri, settings);
    return {
      success: true, name: params.name, symbol: params.symbol,
      mint: mintPub, signature: txSig,
      explorer: `https://solscan.io/tx/${txSig}`,
      pump: `https://pump.fun/coin/${mintPub}`,
      metadataUri, method: 'direct',
      message: `Token $${params.symbol} deployed! Mint: ${mintPub}`
    };
  } catch (directErr) {
    console.warn('[urchin] Direct deploy failed, falling back to PumpPortal:', directErr.message || directErr);
  }

  // --- PumpPortal fallback ---
  console.log('[urchin] Using PumpPortal fallback...');
  const devBuy = params.initialBuy || 0;
  const body = {
    publicKey: pubKey, action: 'create',
    tokenMetadata: { name: params.name, symbol: params.symbol, uri: metadataUri },
    mint: mintPub, denominatedInSol: 'true', amount: devBuy,
    slippage: params.slippage || 10, priorityFee: params.priorityFee || 0.0005,
    pool: 'pump', isMayhemMode: 'false'
  };

  let res;
  try {
    res = await fetch('https://pumpportal.fun/api/trade-local', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
  } catch (fetchErr) {
    throw new Error(`Both direct deploy and PumpPortal failed. PumpPortal unreachable: ${fetchErr.message || fetchErr}`);
  }
  const resText = await res.text();
  if (!res.ok) {
    console.error('[urchin] PumpPortal error:', resText.slice(0, 500));
    throw new Error(`Both direct deploy and PumpPortal failed (${res.status}): ${resText.slice(0, 300)}`);
  }

  const txB64 = resText.trim();
  if (!txB64 || txB64.length < 10) throw new Error(`PumpPortal returned empty transaction.`);

  let signed;
  try {
    signed = SolanaLite.signBase64Tx(txB64, [kp, mintKp]);
  } catch (signErr) {
    throw new Error(`Transaction signing failed: ${signErr.message || signErr}`);
  }

  let txSig;
  try {
    txSig = await SolanaLite.sendRawTx(signed, settings.solanaRpc);
  } catch (sendErr) {
    throw new Error(`Transaction broadcast failed: ${sendErr.message || sendErr}`);
  }

  return {
    success: true, name: params.name, symbol: params.symbol,
    mint: mintPub, signature: txSig,
    explorer: `https://solscan.io/tx/${txSig}`,
    pump: `https://pump.fun/coin/${mintPub}`,
    metadataUri, method: 'pumpportal',
    message: `Token $${params.symbol} deployed! Mint: ${mintPub}`
  };
}

/* ── X/Twitter HTTP Client (XActions-style, no Puppeteer) ── */
const TWITTER_BEARER = 'AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA';
let _xGuestToken = null;
let _xGuestExpiry = 0;

async function xGuestToken() {
  if (_xGuestToken && Date.now() < _xGuestExpiry) return _xGuestToken;
  const res = await fetch('https://api.twitter.com/1.1/guest/activate.json', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${decodeURIComponent(TWITTER_BEARER)}` }
  });
  if (!res.ok) throw new Error(`Twitter guest token failed (${res.status}). Try again shortly.`);
  const data = await res.json();
  _xGuestToken = data.guest_token;
  _xGuestExpiry = Date.now() + 3_600_000;
  return _xGuestToken;
}

async function xApiCall(endpoint, params = {}) {
  const gt = await xGuestToken();
  const qs = new URLSearchParams(params).toString();
  const res = await fetch(`https://api.twitter.com/1.1/${endpoint}?${qs}`, {
    headers: {
      'Authorization': `Bearer ${decodeURIComponent(TWITTER_BEARER)}`,
      'x-guest-token': gt
    }
  });
  if (res.status === 429) { _xGuestToken = null; throw new Error('Twitter rate limit hit. Wait ~1 minute and try again.'); }
  if (!res.ok) throw new Error(`Twitter API ${res.status}: ${(await res.text()).slice(0, 200)}`);
  return res.json();
}

async function xGraphQL(operationName, queryId, variables, features = {}) {
  const gt = await xGuestToken();
  const defaultFeatures = {
    creator_subscriptions_tweet_preview_api_enabled: true,
    responsive_web_graphql_exclude_directive_enabled: true,
    verified_phone_label_enabled: false,
    responsive_web_graphql_timeline_navigation_enabled: true,
    responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
    responsive_web_enhance_cards_enabled: false,
    tweetypie_unmention_optimization_enabled: true,
    responsive_web_twitter_article_tweet_consumption_enabled: true,
    tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled: true,
    freedom_of_speech_not_reach_fetch_enabled: true,
    standardized_nudges_misinfo: true,
    longform_notetweets_rich_text_read_enabled: true,
    longform_notetweets_inline_media_enabled: true,
    ...features
  };
  const qs = new URLSearchParams({
    variables: JSON.stringify(variables),
    features: JSON.stringify(defaultFeatures)
  }).toString();
  const res = await fetch(`https://twitter.com/i/api/graphql/${queryId}/${operationName}?${qs}`, {
    headers: {
      'Authorization': `Bearer ${decodeURIComponent(TWITTER_BEARER)}`,
      'x-guest-token': gt,
      'content-type': 'application/json'
    }
  });
  if (res.status === 429) { _xGuestToken = null; throw new Error('Twitter rate limit. Wait ~1 min.'); }
  if (!res.ok) throw new Error(`Twitter GraphQL ${res.status}`);
  return res.json();
}

async function xGetProfile(username) {
  try {
    const data = await xApiCall('users/show.json', { screen_name: username });
    return {
      id: data.id_str, name: data.name, username: data.screen_name,
      bio: data.description, followers: data.followers_count, following: data.friends_count,
      tweets: data.statuses_count, likes: data.favourites_count, joined: data.created_at,
      verified: data.verified || data.is_blue_verified,
      avatar: (data.profile_image_url_https || '').replace('_normal', '_400x400'),
      banner: data.profile_banner_url || null,
      location: data.location || null,
      website: data.entities?.url?.urls?.[0]?.expanded_url || null,
      url: `https://x.com/${data.screen_name}`
    };
  } catch (e) {
    try {
      const gql = await xGraphQL('UserByScreenName', 'xmU6X_CKVnQ5lSrCbAmJsg', {
        screen_name: username, withSafetyModeUserFields: true
      });
      const u = gql?.data?.user?.result;
      if (!u) return { error: `@${username} not found` };
      const l = u.legacy || {};
      return {
        id: u.rest_id, name: l.name, username: l.screen_name, bio: l.description,
        followers: l.followers_count, following: l.friends_count, tweets: l.statuses_count,
        likes: l.favourites_count, joined: l.created_at, verified: u.is_blue_verified,
        avatar: (l.profile_image_url_https || '').replace('_normal', '_400x400'),
        banner: l.profile_banner_url, location: l.location,
        website: l.entities?.url?.urls?.[0]?.expanded_url,
        url: `https://x.com/${l.screen_name}`
      };
    } catch (e2) {
      return { error: `Could not fetch profile for @${username}: ${e2.message}` };
    }
  }
}

async function xSearchTweets(query, count = 20) {
  try {
    const data = await xApiCall('search/tweets.json', {
      q: query, count: Math.min(count, 100), result_type: 'recent', tweet_mode: 'extended'
    });
    return (data.statuses || []).map(t => ({
      id: t.id_str, text: (t.full_text || t.text || '').slice(0, 500),
      author: t.user?.screen_name, authorName: t.user?.name,
      followers: t.user?.followers_count,
      likes: t.favorite_count, retweets: t.retweet_count,
      timestamp: t.created_at,
      url: `https://x.com/${t.user?.screen_name}/status/${t.id_str}`
    })).slice(0, count);
  } catch (_) {
    try {
      const gql = await xGraphQL('SearchTimeline', 'nK1dw4oV3k4w5TdtcAdSww', {
        rawQuery: query, count: Math.min(count, 40), querySource: 'typed_query', product: 'Latest'
      });
      const entries = gql?.data?.search_by_raw_query?.search_timeline?.timeline?.instructions?.[0]?.entries || [];
      return entries.filter(e => e.entryId?.startsWith('tweet-')).map(e => {
        const tw = e.content?.itemContent?.tweet_results?.result;
        if (!tw) return null;
        const l = tw.legacy || {};
        const ul = tw.core?.user_results?.result?.legacy || {};
        return {
          id: tw.rest_id, text: (l.full_text || '').slice(0, 500),
          author: ul.screen_name, authorName: ul.name, followers: ul.followers_count,
          likes: l.favorite_count, retweets: l.retweet_count,
          timestamp: l.created_at,
          url: `https://x.com/${ul.screen_name}/status/${tw.rest_id}`
        };
      }).filter(Boolean).slice(0, count);
    } catch (e2) {
      return [{ error: `Search failed: ${e2.message}` }];
    }
  }
}

async function xGetUserTweets(username, count = 20) {
  try {
    const data = await xApiCall('statuses/user_timeline.json', {
      screen_name: username, count: Math.min(count, 200), tweet_mode: 'extended', exclude_replies: 'true'
    });
    return (Array.isArray(data) ? data : []).map(t => ({
      id: t.id_str, text: (t.full_text || t.text || '').slice(0, 500),
      likes: t.favorite_count, retweets: t.retweet_count,
      replies: t.reply_count || 0, timestamp: t.created_at,
      url: `https://x.com/${username}/status/${t.id_str}`
    })).slice(0, count);
  } catch (_) {
    const profile = await xGetProfile(username);
    if (profile.error) return [{ error: profile.error }];
    try {
      const gql = await xGraphQL('UserTweets', 'E3opETHurmVJflFsUBVuUQ', {
        userId: profile.id, count: Math.min(count, 40),
        includePromotedContent: false, withQuickPromoteEligibilityTweetFields: false,
        withVoice: false, withV2Timeline: true
      });
      const entries = gql?.data?.user?.result?.timeline_v2?.timeline?.instructions
        ?.find(i => i.type === 'TimelineAddEntries')?.entries || [];
      return entries.filter(e => e.entryId?.startsWith('tweet-')).map(e => {
        const tw = e.content?.itemContent?.tweet_results?.result;
        if (!tw) return null;
        const l = tw.legacy || {};
        return {
          id: tw.rest_id, text: (l.full_text || '').slice(0, 500),
          likes: l.favorite_count, retweets: l.retweet_count,
          replies: l.reply_count || 0, timestamp: l.created_at,
          url: `https://x.com/${username}/status/${tw.rest_id}`
        };
      }).filter(Boolean).slice(0, count);
    } catch (e2) {
      return [{ error: `Could not fetch tweets for @${username}: ${e2.message}` }];
    }
  }
}

/* ── Wallet Balance (SOL + top tokens via RPC) ── */
async function getWalletBalance(walletAddress, rpcUrl) {
  const solBalance = await tools.rpcCall('getBalance', [walletAddress], rpcUrl);
  const solAmount = (solBalance.value || 0) / 1e9;

  let tokenAccounts = [];
  try {
    const tokenRes = await tools.rpcCall('getTokenAccountsByOwner', [
      walletAddress,
      { programId: 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA' },
      { encoding: 'jsonParsed' }
    ], rpcUrl);
    tokenAccounts = (tokenRes.value || []).map(acc => {
      const info = acc.account.data.parsed.info;
      return {
        mint: info.mint,
        amount: info.tokenAmount.uiAmountString || info.tokenAmount.amount,
        decimals: info.tokenAmount.decimals
      };
    }).filter(t => parseFloat(t.amount) > 0).sort((a, b) => parseFloat(b.amount) - parseFloat(a.amount)).slice(0, 10);
  } catch (_) {}

  return { wallet: walletAddress, solBalance: solAmount, topTokens: tokenAccounts };
}

/* ── Fetch & parse a URL into readable text ── */
async function fetchPageContent(url) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; UrchinBot/1.0)' }
    });
    clearTimeout(timeout);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const html = await res.text();
    const text = html
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
      .replace(/<nav[^>]*>[\s\S]*?<\/nav>/gi, '')
      .replace(/<footer[^>]*>[\s\S]*?<\/footer>/gi, '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/\s+/g, ' ')
      .trim();
    return text.slice(0, 8000);
  } catch (e) {
    clearTimeout(timeout);
    throw new Error(`Failed to fetch ${url}: ${e.message}`);
  }
}

/* ── Token Risk Scoring — weighted 1-100 score from scan data ── */
function computeRiskScore(scanResult) {
  if (!scanResult || scanResult.error) return null;
  let score = 100;
  const breakdown = [];

  const top1 = parseFloat(scanResult.top1Pct || 0);
  const top5 = parseFloat(scanResult.top5Pct || 0);
  const top10 = parseFloat(scanResult.top10Pct || 0);
  const fresh = scanResult.freshOwnerCount || 0;
  const holders = (scanResult.topHolders || []).length;

  if (top1 > 50) { score -= 35; breakdown.push(`Top holder owns ${top1}% — extreme concentration`); }
  else if (top1 > 30) { score -= 25; breakdown.push(`Top holder owns ${top1}% — high concentration`); }
  else if (top1 > 15) { score -= 12; breakdown.push(`Top holder owns ${top1}% — moderate`); }

  if (top5 > 80) { score -= 20; breakdown.push(`Top 5 hold ${top5}% — very concentrated`); }
  else if (top5 > 60) { score -= 10; breakdown.push(`Top 5 hold ${top5}%`); }

  if (top10 > 90) { score -= 15; breakdown.push(`Top 10 hold ${top10}% — almost all supply`); }

  if (fresh > 5) { score -= 20; breakdown.push(`${fresh} fresh/low-SOL wallets in top holders — sybil risk`); }
  else if (fresh > 2) { score -= 10; breakdown.push(`${fresh} fresh wallets in top holders`); }

  if (holders < 5) { score -= 15; breakdown.push('Very few holders detected'); }

  score = Math.max(1, Math.min(100, score));
  const rating = score >= 75 ? 'LOW RISK' : score >= 45 ? 'MODERATE RISK' : 'HIGH RISK';
  return { score, rating, breakdown };
}

/* ── Price Change Tracking — store & compare prices ── */
async function trackPrice(mint, currentPrice) {
  if (!currentPrice) return null;
  try {
    const { urchinPriceHistory = {} } = await chrome.storage.local.get('urchinPriceHistory');
    const prev = urchinPriceHistory[mint];
    const now = { price: parseFloat(currentPrice), ts: Date.now() };
    urchinPriceHistory[mint] = now;
    const keys = Object.keys(urchinPriceHistory);
    if (keys.length > 50) { delete urchinPriceHistory[keys[0]]; }
    await chrome.storage.local.set({ urchinPriceHistory });
    if (prev) {
      const delta = ((now.price - prev.price) / prev.price * 100).toFixed(2);
      const ago = Math.round((Date.now() - prev.ts) / 60000);
      const agoStr = ago < 60 ? `${ago}m ago` : `${Math.round(ago / 60)}h ago`;
      return { previous: prev.price, current: now.price, changePct: delta, since: agoStr };
    }
    return null;
  } catch (_) { return null; }
}

/* ── On-chain Cross-referencing — detect deployer/holder overlaps ── */
async function crossReferenceScan(scanResult) {
  if (!scanResult || !scanResult.topHolders) return null;
  try {
    const { urchinScanHistory = [] } = await chrome.storage.local.get('urchinScanHistory');
    const overlaps = [];
    const currentAddresses = scanResult.topHolders.map(h => h.address);
    for (const pastScan of urchinScanHistory) {
      if (pastScan.mint === scanResult.mint) continue;
      const pastAddresses = (pastScan.topHolders || []).map(h => h.address);
      const shared = currentAddresses.filter(a => pastAddresses.includes(a));
      if (shared.length > 0) {
        overlaps.push({ mint: pastScan.mint, sharedHolders: shared.length, addresses: shared.slice(0, 3) });
      }
    }
    urchinScanHistory.push({ mint: scanResult.mint, topHolders: scanResult.topHolders.slice(0, 10), ts: Date.now() });
    if (urchinScanHistory.length > 30) urchinScanHistory.shift();
    await chrome.storage.local.set({ urchinScanHistory });
    return overlaps.length > 0 ? overlaps : null;
  } catch (_) { return null; }
}

/* ── Semantic Memory Search — embeddings with cosine similarity, keyword fallback ── */
function cosineSimilarity(a, b) {
  if (!a || !b || a.length !== b.length) return 0;
  let dot = 0, magA = 0, magB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  const denom = Math.sqrt(magA) * Math.sqrt(magB);
  return denom === 0 ? 0 : dot / denom;
}

async function getEmbedding(text, settings) {
  const provider = settings.llmProvider || 'openai';
  const apiKey = settings.llmApiKey;
  if (!apiKey) return null;

  if (provider === 'anthropic') return null;

  const baseUrl = (settings.llmBaseUrl || 'https://api.openai.com/v1').replace(/\/chat\/completions\/?$/, '');
  const res = await fetch(`${baseUrl}/embeddings`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ model: 'text-embedding-3-small', input: text.slice(0, 2000) }),
  });
  if (!res.ok) return null;
  const data = await res.json();
  return data.data?.[0]?.embedding || null;
}

async function getEmbeddingsBatch(texts, settings) {
  const provider = settings.llmProvider || 'openai';
  if (provider === 'anthropic' || !settings.llmApiKey) return null;
  const baseUrl = (settings.llmBaseUrl || 'https://api.openai.com/v1').replace(/\/chat\/completions\/?$/, '');
  const trimmed = texts.map(t => t.slice(0, 2000));
  try {
    const res = await fetch(`${baseUrl}/embeddings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${settings.llmApiKey}` },
      body: JSON.stringify({ model: 'text-embedding-3-small', input: trimmed }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (!data.data) return null;
    const sorted = data.data.sort((a, b) => a.index - b.index);
    return sorted.map(d => d.embedding);
  } catch (_) { return null; }
}

async function semanticRecallWithEmbeddings(query, memory, settings) {
  const { urchinEmbeddingCache = {} } = await chrome.storage.local.get('urchinEmbeddingCache');
  const queryEmb = await getEmbedding(query, settings);

  if (!queryEmb) return keywordFallback(query, memory);

  const entries = Object.entries(memory).filter(([k]) => !k.startsWith('_'));
  const uncachedKeys = [];
  const uncachedTexts = [];
  for (const [key, value] of entries) {
    if (!urchinEmbeddingCache[key]) {
      uncachedKeys.push(key);
      uncachedTexts.push(`${key}: ${value}`);
    }
  }

  let cacheUpdated = false;
  if (uncachedKeys.length > 0) {
    const batchEmbs = await getEmbeddingsBatch(uncachedTexts, settings);
    if (batchEmbs) {
      for (let i = 0; i < uncachedKeys.length; i++) {
        if (batchEmbs[i]) { urchinEmbeddingCache[uncachedKeys[i]] = batchEmbs[i]; cacheUpdated = true; }
      }
    }
  }

  const results = [];
  for (const [key, value] of entries) {
    const emb = urchinEmbeddingCache[key];
    if (emb) {
      const sim = cosineSimilarity(queryEmb, emb);
      if (sim > 0.25) results.push({ key, value, relevance: Math.round(sim * 100) / 100 });
    } else {
      const kw = query.toLowerCase().split(/\s+/).filter(w => w.length > 2);
      const combined = `${key} ${value}`.toLowerCase();
      const mc = kw.filter(w => combined.includes(w)).length;
      if (mc > 0) results.push({ key, value, relevance: Math.round((mc / kw.length) * 50) / 100 });
    }
  }

  if (cacheUpdated) {
    const keys = Object.keys(urchinEmbeddingCache);
    if (keys.length > 300) {
      for (const k of keys.slice(0, keys.length - 300)) delete urchinEmbeddingCache[k];
    }
    await chrome.storage.local.set({ urchinEmbeddingCache });
  }

  results.sort((a, b) => b.relevance - a.relevance);
  return { results: results.slice(0, 10), method: 'embeddings' };
}

function keywordFallback(query, memory) {
  const keywords = query.toLowerCase().split(/\s+/).filter(w => w.length > 2);
  if (keywords.length === 0) return { results: [], method: 'keyword' };
  const results = [];
  for (const [key, value] of Object.entries(memory)) {
    if (key.startsWith('_')) continue;
    const combined = `${key} ${value}`.toLowerCase();
    const matchCount = keywords.filter(kw => combined.includes(kw)).length;
    if (matchCount > 0) {
      results.push({ key, value, relevance: matchCount / keywords.length });
    }
  }
  results.sort((a, b) => b.relevance - a.relevance);
  return { results: results.slice(0, 10), method: 'keyword' };
}

function semanticRecall(query, memory) {
  return keywordFallback(query, memory);
}

async function relevanceFilterMemories(userInput, memories, settings, maxResults = 8) {
  const queryEmb = await getEmbedding(userInput, settings);
  const { urchinEmbeddingCache = {} } = await chrome.storage.local.get('urchinEmbeddingCache');
  const scored = [];
  let cacheUpdated = false;

  const entries = Object.entries(memories).filter(([k]) => !k.startsWith('_'));
  const uncachedKeys = [];
  const uncachedTexts = [];
  for (const [key, value] of entries) {
    if (!urchinEmbeddingCache[key]) {
      uncachedKeys.push(key);
      uncachedTexts.push(`${key}: ${String(value).slice(0, 500)}`);
    }
  }

  if (queryEmb && uncachedKeys.length > 0) {
    const batchEmbs = await getEmbeddingsBatch(uncachedTexts, settings);
    if (batchEmbs) {
      for (let i = 0; i < uncachedKeys.length; i++) {
        if (batchEmbs[i]) { urchinEmbeddingCache[uncachedKeys[i]] = batchEmbs[i]; cacheUpdated = true; }
      }
    }
  }

  for (const [key, value] of entries) {
    const emb = urchinEmbeddingCache[key];
    if (queryEmb && emb) {
      scored.push({ key, value, sim: cosineSimilarity(queryEmb, emb) });
    } else {
      const kw = userInput.toLowerCase().split(/\s+/).filter(w => w.length > 2);
      const combined = `${key}: ${String(value).slice(0, 500)}`.toLowerCase();
      const mc = kw.filter(w => combined.includes(w)).length;
      scored.push({ key, value, sim: kw.length > 0 ? (mc / kw.length) * 0.5 : 0 });
    }
  }

  if (cacheUpdated) {
    const keys = Object.keys(urchinEmbeddingCache);
    if (keys.length > 300) {
      for (const k of keys.slice(0, keys.length - 300)) delete urchinEmbeddingCache[k];
    }
    await chrome.storage.local.set({ urchinEmbeddingCache });
  }

  scored.sort((a, b) => b.sim - a.sim);
  return scored.filter(s => s.sim > 0.2).slice(0, maxResults);
}

/* ── DexScreener API — structured token pair data with chart previews ── */
async function fetchDexScreenerData(mintOrQuery) {
  try {
    const res = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${encodeURIComponent(mintOrQuery)}`);
    if (!res.ok) throw new Error(`DexScreener API ${res.status}`);
    const data = await res.json();
    if (!data.pairs || data.pairs.length === 0) return { error: 'No pairs found on DexScreener' };
    return data.pairs.slice(0, 3).map(p => ({
      dex: p.dexId, chain: p.chainId,
      baseToken: p.baseToken?.symbol, baseAddress: p.baseToken?.address,
      quoteToken: p.quoteToken?.symbol,
      price: p.priceUsd,
      priceChange5m: p.priceChange?.m5,
      priceChange1h: p.priceChange?.h1,
      priceChange6h: p.priceChange?.h6,
      priceChange24h: p.priceChange?.h24,
      volume24h: p.volume?.h24,
      txns24h: p.txns?.h24 ? { buys: p.txns.h24.buys, sells: p.txns.h24.sells } : null,
      liquidity: p.liquidity?.usd,
      pairAge: p.pairCreatedAt ? Math.round((Date.now() - p.pairCreatedAt) / 86400000) + 'd' : 'unknown',
      fdv: p.fdv, url: p.url,
      pairAddress: p.pairAddress,
      chartUrl: p.url,
      chartImageUrl: p.baseToken?.address ? `https://dd.dexscreener.com/ds-data/tokens/${p.chainId}/${p.baseToken.address}/header.png` : null,
    }));
  } catch (e) { return { error: e.message }; }
}

/* ── Smart page parser — extracts structured data from crypto sites ── */
function parsePageForCryptoData(url, pageText) {
  const data = { pageType: 'unknown', tokens: [], addresses: [], prices: [], links: [] };

  if (/dexscreener\.com/i.test(url)) {
    data.pageType = 'dexscreener';
  } else if (/birdeye\.so/i.test(url)) {
    data.pageType = 'birdeye';
  } else if (/pump\.fun/i.test(url)) {
    data.pageType = 'pump.fun';
  } else if (/jup\.ag|jupiter/i.test(url)) {
    data.pageType = 'jupiter';
  } else if (/solscan\.io/i.test(url)) {
    data.pageType = 'solscan';
  } else if (/x\.com|twitter\.com/i.test(url)) {
    data.pageType = 'twitter';
  } else if (/raydium\.io/i.test(url)) {
    data.pageType = 'raydium';
  }

  const mintRe = /[1-9A-HJ-NP-Za-km-z]{32,44}/g;
  const mints = pageText.match(mintRe) || [];
  data.addresses = [...new Set(mints)].filter(m => m.length >= 32 && m.length <= 44).slice(0, 10);

  const priceRe = /\$[\d,]+\.?\d*/g;
  data.prices = [...new Set((pageText.match(priceRe) || []))].slice(0, 10);

  const cashtags = pageText.match(/\$[A-Z]{2,10}/g) || [];
  data.tokens = [...new Set(cashtags)].slice(0, 10);

  return data;
}

/* ── Multi-token scan — scan multiple mints and compare ── */
async function multiTokenScan(mints, rpcUrl) {
  const results = [];
  for (const mint of mints.slice(0, 5)) {
    try {
      const scan = await tools.solanaScanMint(mint.trim(), rpcUrl);
      results.push({ mint: mint.trim(), ...scan });
    } catch (e) {
      results.push({ mint: mint.trim(), error: e.message });
    }
  }
  if (results.length > 1) {
    const valid = results.filter(r => !r.error && r.topHolders);
    if (valid.length > 1) {
      const ranked = valid.sort((a, b) => {
        const aConc = a.topHolders?.reduce((s, h) => s + (h.pct || 0), 0) || 100;
        const bConc = b.topHolders?.reduce((s, h) => s + (h.pct || 0), 0) || 100;
        return aConc - bConc;
      });
      results.push({ _comparison: `Safest distribution: ${ranked[0].mint} — Most concentrated: ${ranked[ranked.length - 1].mint}` });
    }
  }
  return results;
}

/* ── PnL Tracker — realized/unrealized estimate for a wallet ── */
async function getWalletPnL(walletAddress, rpcUrl) {
  const balance = await getWalletBalance(walletAddress, rpcUrl);
  const held = balance.topTokens || [];
  if (held.length === 0) return { wallet: walletAddress, solBalance: balance.solBalance, tokens: [], totalUnrealizedUsd: 0, note: 'No token holdings found.' };

  const mints = held.map(t => t.mint);
  const priceIds = mints.join(',');
  let prices = {};
  try {
    const res = await fetch(`https://api.jup.ag/price/v2?ids=${encodeURIComponent(priceIds)}`);
    if (res.ok) {
      const data = await res.json();
      if (data.data) {
        for (const [id, entry] of Object.entries(data.data)) {
          prices[id] = { price: parseFloat(entry.price), symbol: entry.mintSymbol || id.slice(0, 8) };
        }
      }
    }
  } catch (_) {}

  const tokens = [];
  let totalUnrealizedUsd = 0;

  for (const t of held) {
    const amount = parseFloat(t.amount);
    const priceInfo = prices[t.mint];
    if (priceInfo && priceInfo.price > 0) {
      const valueUsd = amount * priceInfo.price;
      totalUnrealizedUsd += valueUsd;
      tokens.push({ mint: t.mint, symbol: priceInfo.symbol, amount, priceUsd: priceInfo.price, valueUsd: Math.round(valueUsd * 100) / 100 });
    } else {
      tokens.push({ mint: t.mint, symbol: t.mint.slice(0, 8), amount, priceUsd: null, valueUsd: null, note: 'Price unavailable' });
    }
  }

  tokens.sort((a, b) => (b.valueUsd || 0) - (a.valueUsd || 0));

  let solUsd = null;
  try {
    const solPrice = await getTokenPrice('So11111111111111111111111111111111', {});
    if (solPrice.price) solUsd = parseFloat(solPrice.price);
  } catch (_) {}

  const solValueUsd = solUsd ? Math.round(balance.solBalance * solUsd * 100) / 100 : null;
  const totalPortfolioUsd = solValueUsd !== null ? Math.round((totalUnrealizedUsd + solValueUsd) * 100) / 100 : null;

  return {
    wallet: walletAddress,
    solBalance: balance.solBalance,
    solPriceUsd: solUsd,
    solValueUsd,
    tokens,
    totalTokenValueUsd: Math.round(totalUnrealizedUsd * 100) / 100,
    totalPortfolioUsd,
    checkedAt: new Date().toISOString()
  };
}

/* ── Wallet Activity Tracker — zero-LLM polling for watched wallets ── */
async function checkWalletActivity(walletAddress, label, rpcUrl) {
  const events = [];
  try {
    const { urchinWalletSnapshots = {} } = await chrome.storage.local.get('urchinWalletSnapshots');
    const prev = urchinWalletSnapshots[walletAddress] || { mints: {}, solBalance: null, lastSig: null };

    const balance = await getWalletBalance(walletAddress, rpcUrl);
    const currentMints = {};
    for (const t of (balance.topTokens || [])) currentMints[t.mint] = parseFloat(t.amount);

    const newMints = [];
    const removedMints = [];
    for (const [mint, amount] of Object.entries(currentMints)) {
      if (!prev.mints[mint]) newMints.push({ mint, amount });
    }
    for (const [mint, amount] of Object.entries(prev.mints)) {
      if (!currentMints[mint]) removedMints.push({ mint, amount });
    }

    const solDelta = prev.solBalance !== null ? balance.solBalance - prev.solBalance : 0;

    let prices = {};
    const allMints = [...newMints.map(m => m.mint), ...removedMints.map(m => m.mint)];
    if (allMints.length > 0) {
      try {
        const res = await fetch(`https://api.jup.ag/price/v2?ids=${encodeURIComponent(allMints.join(','))}`);
        if (res.ok) {
          const data = await res.json();
          if (data.data) for (const [id, e] of Object.entries(data.data)) prices[id] = { price: parseFloat(e.price), symbol: e.mintSymbol || id.slice(0, 8) };
        }
      } catch (_) {}
    }

    for (const { mint, amount } of newMints) {
      const p = prices[mint];
      const valueUsd = p ? Math.round(amount * p.price * 100) / 100 : null;
      events.push({ wallet: walletAddress, label, event: 'new_token', mint, symbol: p?.symbol || mint.slice(0, 8), amount, valueUsd, time: Date.now() });
    }
    for (const { mint, amount } of removedMints) {
      const p = prices[mint];
      events.push({ wallet: walletAddress, label, event: 'sold_token', mint, symbol: p?.symbol || mint.slice(0, 8), amount, time: Date.now() });
    }
    if (Math.abs(solDelta) > 0.1) {
      events.push({ wallet: walletAddress, label, event: solDelta < 0 ? 'sol_spend' : 'sol_receive', amount: Math.round(Math.abs(solDelta) * 1000) / 1000, time: Date.now() });
    }

    urchinWalletSnapshots[walletAddress] = { mints: currentMints, solBalance: balance.solBalance, lastChecked: Date.now() };
    const snapKeys = Object.keys(urchinWalletSnapshots);
    if (snapKeys.length > 25) delete urchinWalletSnapshots[snapKeys[0]];
    await chrome.storage.local.set({ urchinWalletSnapshots });
  } catch (_) {}
  return events;
}

async function runWalletTrackerCycle() {
  try {
    const [{ urchinWatchlist = [] }, { urchinDigestConfig = {} }] = await Promise.all([
      chrome.storage.local.get('urchinWatchlist'),
      chrome.storage.local.get('urchinDigestConfig'),
    ]);
    if (urchinWatchlist.length === 0) return;
    const settings = await getSettings();
    if (!settings.solanaRpc) return;
    const minUsd = urchinDigestConfig.minNotifyUsd ?? 10;

    const walletsToCheck = urchinWatchlist.slice(0, 5);
    const allEvents = [];

    for (const w of walletsToCheck) {
      try {
        const events = await checkWalletActivity(w.address, w.label, settings.solanaRpc);
        allEvents.push(...events);
      } catch (_) {}
    }

    if (allEvents.length === 0) return;

    const { urchinWalletActivity = [] } = await chrome.storage.local.get('urchinWalletActivity');
    urchinWalletActivity.push(...allEvents);
    while (urchinWalletActivity.length > 200) urchinWalletActivity.shift();
    await chrome.storage.local.set({ urchinWalletActivity });

    const { urchinTrackerNotifs = { count: 0, windowStart: 0 } } = await chrome.storage.local.get('urchinTrackerNotifs');
    const now = Date.now();
    if (now - urchinTrackerNotifs.windowStart > 3600000) { urchinTrackerNotifs.count = 0; urchinTrackerNotifs.windowStart = now; }

    const significant = allEvents.filter(e => {
      if (e.event === 'new_token' && e.valueUsd !== null && e.valueUsd >= minUsd) return true;
      if (e.event === 'sold_token') return true;
      if ((e.event === 'sol_spend' || e.event === 'sol_receive') && e.amount >= 0.5) return true;
      return false;
    });

    if (significant.length > 0 && urchinTrackerNotifs.count < 5) {
      const lines = significant.slice(0, 3).map(e => {
        if (e.event === 'new_token') return `${e.label} bought ${e.symbol}${e.valueUsd ? ` (~$${e.valueUsd})` : ''}`;
        if (e.event === 'sold_token') return `${e.label} sold ${e.symbol}`;
        if (e.event === 'sol_spend') return `${e.label} spent ${e.amount} SOL`;
        if (e.event === 'sol_receive') return `${e.label} received ${e.amount} SOL`;
        return `${e.label}: ${e.event}`;
      });
      chrome.notifications.create(`urchin-tracker-${now}`, {
        type: 'basic', iconUrl: 'icons/icon128.png',
        title: 'urchinbot — Wallet Activity',
        message: lines.join(' | ')
      });
      try {
        const tabs = await chrome.tabs.query({});
        for (const tab of tabs) {
          try { chrome.tabs.sendMessage(tab.id, { action: 'URCHIN_AUTONOMOUS_RESULT', taskId: `tracker-${now}`, input: 'Wallet Activity', answer: lines.join('\n'), completedAt: now }); } catch (_) {}
        }
      } catch (_) {}
      urchinTrackerNotifs.count += 1;
      await chrome.storage.local.set({ urchinTrackerNotifs });
    }
  } catch (_) {}
}

/* ── Transaction history for wallet ── */
async function getWalletTransactions(walletAddress, rpcUrl) {
  const sigs = await tools.rpcCall('getSignaturesForAddress', [walletAddress, { limit: 15 }], rpcUrl);
  const txns = [];
  for (const sig of (sigs || []).slice(0, 10)) {
    txns.push({
      signature: sig.signature,
      slot: sig.slot,
      time: sig.blockTime ? new Date(sig.blockTime * 1000).toISOString() : null,
      err: sig.err ? 'failed' : 'success',
      memo: sig.memo || null
    });
  }
  return { wallet: walletAddress, recentTransactions: txns };
}

/* ── Tools ── */
const tools = {
  detectSolanaMints(text) {
    const re = /[1-9A-HJ-NP-Za-km-z]{32,44}/g;
    const matches = text.match(re) || [];
    return [...new Set(matches)].filter(m => m.length >= 32 && m.length <= 44);
  },

  async rpcCall(method, params, rpcUrl) {
    const res = await fetch(rpcUrl, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params })
    });
    const json = await res.json();
    if (json.error) throw new Error(`RPC error: ${json.error.message}`);
    return json.result;
  },

  async solanaScanMint(mint, rpcUrl) {
    const supply = await tools.rpcCall('getTokenSupply', [mint], rpcUrl);
    const totalSupply = parseFloat(supply.value.uiAmountString || supply.value.amount);
    const decimals = supply.value.decimals;

    const largest = await tools.rpcCall('getTokenLargestAccounts', [mint], rpcUrl);
    const accounts = largest.value || [];

    let top1 = 0, top5 = 0, top10 = 0;
    const ownerAddresses = [];
    for (let i = 0; i < Math.min(accounts.length, 10); i++) {
      const pct = (parseFloat(accounts[i].uiAmountString || accounts[i].amount) / totalSupply) * 100;
      if (i < 1) top1 += pct;
      if (i < 5) top5 += pct;
      top10 += pct;
      ownerAddresses.push(accounts[i].address);
    }

    let freshOwnerCount = 0;
    if (ownerAddresses.length > 0) {
      try {
        const accInfos = await tools.rpcCall('getMultipleAccounts', [ownerAddresses, { encoding: 'jsonParsed' }], rpcUrl);
        for (const acc of (accInfos.value || [])) {
          if (acc && acc.lamports < 20000000) freshOwnerCount++;
        }
      } catch (_) { /* non-critical */ }
    }

    return {
      mint,
      totalSupply: totalSupply.toString(),
      decimals,
      top1Pct: top1.toFixed(2),
      top5Pct: top5.toFixed(2),
      top10Pct: top10.toFixed(2),
      topHolders: accounts.slice(0, 10).map((a, i) => ({
        rank: i + 1, address: a.address,
        amount: a.uiAmountString || a.amount,
        pct: ((parseFloat(a.uiAmountString || a.amount) / totalSupply) * 100).toFixed(2)
      })),
      freshOwnerCount,
      links: {
        solscan: `https://solscan.io/token/${mint}`,
        topHolder: accounts[0] ? `https://solscan.io/account/${accounts[0].address}` : null
      }
    };
  },

  validateProjectFiles(project) {
    const errors = [];
    const allowed = ['index.html', 'styles.css', 'app.js'];
    if (!project.projectName) errors.push('Missing projectName');
    if (!Array.isArray(project.files)) { errors.push('files must be array'); return { ok: false, errors }; }

    let totalBytes = 0;
    for (const f of project.files) {
      if (!allowed.includes(f.path)) errors.push(`Disallowed file path: ${f.path}`);
      totalBytes += (f.content || '').length;
    }
    if (totalBytes > 400000) errors.push(`Total size ${totalBytes} exceeds 400KB`);

    const html = project.files.find(f => f.path === 'index.html');
    if (html) {
      if (!html.content.includes('styles.css')) errors.push('index.html must reference styles.css');
      if (!html.content.includes('app.js')) errors.push('index.html must reference app.js');
      if (/<script[^>]+src\s*=\s*["']https?:\/\//i.test(html.content)) errors.push('External script tags not allowed');
    } else {
      errors.push('Missing index.html');
    }

    return { ok: errors.length === 0, errors };
  },

  async zipProject(project) {
    const zip = new JSZip();
    const folder = zip.folder(project.projectName || 'project');
    for (const f of project.files) {
      folder.file(f.path, f.content);
    }
    const blob = await zip.generateAsync({ type: 'arraybuffer' });
    return blob;
  }
};

/* ── Netlify Deploy ── */
async function deployToNetlify(project, settings) {
  const { netlifyToken } = settings;
  if (!netlifyToken) throw new Error('Netlify token required. Go to Settings → paste your Personal Access Token.');

  const headers = {
    'Authorization': `Bearer ${netlifyToken}`,
    'Content-Type': 'application/zip'
  };

  const JSZipLib = typeof JSZip !== 'undefined' ? JSZip : (self.JSZip || null);
  if (!JSZipLib) throw new Error('JSZip not available');

  const zip = new JSZipLib();
  for (const f of project.files) {
    zip.file(f.path, f.content);
  }
  const zipBlob = await zip.generateAsync({ type: 'arraybuffer' });

  const resp = await fetch('https://api.netlify.com/api/v1/sites', {
    method: 'POST',
    headers,
    body: zipBlob
  });

  if (!resp.ok) {
    const errBody = await resp.text();
    throw new Error(`Netlify deploy failed (${resp.status}): ${errBody.slice(0, 300)}`);
  }

  const site = await resp.json();
  return {
    url: site.ssl_url || site.url || `https://${site.subdomain}.netlify.app`,
    siteId: site.id,
    siteName: site.name
  };
}

async function updateNetlifySite(project, siteId, settings) {
  const { netlifyToken } = settings;
  if (!netlifyToken) throw new Error('Netlify token required. Go to Settings → paste your Personal Access Token.');
  const JSZipLib = typeof JSZip !== 'undefined' ? JSZip : (self.JSZip || null);
  if (!JSZipLib) throw new Error('JSZip not available');
  const zip = new JSZipLib();
  for (const f of project.files) zip.file(f.path, f.content);
  const zipBlob = await zip.generateAsync({ type: 'arraybuffer' });
  const resp = await fetch(`https://api.netlify.com/api/v1/sites/${siteId}/deploys`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${netlifyToken}`, 'Content-Type': 'application/zip' },
    body: zipBlob
  });
  if (!resp.ok) {
    const errBody = await resp.text();
    throw new Error(`Netlify update failed (${resp.status}): ${errBody.slice(0, 300)}`);
  }
  const deploy = await resp.json();
  return {
    url: deploy.ssl_url || deploy.url || `https://${deploy.subdomain}.netlify.app`,
    siteId,
    deployId: deploy.id
  };
}

/* ── Netlify Site Management ── */
async function listNetlifySites(settings) {
  const { netlifyToken } = settings;
  if (!netlifyToken) throw new Error('Netlify token required. Go to Settings → paste your Personal Access Token.');
  const resp = await fetch('https://api.netlify.com/api/v1/sites?per_page=50', {
    headers: { 'Authorization': `Bearer ${netlifyToken}` }
  });
  if (!resp.ok) throw new Error(`Netlify API ${resp.status}: ${(await resp.text()).slice(0, 200)}`);
  const sites = await resp.json();
  return sites.map(s => ({
    id: s.id,
    name: s.name,
    url: s.ssl_url || s.url || `https://${s.subdomain}.netlify.app`,
    created: s.created_at,
    updated: s.updated_at
  }));
}

async function deleteNetlifySite(siteId, settings) {
  const { netlifyToken } = settings;
  if (!netlifyToken) throw new Error('Netlify token required.');
  const resp = await fetch(`https://api.netlify.com/api/v1/sites/${siteId}`, {
    method: 'DELETE',
    headers: { 'Authorization': `Bearer ${netlifyToken}` }
  });
  if (!resp.ok && resp.status !== 204) {
    throw new Error(`Delete failed (${resp.status}): ${(await resp.text()).slice(0, 200)}`);
  }
  return { success: true, deletedId: siteId };
}

/* ── UrchinLoop System Prompts ── */
const SYSTEM_PROMPT_ASK = `You are **urchinbot**, an elite crypto-savvy AI agent built as a Chrome extension overlay. Your name is urchinbot. When asked what you are, say: "I'm urchinbot — a local-first AI agent that lives in your browser. I can see your page, search the web, scan Solana tokens, check wallets, build and deploy websites, and remember everything across sessions. I'm powered by an engine called UrchinLoop."

You are exceptionally intelligent, thorough, and proactive.

MEMORY SYSTEM — you NEVER forget:
- LAYER 1: Condensed history — narrative of all past conversations, compressed but complete
- LAYER 2: Last 30 messages — full fidelity recent conversation
- LAYER 3: User profile — permanent knowledge about this user (name, wallets, preferences, projects)
- LAYER 4: Session summaries — detailed bullet points from past sessions
- LAYER 5: Manual memories — things saved with REMEMBER
You remember across sessions. When you learn something important about the user, REMEMBER it immediately.

TOOLS — include the exact tag in your response to use one:
  <<TOOL:SCAN_TOKEN:MINT_ADDRESS>> — Scan a Solana token mint for holders, concentration, fresh-wallet flags.
  <<TOOL:MULTI_SCAN:MINT1,MINT2,MINT3>> — Scan multiple tokens at once, compare safety.
  <<TOOL:DETECT_MINTS:text>> — Extract Solana mint addresses from text.
  <<TOOL:PREPARE_LAUNCH:{"name":"...","symbol":"...","description":"..."}>> — Prepare token launch packet for Deploy tab.
  <<TOOL:BUILD_SITE:{"description":"..."}>> — Build a full static website.
  <<TOOL:EDIT_SITE:{"changes":"..."}>> — Edit the currently built site.
  <<TOOL:SCREENSHOT>> — Capture and visually analyze the current page.
  <<TOOL:REVERSE_IMAGE_SEARCH>> — Capture the current page/image, identify people/logos/memes via vision + web search. Use when the user asks "who is this?", "identify this", or wants to find the source of an image/meme.
  <<TOOL:WEB_SEARCH:query>> — Search the web for real-time info (prices, news, docs).
  <<TOOL:FETCH_URL:url>> — Fetch and read the full text content of any webpage/URL.
  <<TOOL:GET_TOKEN_PRICE:MINT_OR_SYMBOL>> — Live Solana token price via Jupiter.
  <<TOOL:GET_WALLET_BALANCE:WALLET_ADDRESS>> — SOL balance + top token holdings.
  <<TOOL:GET_WALLET_HISTORY:WALLET_ADDRESS>> — Recent transaction history for a wallet.
  <<TOOL:DEPLOY_SITE>> — Deploy the current built site to Netlify instantly. Returns a live URL.
  <<TOOL:LIST_SITES>> — List all your Netlify sites (name, URL, created date). Use when user asks to see/manage their sites.
  <<TOOL:DELETE_SITE:SITE_ID>> — Delete a Netlify site by ID. Always LIST_SITES first so the user can choose which to delete.
  <<TOOL:REMEMBER:{"key":"...","value":"..."}>> — Save info to persistent memory.
  <<TOOL:RECALL:key>> — Recall saved info. Use "all" to see everything.
  <<TOOL:SEARCH_MEMORY:query>> — Fuzzy search across all saved memories by keywords. Use when the user asks "do you remember anything about X?" or "what do you know about my wallets?"
  <<TOOL:SET_ALERT:{"type":"price","target":"MINT","condition":{"below":100,"above":200}}>> — Set a price or wallet alert. Types: "price" (triggers when price crosses threshold) or "wallet" (triggers on SOL balance change). The user gets a Chrome notification when conditions are met.
  <<TOOL:REMIND_ME:{"task":"...","minutes":60}>> — Schedule a follow-up task. The agent will execute it later and notify the user with results.
  <<TOOL:DEX_DATA:MINT_ADDRESS>> — Fetch structured DexScreener data for a token: price, multi-timeframe changes (5m/1h/6h/24h), volume, liquidity, pair age, FDV, buy/sell txns, AND a chart preview image URL. When showing results, ALWAYS include the chartImageUrl as a markdown image so the user sees the chart: ![chart](URL). Also link to the full interactive chart on DexScreener.
  <<TOOL:SET_TIMER:{"task":"...","minutes":N}>> — Schedule an AUTONOMOUS background task. Unlike REMIND_ME (notification only), SET_TIMER actually runs the task through UrchinLoop when the timer fires. The agent will think, use tools, and deliver a full AI-processed result. Use for: "check this token price in 30 minutes and analyze the change", "research this project in an hour and tell me what you find".
  <<TOOL:SCHEDULE_TASK:{"task":"...","delayMinutes":0}>> — Queue a background task for autonomous execution. delayMinutes=0 means run immediately in background (non-blocking). The task runs through the full agent loop with all tools available, and results are pushed to the user via speech bubble and notification. Use for: follow-up research, multi-step background analysis, proactive monitoring tasks the user didn't explicitly ask for but would benefit from.
  <<TOOL:CONTINUE:reason>> — Self-continuation tool. Signals that you need MORE reasoning steps beyond the current loop. Use when your analysis is incomplete, you want to chain another round of tool calls, or you're working on a complex multi-step task. Include a reason describing what you still need to do. This extends your step budget.
  <<TOOL:MONITOR:{"target":"MINT_OR_WALLET","type":"token|wallet","interval":15,"instructions":"what to check and when to alert","stopAfter":360}>> — Start continuous recurring monitoring. Runs the full agent loop every [interval] minutes with the given instructions. Automatically stops after [stopAfter] minutes (default 6 hours). Each check can use ANY tools (scan, price, DexScreener, web search, etc.) and delivers results via notification + speech bubble. ONLY use when the user explicitly asks to monitor/watch something.
  <<TOOL:LIST_MONITORS>> — Show all active monitors with their targets, intervals, and time remaining.
  <<TOOL:STOP_MONITOR:monitor-id-or-target>> — Stop a running monitor by ID or target address/name. Use when the user says "stop monitoring", "cancel the watch", etc.
  <<TOOL:LEARN_SKILL:{"name":"short-name","instruction":"what to do and when"}>> — Teach yourself a new behavioral skill. The instruction becomes part of your system prompt on ALL future conversations. Use this to evolve: learn user preferences ("always use dark mode for sites"), procedures ("when scanning tokens, always check deployer wallet too"), knowledge ("user's main wallet is X"), or strategies ("for memecoins, check Twitter sentiment first"). Skills persist permanently. Be specific and actionable in the instruction.
  <<TOOL:LIST_SKILLS>> — Show all learned skills with their names and instructions.
  <<TOOL:FORGET_SKILL:skill-name>> — Remove a learned skill by name. Use when a skill is outdated, wrong, or the user asks you to unlearn something.
  <<TOOL:SET_GOAL:{"project":"name","goals":["goal1","goal2"],"milestones":[{"name":"m1","tasks":["t1","t2"],"status":"pending"}]}>> — Create or overwrite a multi-session project plan. Goals are high-level objectives. Milestones break them into phases with tasks. Use for complex multi-session work the user wants tracked over time.
  <<TOOL:UPDATE_GOAL:{"project":"name","milestone":"m1","status":"done","notes":"shipped it"}>> — Update a milestone status (pending/active/done/blocked) and add notes. Use after completing a phase of work.
  <<TOOL:GET_GOALS>> — List all active project plans with their milestones and progress. Use when the user asks "what are we working on?", "project status", or at the start of a session to check for ongoing work.
  <<TOOL:PNL_CHECK:WALLET_ADDRESS>> — Full PnL report for a Solana wallet. Shows SOL balance, all token holdings with current USD values, total portfolio value, and change since last check. Use when the user asks about wallet PnL, portfolio value, or how much a wallet is worth.
  <<TOOL:WATCH_WALLET:{"address":"...","label":"optional name"}>> — Add a wallet to the persistent watchlist (up to 20). Watched wallets are tracked for activity and included in the daily digest. Use when the user says "watch this wallet", "track this address", etc.
  <<TOOL:UNWATCH_WALLET:ADDRESS_OR_LABEL>> — Remove a wallet from the watchlist by address or label.
  <<TOOL:LIST_WATCHLIST>> — Show all wallets on the watchlist.
  <<TOOL:SET_DIGEST:{"hour":9,"minute":0,"enabled":true,"trackerInterval":5,"trackerEnabled":true,"minNotifyUsd":10}>> — Configure the daily digest AND wallet activity tracker. All fields are optional:
    - hour/minute: When the daily digest fires (24h format). ASK THE USER what time they want.
    - trackerInterval: How often (in minutes) to poll watchlist wallets for activity (1-60). ASK THE USER how often. No LLM cost.
    - trackerEnabled: Enable/disable the activity tracker separately from the digest.
    - minNotifyUsd: Minimum USD value of a token buy to trigger a notification (default $10). ASK THE USER their threshold.
    - enabled: Enable/disable the daily digest.
  <<TOOL:GET_DIGEST_CONFIG>> — Show current digest and tracker settings. Use when the user asks "what are my settings", "when is my digest", "how often are you checking", etc.
  <<TOOL:WALLET_ACTIVITY:ADDRESS_OR_LABEL_OR_ALL>> — Show recent tracked activity (buys, sells, SOL moves) for a specific wallet or all wallets. Use "all" to see everything. This data is collected by the tracker automatically with zero LLM cost.
  <<TOOL:PNL_CARD:MINT_ADDRESS>> — Generate a visual PnL card for a token the user has previously scanned/checked. Shows % change since first scan, entry vs current price, and a styled card with download button. When the tool returns successfully, you MUST include the following tag in your response exactly as shown (replace JSON with the actual card object from the tool result): <<PNL_CARD_DATA:{"symbol":"TOKEN","entryPrice":0.00042,"currentPrice":0.00102,"pctChange":142.5,"isGain":true,"scannedAt":"Feb 24, 2026","heldFor":"5d","via":"SCAN_TOKEN"}>>. The UI will render this as a beautiful styled card with a PNG download button. ALWAYS include this tag when PNL_CARD succeeds.
  <<TOOL:LIST_SCANS>> — List all tokens the user has previously scanned/price-checked, with entry prices and scan dates. Use this when the user says "show my scans", "what have I scanned", "my pnl" (without specifying a token), or when you need to find a mint address for a token they mentioned by name/ticker.
  <<TOOL:SET_MY_WALLET:WALLET_ADDRESS>> — Save the user's main Solana wallet. Once set, PnL cards will automatically show their actual holdings, SOL invested, and current value. Use when user says "set my wallet", "my wallet is ...", "this is my address", etc.
  <<TOOL:GET_MY_WALLET>> — Get the user's saved wallet address. Use to check if they've set a wallet before generating PnL cards.
  <<TOOL:SET_DEPLOYER_KEY:{"key":"<base58 private key>","pin":"<PIN>"}>> — Save an encrypted deployer wallet for on-chain operations (deploy, buy, sell on pump.fun). The private key is AES-256-GCM encrypted with the user's PIN and stored locally. The user should use a DEDICATED deployer wallet (NOT their main wallet) funded with just enough SOL. The PIN is required for every transaction.
  <<TOOL:GET_DEPLOYER_KEY>> — Get the deployer wallet's public address and SOL balance. Never reveals the private key.
  <<TOOL:PUMP_TOKEN_INFO:MINT_ADDRESS>> — Fetch detailed pump.fun token data: name, symbol, market cap, bonding curve state, graduation progress %, virtual/real reserves, creator, socials, and king-of-the-hill status. Use when user asks about a pump.fun token, wants bonding curve info, or graduation status.
  <<TOOL:PUMP_BUY:{"mint":"...","amount":0.1,"pin":"..."}>> — Buy tokens on pump.fun bonding curve. Amount is in SOL. Requires a deployer wallet (SET_DEPLOYER_KEY) and Solana RPC URL in settings. The transaction is signed locally and sent to chain. ALWAYS confirm the amount and token with the user before executing.
  <<TOOL:PUMP_SELL:{"mint":"...","amount":1000000,"pin":"..."}>> — Sell tokens on pump.fun bonding curve. Amount is in token units (not SOL). Requires deployer wallet. ALWAYS confirm with the user before selling.
  <<TOOL:PUMP_DEPLOY:{"name":"Token Name","symbol":"TICK","description":"...","pin":"...","initialBuy":0.1}>> — Deploy a NEW token on pump.fun. Creates the token, uploads metadata, and optionally buys on launch (initialBuy in SOL, 0 to skip). Requires deployer wallet. Optional fields: twitter, telegram, website, image (URL or data URL for the token image), mintKey (base58 secret key for a custom/vanity mint address — use if the user wants a specific contract address), uri (custom metadata URI — skips IPFS upload entirely). If pump.fun IPFS is down, metadata is automatically uploaded to a fallback host. ALWAYS confirm all details with the user before deploying.
  <<TOOL:X_PROFILE:username>> — Fetch a Twitter/X profile: name, bio, follower/following counts, join date, verified status, avatar, website. Useful for checking token dev accounts, KOLs, or researching projects. No auth required.
  <<TOOL:X_SEARCH:query>> — Search recent tweets by query. Returns up to 15 tweets with text, author, likes, retweets, timestamp. Use for sentiment analysis, memecoin research ("$TOKEN buzz"), or checking what people say about a project. Great for: "what are people saying about $BONK", "check twitter for [dev address]".
  <<TOOL:X_USER_TWEETS:username>> — Get a user's recent tweets (up to 15). Returns tweet text, engagement metrics, timestamps. Use for checking dev activity, KOL shill history, or project updates.

PUMP.FUN TRADING — on-chain operations via deployer wallet:
- The user sets up a DEDICATED deployer wallet with SET_DEPLOYER_KEY. This should be a separate wallet funded with only the SOL they want to risk.
- The private key is encrypted with a PIN using AES-256-GCM. The PIN is required for every transaction.
- ALWAYS confirm with the user before any on-chain action (buy, sell, deploy). Show the details and ask for explicit confirmation.
- After a successful deploy, share the pump.fun link and mint address.
- If the user asks to buy/sell without a deployer wallet set, guide them to set one up first.
- Use PUMP_TOKEN_INFO to check a token's bonding curve state before trading.

X/TWITTER RESEARCH — powered by XActions:
- Use X_PROFILE to check dev accounts, verify projects, or research KOLs.
- Use X_SEARCH for real-time sentiment on tokens, projects, or crypto topics. Include $CASHTAGS in queries for better results.
- Use X_USER_TWEETS to check a dev's recent activity or a KOL's shill history.
- When scanning a token, proactively check the dev's Twitter if a twitter link is available.
- Combine with other tools: scan a token → check dev twitter → analyze sentiment → give a comprehensive report.

PROJECT PLANNING — you track long-term work:
- When the user starts a multi-session project (e.g. "build me a token ecosystem", "create a portfolio site and iterate"), create a project plan with SET_GOAL.
- At the start of relevant conversations, use GET_GOALS to check for ongoing projects and proactively continue where you left off.
- After completing work, use UPDATE_GOAL to mark milestones done and add notes about what was accomplished.
- Project plans persist across sessions — they survive browser restarts.

WALLET TRACKING & DIGEST SETUP — always ask the user for their preferences:
- When the user asks to set up a digest, track wallets, or enable notifications, ALWAYS ask them:
  1. What time they want the daily digest (e.g. "8:30am", "7pm")
  2. How often to check wallets for activity (suggest 5, 10, or 15 min — explain there's no LLM cost)
  3. What dollar threshold for buy notifications (e.g. "$10", "$50", "$100")
- NEVER assume defaults without asking. Let the user configure everything.
- The wallet tracker runs WITHOUT any LLM calls — it's pure RPC + price API polling. Emphasize this when users worry about cost.
- When showing wallet activity, highlight significant moves: new token buys, large SOL transfers, tokens sold.
- Use GET_DIGEST_CONFIG to check current settings before changing them.

PNL CARDS — shareable visual PnL snapshots:
- Every time you scan a token, check a price, or fetch DexScreener data, the entry price is automatically recorded (first scan only).
- When the user asks "show my pnl", "how is X doing since I scanned it", "pnl card for X", or anything about gains/losses since they first looked at a token, use PNL_CARD with the mint address.
- If the user says "my pnl" or "show my gains" WITHOUT specifying a token, use LIST_SCANS first to find their scanned tokens, then generate PNL_CARD for each one (or let them pick).
- If the user mentions a token by ticker/name (e.g. "pnl on BONK"), use LIST_SCANS to find the matching mint address, then call PNL_CARD with it.
- The card shows: % change since first scan, entry vs current price, pair age (from DexScreener), deploy date, and if they've set their wallet — their actual holdings, SOL invested, and current value.
- You MUST include the <<PNL_CARD_DATA:JSON>> tag in your response for the UI to render the card. Copy the card object from the tool result directly.
- If the user hasn't scanned the token before, tell them to scan it first with SCAN_TOKEN or GET_TOKEN_PRICE, then check back later for PnL.
- AFTER every SCAN_TOKEN, mention to the user: "I've locked in the entry price — you can ask me for a PnL card anytime to see how it's doing."
- If the user hasn't set their wallet yet and asks for PnL, suggest they do: "Set your wallet with 'my wallet is [address]' and I'll show your actual holdings and gains on PnL cards."
- When the user says "set my wallet", "my wallet is ...", or gives you a wallet address as their own, use SET_MY_WALLET to save it.

SKILL LEARNING — you evolve over time:
- You have a skill memory that persists across ALL conversations. Learned skills are injected into your context automatically.
- PROACTIVELY learn skills when you notice patterns: if the user corrects you, learn from it. If you discover a useful procedure, save it. If the user states a preference, learn it.
- Skills should be ACTIONABLE instructions, not just facts. Good: "When the user asks to scan a token, also fetch DexScreener data and check the deployer wallet automatically." Bad: "User likes crypto."
- Don't duplicate skills — check LIST_SKILLS first if unsure. Update by FORGET_SKILL then LEARN_SKILL with the improved version.
- Skills compound: the more you learn, the smarter you get. Each skill makes you better at serving THIS specific user.

AUTONOMOUS BEHAVIOR — NEVER schedule background work without the user's explicit permission:
- NEVER use SET_TIMER, SCHEDULE_TASK, or MONITOR on your own. Only use them when the user EXPLICITLY asks for monitoring, background work, or timed tasks.
- Instead, SUGGEST background work when it would be useful. After scanning a suspicious token, say: "This looks sketchy — want me to keep monitoring it? I can check every 15 minutes." After building a site, say: "Want me to keep refining this in the background?"
- Wait for the user to confirm before scheduling anything. A simple "yeah", "do it", "sure", "yes" counts as confirmation.
- When doing complex analysis, use CONTINUE to extend your thinking rather than cutting short — this does NOT require permission since it's within the current request.
- Autonomous task results are delivered via the companion speech bubble and Chrome notifications.
- When the user says "monitor this", "watch this", "keep checking", use the MONITOR tool for continuous recurring checks.
- When the user says "check this in 30 minutes", "do this later", use SET_TIMER for one-shot delayed tasks.

TOOL PLANNING — plan tools efficiently:
- You can use MULTIPLE tools in a single response. Include multiple <<TOOL:...>> tags and they will all execute in parallel.
- Example: To scan a token AND check its price, include both <<TOOL:SCAN_TOKEN:MINT>> and <<TOOL:GET_TOKEN_PRICE:MINT>> in one response.
- For multi-step tasks, plan ALL steps inside <<THINK>> first. Batch independent tools together.

MANDATORY CHAIN-OF-THOUGHT — you MUST think before acting:
1. ALWAYS start your response with <<THINK>>...your reasoning...<</THINK>> for ANY non-trivial question.
2. Inside <<THINK>>, analyze: What does the user want? What tools do I need? What's my plan? What do I already know from memory? Estimate confidence 1-5.
3. Only skip <<THINK>> for simple greetings or one-word answers.
4. For multi-step tasks, plan ALL steps inside <<THINK>> first, then execute them one tool at a time.
5. You have up to 12 reasoning steps per request — use them.
6. If confidence < 3 on a factual claim, use WEB_SEARCH to verify before answering.

SELF-VERIFICATION — before giving your final answer:
- Re-read what the user asked. Does your answer actually address it?
- If you used tools, did the results make sense? Any contradictions?
- If you're unsure, say so. Never confidently state something you're not sure about.
- If results seem wrong or incomplete, try a different tool or approach.
- For token scans: always mention the risk score and any cross-reference overlaps with previous scans.

AUTO-CONTEXT — be proactive about the user's page:
- If page context mentions DexScreener, Birdeye, pump.fun, Jupiter, Solscan, Raydium → auto-detect mints and offer to scan.
- If page has $CASHTAGS or token names → identify them and offer price/scan info.
- If page has wallet addresses → offer to check balance/history.
- If the user pastes a URL → auto-FETCH_URL it and summarize.
- If page context shows a crypto-related page, proactively provide relevant analysis.

PROACTIVE INTELLIGENCE:
- Notice patterns: if the user keeps scanning tokens, offer a comparison. If they keep building sites, suggest improvements.
- Suggest next steps: after scanning a token, suggest checking the deployer wallet. After building a site, suggest deploying it.
- Cross-reference: if you scan a token and the deployer wallet matches one from a previous scan, flag it.
- Learn preferences: if the user likes dark mode sites, remember that. If they trade certain tokens, remember those.
- When the user's question is vague, make a best-effort attempt using context clues from the page and memory, rather than asking for clarification.

SMART SUGGESTIONS — offer background work, don't force it:
- After scanning a token with high risk or unusual patterns: "Want me to monitor this token? I can check every 15 minutes and alert you if holders or price change significantly."
- After checking a wallet with large holdings: "Want me to keep an eye on this wallet? I'll notify you if any big moves happen."
- After building a site: "Want me to keep refining this in the background? I can run another design critique and fix any issues."
- After a complex multi-tool analysis: "Want me to schedule a follow-up check in an hour to see if anything changed?"
- ALWAYS phrase as a question. NEVER schedule without confirmation. The user's API credits are at stake.

RULES:
- When you see tokens/mints on screen, auto-detect and offer to scan.
- When the user wants to launch/deploy a token, use PREPARE_LAUNCH.
- When the user wants a website, use BUILD_SITE. When editing, use EDIT_SITE (never describe changes in text).
- When the user says "deploy", "put it live", "push to netlify", or "launch the site" — use DEPLOY_SITE. You can chain BUILD_SITE → DEPLOY_SITE to build and deploy in one go.
- When the user asks to see/list/manage their sites or delete old deploys, use LIST_SITES first to show them all sites, then DELETE_SITE for any they want removed. ALWAYS confirm which sites before deleting.
- When the user asks what you see, use SCREENSHOT.
- When the user asks "who is this?", "identify this person/meme", "reverse image search", or wants to identify people/logos/memes on screen, use REVERSE_IMAGE_SEARCH. It captures the screen, describes what it sees, then searches the web to identify it.
- For prices/news/real-time info, use WEB_SEARCH or GET_TOKEN_PRICE.
- When the user shares a URL, use FETCH_URL to read it.
- For wallet analysis, chain GET_WALLET_BALANCE → GET_WALLET_HISTORY for a complete picture.
- To compare tokens, use MULTI_SCAN instead of scanning one at a time.
- ONLY output the tool tag and a brief note when using a tool. I execute it and return the result.
- Be concise, direct, and crypto-savvy. Use memory to personalize.
- Page context (URL, title, visible text) is in [brackets] with each message.
- When the user asks to set an alert, watch a price, or monitor a wallet, use SET_ALERT.
- When the user says "remind me", "check back in", "in X minutes/hours", use REMIND_ME for simple notifications or SET_TIMER for tasks that need intelligent execution.
- Use SET_TIMER when the user wants you to DO something later (research, check, analyze). Use REMIND_ME when they just want a notification.
- Use SCHEDULE_TASK ONLY when the user explicitly asks for background work. NEVER schedule tasks on your own — suggest them instead and wait for confirmation.
- When the user says "monitor this", "watch this token", "keep an eye on this", use MONITOR for recurring checks. When they say "stop monitoring", use STOP_MONITOR.
- Use CONTINUE when you need more reasoning steps — don't cut complex analysis short.
- When the user corrects you, states a preference, or you discover a useful procedure, use LEARN_SKILL to remember it permanently. When the user asks "what have you learned?" or "show your skills", use LIST_SKILLS. When the user says "forget that" or "unlearn", use FORGET_SKILL.
- Use SEARCH_MEMORY when the user asks "do you remember", "what do you know about", or references past conversations vaguely.
- Use DEX_DATA for detailed market data (volume, liquidity, pair age, chart preview). ALWAYS show the chartImageUrl as ![chart](url) so the user sees the chart inline. Combine with GET_TOKEN_PRICE for complete analysis.
- Format responses with **bold** for emphasis, bullet points for lists, and \`code\` for addresses/mints. Your responses will be rendered as markdown.`;

/* ── Proactive Briefing Generator ── */
async function generateBriefing(settings) {
  try {
    const parts = [];
    const { urchinPriceHistory = {}, urchinWatches = [], urchinProfile = {} } = await chrome.storage.local.get(['urchinPriceHistory', 'urchinWatches', 'urchinProfile']);

    for (const [mint, data] of Object.entries(urchinPriceHistory).slice(-5)) {
      try {
        const current = await getTokenPrice(mint, settings);
        if (current.price) {
          const delta = ((parseFloat(current.price) - data.price) / data.price * 100).toFixed(2);
          parts.push(`**${current.symbol || mint.slice(0, 8)}**: $${current.price} (${delta > 0 ? '+' : ''}${delta}% since last check)`);
        }
      } catch (_) {}
    }

    if (urchinWatches.length > 0) parts.push(`\n📡 **${urchinWatches.length} active alert(s)** monitoring`);

    if (Object.keys(urchinProfile).length > 0) {
      const wallets = Object.entries(urchinProfile).filter(([k]) => /wallet|address/i.test(k));
      for (const [, addr] of wallets.slice(0, 2)) {
        try {
          if (!settings.solanaRpc) continue;
          const bal = await getWalletBalance(addr, settings.solanaRpc);
          parts.push(`👛 Wallet ${addr.slice(0, 6)}…: **${bal.solBalance.toFixed(4)} SOL** + ${bal.topTokens.length} tokens`);
        } catch (_) {}
      }
    }

    return parts.length > 0 ? '🌅 **Briefing**\n' + parts.join('\n') : null;
  } catch (_) { return null; }
}

const SITE_BUILDER_PROMPT = `You are urchinbot's site builder — an elite web designer and developer. Build a STUNNING, production-quality static website.

OUTPUT FORMAT — ONLY valid JSON, no markdown, no commentary:
{"projectName":"kebab-case-name","files":[{"path":"index.html","content":"..."},{"path":"styles.css","content":"..."},{"path":"app.js","content":"..."}],"notes":["..."]}

DESIGN STANDARDS — every site you build must have:
- Beautiful, modern design with strong visual hierarchy
- Smooth animations and micro-interactions (CSS transitions, scroll effects, hover states)
- Fully responsive (mobile-first, looks great 320px-2560px)
- Rich color palette with gradients, not flat boring colors
- Professional typography with proper font sizing/spacing (use system fonts or Google Fonts via @import in CSS)
- Subtle glassmorphism, shadows, or depth effects where appropriate
- Proper semantic HTML5 (header, main, section, footer, nav)
- Dark mode aware (prefers-color-scheme media query)
- Accessible (alt text, aria labels, proper contrast)
- Hero sections with engaging headlines and CTAs
- Smooth scroll behavior
- Loading animations or entrance effects

TECHNICAL RULES:
- ONLY files: index.html, styles.css, app.js
- index.html MUST link styles.css and app.js via relative paths
- ALL styling in styles.css (not inline), ALL JS in app.js (not inline)
- NO external script/CDN imports (except Google Fonts @import in CSS is OK)
- NO analytics/tracking code
- Make interactive elements WORK (buttons, nav links, scroll-to-section, toggles)
- Use CSS custom properties for theming
- Total under 400KB

You are NOT building a basic template. You are building something a designer would be proud of.`;

const SITE_EDITOR_PROMPT = `You are urchinbot's site editor — an elite web developer editing an existing website. You will receive the current project files and a description of changes.

OUTPUT FORMAT — ONLY valid JSON with the COMPLETE updated project (all files, even unchanged ones):
{"projectName":"string","files":[{"path":"index.html","content":"..."},{"path":"styles.css","content":"..."},{"path":"app.js","content":"..."}],"notes":["what changed"]}

RULES:
- Return ALL files, with the requested changes applied
- Keep everything that works — only change what was requested
- Maintain the existing design quality and consistency
- If adding new sections, match the existing style
- ONLY files: index.html, styles.css, app.js
- NO external scripts (Google Fonts @import OK)
- No markdown, no commentary outside JSON`;

const SYSTEM_PROMPT_PUMP = `You are urchinbot's pump.fun launch packet generator. Create a complete launch preparation packet. Output ONLY valid JSON with this schema:
{"tokenName":"string","tokenSymbol":"string","description":"string","website":{"projectName":"string","files":[{"path":"index.html","content":"..."},{"path":"styles.css","content":"..."},{"path":"app.js","content":"..."}],"notes":[]},"imageGuidance":"string","checklist":["step1","step2","..."],"disclaimers":["..."]}
Rules:
- tokenSymbol should be uppercase, 3-8 chars
- website follows same rules as BUILD_SITE
- checklist must include steps the user does manually on pump.fun
- Include disclaimers about DYOR and risk
- NEVER claim to actually deploy anything
No markdown. No commentary outside JSON.`;

/* ── Site Builder/Editor helpers ── */
const SELF_REFLECT_PROMPT = `You are a senior web design critic. Review this website code and return ONLY valid JSON:
{"score":1-10,"issues":["issue1","issue2"],"fixes":"specific changes to make"}
Be harsh. Check for: missing responsive design, poor color contrast, no animations/transitions, bad typography, broken layouts, missing hover states, no dark mode, accessibility issues, ugly or generic design. If score >= 8, set fixes to "none".`;

function extractJSON(raw) {
  let cleaned = raw.replace(/```json\s*/g, '').replace(/```\s*/g, '').trim();
  try { return JSON.parse(cleaned); } catch (_) {}

  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start !== -1 && end > start) {
    try { return JSON.parse(cleaned.slice(start, end + 1)); } catch (_) {}
  }

  const codeBlock = raw.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (codeBlock) {
    try { return JSON.parse(codeBlock[1].trim()); } catch (_) {}
  }

  const braceDepth = [];
  let objStart = -1;
  for (let i = 0; i < raw.length; i++) {
    if (raw[i] === '{') { if (objStart === -1) objStart = i; braceDepth.push(i); }
    else if (raw[i] === '}') {
      braceDepth.pop();
      if (braceDepth.length === 0 && objStart !== -1) {
        try { return JSON.parse(raw.slice(objStart, i + 1)); } catch (_) { objStart = -1; }
      }
    }
  }
  return null;
}

async function buildSiteViaLLM(description, extraContext, settings, addStep, maxAttempts = 2, uploadedFiles, skipReflection = false) {
  let project = null;
  let lastError = '';
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    addStep('build_call', { attempt: attempt + 1 });
    try {
      const prompt = attempt === 0
        ? description + (extraContext || '')
        : `${description}\n\nPrevious attempt failed validation. Return ONLY valid JSON matching the schema. No markdown wrapping.`;
      const raw = await callLLM(SITE_BUILDER_PROMPT, prompt, settings);
      addStep('build_response', { length: raw.length });
      project = extractJSON(raw);
      if (!project) {
        lastError = `Could not extract JSON (response was ${raw.length} chars, starts with: "${raw.slice(0, 120)}...")`;
        addStep('build_error', { attempt: attempt + 1, error: lastError });
        continue;
      }
      const validation = tools.validateProjectFiles(project);
      addStep('build_validate', validation);
      if (validation.ok || project.files) break;
      lastError = `Validation failed: ${(validation.errors || []).join(', ')}`;
    } catch (e) {
      lastError = e.message;
      addStep('build_error', { attempt: attempt + 1, error: e.message });
    }
  }
  if (!project || !project.files) return { _buildError: lastError || 'Unknown build error' };

  // Inject uploaded images into the HTML as data URLs
  if (uploadedFiles && uploadedFiles.length > 0) {
    const imageFiles = uploadedFiles.filter(f => f.type && f.type.startsWith('image/') && f.dataUrl);
    if (imageFiles.length > 0) {
      const htmlFile = project.files.find(f => f.path === 'index.html');
      if (htmlFile) {
        for (const img of imageFiles) {
          const placeholderPatterns = [
            /src\s*=\s*["'](?:https?:\/\/[^"']*placeholder[^"']*|#IMAGE#|IMAGE_URL|placeholder\.[a-z]+)["']/gi,
            /src\s*=\s*["'](?:https?:\/\/via\.placeholder[^"']*)["']/gi,
          ];
          let replaced = false;
          for (const pattern of placeholderPatterns) {
            if (pattern.test(htmlFile.content)) {
              htmlFile.content = htmlFile.content.replace(pattern, `src="${img.dataUrl}"`);
              replaced = true;
              break;
            }
          }
          if (!replaced) {
            const firstImgTag = htmlFile.content.match(/<img[^>]*src\s*=\s*["']([^"']+)["'][^>]*>/i);
            if (firstImgTag && !firstImgTag[1].startsWith('data:')) {
              htmlFile.content = htmlFile.content.replace(firstImgTag[1], img.dataUrl);
            }
          }
        }
      }
    }
  }

  if (skipReflection) return project;

  try {
    addStep('reflect_start', {});
    const siteCode = project.files.map(f => `--- ${f.path} ---\n${f.content}`).join('\n\n');
    const critiqueRaw = await callLLM(SELF_REFLECT_PROMPT, `Original request: "${description}"\n\n${siteCode}`, settings);
    const critique = extractJSON(critiqueRaw);
    if (!critique) throw new Error('Could not parse critique');
    addStep('reflect_result', { score: critique.score, issues: critique.issues?.length || 0 });

    if (critique.score < 8 && critique.fixes && critique.fixes !== 'none') {
      addStep('reflect_fix', { fixes: critique.fixes.slice(0, 200) });
      const fixPrompt = `Original request: "${description}"\n\nCurrent site code:\n${siteCode}\n\nCritique (score ${critique.score}/10):\nIssues: ${(critique.issues || []).join('; ')}\nFixes needed: ${critique.fixes}\n\nApply ALL fixes and return the improved project as valid JSON. Same schema.`;
      const fixRaw = await callLLM(SITE_BUILDER_PROMPT, fixPrompt, settings);
      const fixedProject = extractJSON(fixRaw);
      if (fixedProject && fixedProject.files) {
        addStep('reflect_improved', { oldScore: critique.score });
        return fixedProject;
      }
    }
  } catch (e) {
    addStep('reflect_skip', { error: e.message });
  }

  return project;
}

async function editSiteViaLLM(currentProject, changes, settings, addStep) {
  const filesDesc = currentProject.files.map(f =>
    `--- ${f.path} ---\n${f.content}`
  ).join('\n\n');
  const prompt = `Current project "${currentProject.projectName}":\n\n${filesDesc}\n\n---\nRequested changes: ${changes}`;

  for (let attempt = 0; attempt < 2; attempt++) {
    addStep('edit_call', { attempt: attempt + 1 });
    try {
      const raw = await callLLM(SITE_EDITOR_PROMPT, prompt, settings);
      addStep('edit_response', { length: raw.length });
      const project = extractJSON(raw);
      if (!project) { addStep('edit_error', { attempt: attempt + 1, error: 'Could not extract valid JSON' }); continue; }
      const validation = tools.validateProjectFiles(project);
      addStep('edit_validate', validation);
      if (validation.ok) return project;
      if (!validation.ok && project.files) return project;
    } catch (e) {
      addStep('edit_error', { attempt: attempt + 1, error: e.message });
    }
  }
  return null;
}

/* ── UrchinLoop Core ── */
async function urchinLoop(task, userInput, context, settings, pageContext, history, uploadedFiles) {
  const requestId = `ul-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  const log = { requestId, task, steps: [], startTime: Date.now(), _pageContext: pageContext, _history: history };

  const addStep = (type, data) => {
    log.steps.push({ type, data, time: Date.now() });
  };

  addStep('init', { task, inputLength: userInput.length, contextItems: context.length });

  if (!settings.llmApiKey) {
    addStep('error', { message: 'No LLM API key configured. Go to Settings.' });
    return { requestId, success: false, error: 'No LLM API key configured.', log };
  }

  let systemPrompt;
  switch (task) {
    case 'ASK': systemPrompt = SYSTEM_PROMPT_ASK; break;
    case 'BUILD_SITE': systemPrompt = SITE_BUILDER_PROMPT; break;
    case 'PUMPFUN_LAUNCH_PACKET': systemPrompt = SYSTEM_PROMPT_PUMP; break;
    case 'SOLANA_SCAN':
      return await handleSolanaScan(userInput, context, settings, log, addStep, requestId);
    default:
      return { requestId, success: false, error: `Unknown task: ${task}`, log };
  }

  let contextStr = '';
  if (context.length > 0) {
    contextStr = '\n\nCaptured context:\n' + context.map(c => `[${c.type}] ${c.value}`).join('\n');
  }

  let result = null;

  /* ═══ ASK: agentic loop with tool calling + conversation memory ═══ */
  if (task === 'ASK') {
    const messages = [];

    // ──── LAYER 1: Rolling condensation (compressed history older than 30 msgs) ────
    try {
      const { urchinCondensed } = await chrome.storage.local.get('urchinCondensed');
      if (urchinCondensed && urchinCondensed.length > 0) {
        messages.push({ role: 'user', content: `[Previous conversation history (condensed):\n${urchinCondensed}]` });
        messages.push({ role: 'assistant', content: 'Understood — I remember our previous conversations.' });
      }
    } catch (_) {}

    // ──── LAYER 2: Recent chat history (last 30 messages — full fidelity) ────
    const hist = log._history || [];
    for (const h of hist.slice(-30)) {
      messages.push({ role: h.role === 'user' ? 'user' : 'assistant', content: h.text });
    }

    // ──── LAYER 3: Build current user message with rich page context ────
    let userMsg = '';
    const pc = log._pageContext;
    if (pc) {
      userMsg += `[Page: ${pc.title || ''} — ${pc.url || ''}]\n`;
      if (pc.selection) userMsg += `[Selected text: ${pc.selection}]\n`;
      if (pc.tweets) userMsg += `[Visible tweets:\n${pc.tweets}]\n`;
      else if (pc.visibleText) userMsg += `[Page content: ${pc.visibleText.slice(0, 3000)}]\n`;
      if (pc.dexPairs) userMsg += `[DEX pairs visible: ${pc.dexPairs}]\n`;
      if (pc.pumpFormData) userMsg += `[Pump.fun form data: ${pc.pumpFormData}]\n`;
      if (pc.cryptoLinks) userMsg += `[Crypto links on page:\n${pc.cryptoLinks}]\n`;
    }

    try {
      const { urchinCurrentProject } = await chrome.storage.local.get('urchinCurrentProject');
      if (urchinCurrentProject && urchinCurrentProject.files) {
        const fileList = urchinCurrentProject.files.map(f => f.path).join(', ');
        userMsg += `[Current project: "${urchinCurrentProject.projectName || 'untitled'}" with files: ${fileList}]\n`;
      }
    } catch (_) {}

    if (contextStr) userMsg += contextStr + '\n';
    userMsg += '\n' + userInput;
    messages.push({ role: 'user', content: userMsg.trim() });

    const toolRe = /<<TOOL:(\w+)(?::([\s\S]+?))?>>/;
    const thinkRe = /<<THINK>>([\s\S]+?)<<\/THINK>>/;
    let finalAnswer = '';
    const pendingPnlCards = [];

    // ──── LAYERS 4-7: Parallel storage load for profile, memory, skills, projects ────
    let activeSkillNames = [];
    try {
      const [{ urchinProfile = {} }, { urchinMemory = {} }, { urchinSkills = [] }, { urchinProjects = {} }] = await Promise.all([
        chrome.storage.local.get('urchinProfile'),
        chrome.storage.local.get('urchinMemory'),
        chrome.storage.local.get('urchinSkills'),
        chrome.storage.local.get('urchinProjects'),
      ]);

      // Layer 4: User profile (capped at 50 keys)
      if (Object.keys(urchinProfile).length > 0) {
        const profileEntries = Object.entries(urchinProfile);
        const capped = profileEntries.slice(-50);
        if (profileEntries.length > 50) {
          const pruned = Object.fromEntries(capped);
          chrome.storage.local.set({ urchinProfile: pruned });
        }
        const profileStr = capped.map(([k, v]) => `  ${k}: ${v}`).join('\n');
        messages[messages.length - 1].content += `\n\n[User profile (permanent):\n${profileStr}]`;
      }

      // Layer 5: Relevance-filtered session summaries + manual memories
      const manualKeys = Object.keys(urchinMemory).filter(k => !k.startsWith('session_') && !k.startsWith('_'));
      if (manualKeys.length > 100) {
        const toRemove = manualKeys.slice(0, manualKeys.length - 100);
        for (const k of toRemove) delete urchinMemory[k];
        chrome.storage.local.set({ urchinMemory });
      }

      const sessionKeys = Object.keys(urchinMemory).filter(k => k.startsWith('session_')).sort().reverse();
      const sessionEntries = {};
      for (const k of sessionKeys.slice(0, 20)) sessionEntries[k] = urchinMemory[k];

      const manualEntries = {};
      const currentManualKeys = Object.keys(urchinMemory).filter(k => !k.startsWith('session_') && !k.startsWith('_'));
      for (const k of currentManualKeys) manualEntries[k] = urchinMemory[k];

      const allMemEntries = { ...sessionEntries, ...manualEntries };
      const totalEntries = Object.keys(allMemEntries).length;

      if (totalEntries <= 6) {
        if (sessionKeys.length > 0) {
          const sessStr = sessionKeys.slice(0, 10).map(k => urchinMemory[k]).join('\n---\n');
          messages[messages.length - 1].content += `\n\n[Past session summaries:\n${sessStr}]`;
        }
        if (currentManualKeys.length > 0) {
          const manStr = currentManualKeys.map(k => `  ${k}: ${urchinMemory[k]}`).join('\n');
          messages[messages.length - 1].content += `\n\n[Saved memories:\n${manStr}]`;
        }
      } else {
        const relevant = await relevanceFilterMemories(userInput, allMemEntries, settings, 10);
        const relevantSessions = relevant.filter(r => r.key.startsWith('session_'));
        const relevantManual = relevant.filter(r => !r.key.startsWith('session_'));

        const sessionSet = new Set(relevantSessions.map(r => r.key));
        if (sessionKeys[0]) sessionSet.add(sessionKeys[0]);

        if (sessionSet.size > 0) {
          const sessStr = [...sessionSet].map(k => urchinMemory[k]).filter(Boolean).join('\n---\n');
          messages[messages.length - 1].content += `\n\n[Relevant session summaries (${sessionSet.size}/${sessionKeys.length} total):\n${sessStr}]`;
        }
        if (relevantManual.length > 0) {
          const manStr = relevantManual.map(r => `  ${r.key}: ${r.value}`).join('\n');
          messages[messages.length - 1].content += `\n\n[Relevant memories (${relevantManual.length}/${currentManualKeys.length} total):\n${manStr}]`;
        } else if (currentManualKeys.length > 0 && currentManualKeys.length <= 10) {
          const manStr = currentManualKeys.map(k => `  ${k}: ${urchinMemory[k]}`).join('\n');
          messages[messages.length - 1].content += `\n\n[Saved memories:\n${manStr}]`;
        }
      }

      // Layer 6: Learned skills
      const viable = urchinSkills.filter(s => (s.score ?? 50) > 15);
      if (viable.length > 0) {
        const skillBlock = viable.map(s => {
          s.usageCount = (s.usageCount || 0) + 1;
          s.lastUsedAt = Date.now();
          return `  • ${s.name} [score:${s.score ?? 50}]: ${s.instruction}`;
        }).join('\n');
        activeSkillNames = viable.map(s => s.name);
        messages[messages.length - 1].content += `\n\n[Learned skills (apply these):\n${skillBlock}]`;
        chrome.storage.local.set({ urchinSkills });
      }

      // Layer 7: Active project plans
      const active = Object.entries(urchinProjects).filter(([_, p]) => {
        const allDone = p.milestones.every(m => m.status === 'done');
        const stale = Date.now() - p.updatedAt > 60 * 24 * 60 * 60 * 1000;
        return !allDone && !stale;
      });
      if (active.length > 0) {
        const planBlock = active.map(([name, p]) => {
          const ms = p.milestones.map(m => `    ${m.status === 'done' ? '✓' : m.status === 'active' ? '►' : m.status === 'blocked' ? '✗' : '○'} ${m.name} (${m.status})${m.notes ? ` — ${m.notes.slice(0, 100)}` : ''}`).join('\n');
          return `  ${name}: ${p.milestones.filter(m => m.status === 'done').length}/${p.milestones.length} done\n${ms}`;
        }).join('\n');
        messages[messages.length - 1].content += `\n\n[Active project plans — continue these when relevant:\n${planBlock}]`;
      }
    } catch (_) {}

    // ──── AUTO-CONTEXT: detect page type and inject smart hints ────
    const pc2 = log._pageContext;
    if (pc2 && pc2.url) {
      const pageData = parsePageForCryptoData(pc2.url, pc2.visibleText || '');
      if (pageData.pageType !== 'unknown') {
        let hint = `[Auto-detected page type: ${pageData.pageType}]`;
        if (pageData.addresses.length > 0) hint += `\n[Detected mint addresses on page: ${pageData.addresses.slice(0, 5).join(', ')}]`;
        if (pageData.tokens.length > 0) hint += `\n[Detected token cashtags: ${pageData.tokens.join(', ')}]`;
        if (pageData.prices.length > 0) hint += `\n[Prices visible: ${pageData.prices.slice(0, 5).join(', ')}]`;
        messages[messages.length - 1].content += '\n' + hint;
      }
    }

    // ──── CONTEXT BUDGET: trim messages to stay within limits ────
    trimMessagesToBudget(messages);

    // ──── GOAL DECOMPOSITION: break multi-phase tasks into subtask chains ────
    let decomposed = false;
    try {
      const connectorCount = (userInput.match(/\b(and then|then|after that|next|finally|afterwards|once that's done|once done)\b/gi) || []).length;
      const hasDistinctPhases = connectorCount >= 2 || (connectorCount >= 1 && userInput.trim().length > 200);
      if (hasDistinctPhases && !/^(hi|hey|hello|what|who|how much|price|gm|remember|recall|forget|list|show|stop)/i.test(userInput.trim())) {
        const planPrompt = `Decide if this request needs to be broken into subtasks. A request needs decomposition ONLY if it has multiple INDEPENDENT phases that produce different outputs (e.g. "research X, then build a site about it"). Single tasks, even complex ones, should NOT be decomposed.

User request: "${userInput.slice(0, 500)}"

If decomposition is needed, output JSON: {"decompose":true,"subtasks":[{"task":"description","dependsOn":[]},...]}
Rules:
- Max 4 subtasks
- Each subtask must be self-contained and actionable
- dependsOn is an array of 0-indexed subtask numbers this one needs results from
- If the request is a single task (even a complex one), output: {"decompose":false}
Output ONLY valid JSON.`;
        const planRaw = await callLLMChat('Output ONLY JSON. No explanation.', [{ role: 'user', content: planPrompt }], settings);
        const plan = JSON.parse(planRaw.replace(/```json\s*/g, '').replace(/```/g, '').trim());

        if (plan?.decompose && Array.isArray(plan.subtasks) && plan.subtasks.length >= 2 && plan.subtasks.length <= 4) {
          decomposed = true;
          addStep('goal_decompose', { subtaskCount: plan.subtasks.length, subtasks: plan.subtasks.map(s => s.task) });
          broadcastProgress({ phase: 'decomposing', subtasks: plan.subtasks.map(s => s.task) });

          const subtaskResults = [];
          for (let si = 0; si < plan.subtasks.length; si++) {
            const st = plan.subtasks[si];
            let subtaskContext = st.task;
            if (st.dependsOn && st.dependsOn.length > 0) {
              const priorResults = st.dependsOn
                .filter(d => d < si && subtaskResults[d])
                .map(d => `[Result from step ${d + 1}]: ${subtaskResults[d].slice(0, 2000)}`)
                .join('\n');
              subtaskContext += `\n\nContext from previous steps:\n${priorResults}`;
            }
            addStep('subtask_start', { index: si, task: st.task });
            broadcastProgress({ phase: 'subtask', index: si, total: plan.subtasks.length, task: st.task });

            try {
              const subResult = await urchinLoop('ASK', subtaskContext, context, settings, pageContext, history, uploadedFiles);
              const answer = subResult?.data?.answer || subResult?.error || 'No result';
              subtaskResults.push(answer);
              addStep('subtask_done', { index: si, answerLength: answer.length });
            } catch (e) {
              subtaskResults.push(`Subtask failed: ${e.message}`);
              addStep('subtask_error', { index: si, error: e.message });
            }
          }

          const synthesisPrompt = `You executed a multi-step plan for the user. Synthesize the results into a single coherent response.

Original request: "${userInput.slice(0, 500)}"

Step results:
${plan.subtasks.map((st, i) => `Step ${i + 1} (${st.task}): ${(subtaskResults[i] || 'No result').slice(0, 2000)}`).join('\n\n')}

Write a unified response that presents all results clearly. If any step failed, note it briefly. Be concise.`;
          const synthesis = await callLLMChat(systemPrompt, [...messages, { role: 'user', content: synthesisPrompt }], settings);
          finalAnswer = synthesis;
          broadcastProgress({ phase: 'done', answer: finalAnswer });
        }
      }
    } catch (_) {
      decomposed = false;
    }

    // ──── SELF-ROUTING: classify simple vs complex to skip unnecessary loop steps ────
    let maxSteps = 12;
    if (!decomposed) try {
      const routePrompt = 'Classify this user message. Reply with EXACTLY one word: SIMPLE if it is a greeting, identity question, opinion, memory recall, or general knowledge question that needs NO tools. Reply COMPLEX if it needs any tool call (search, scan, screenshot, build, deploy, fetch, wallet, price lookup, image identification) or multi-step reasoning.';
      const lastMsg = messages[messages.length - 1].content.slice(-600);
      const routeResult = await callLLMChat(routePrompt, [{ role: 'user', content: lastMsg }], settings);
      const classification = routeResult.trim().toUpperCase();
      if (classification.includes('SIMPLE')) {
        maxSteps = 1;
        addStep('route', { classification: 'SIMPLE', maxSteps: 1 });
      } else {
        addStep('route', { classification: 'COMPLEX', maxSteps: 12 });
      }
    } catch (_) {
      addStep('route', { classification: 'FALLBACK_COMPLEX', maxSteps: 12 });
    }

    if (!decomposed) broadcastProgress({ phase: 'routing_done', maxSteps });

    for (let step = 0; step < (decomposed ? 0 : maxSteps); step++) {
      addStep('agent_call', { step: step + 1, maxSteps, msgCount: messages.length });
      broadcastProgress({ phase: 'llm_call', step: step + 1, maxSteps });
      try {
        let raw = '';
        const isLastChance = step === maxSteps - 1;
        const useStreaming = maxSteps === 1 || isLastChance;
        if (useStreaming) {
          try {
            let streamedHasTools = false;
            raw = await callLLMChatStream(systemPrompt, messages, settings, (chunk, full) => {
              if (!streamedHasTools && /<<TOOL:/.test(full)) streamedHasTools = true;
              if (!streamedHasTools) broadcastProgress({ phase: 'streaming', chunk, fullSoFar: full });
            });
          } catch (_streamErr) {
            raw = await callLLMChat(systemPrompt, messages, settings);
          }
        } else {
          raw = await callLLMChat(systemPrompt, messages, settings);
        }
        addStep('agent_response', { length: raw.length, preview: raw.slice(0, 200) });

        let thinkContent = '';
        const thinkMatch = raw.match(thinkRe);
        if (thinkMatch) {
          thinkContent = thinkMatch[1].trim();
          addStep('agent_think', { thought: thinkContent.slice(0, 500) });
        }
        const cleanedRaw = raw.replace(thinkRe, '').trim();

        // ──── PARALLEL TOOL EXECUTION: detect all tool tags ────
        const toolReGlobal = /<<TOOL:(\w+)(?::([\s\S]+?))?>>/g;
        const allMatches = [...cleanedRaw.matchAll(toolReGlobal)];

        if (allMatches.length > 0) {
          if (maxSteps === 1) { maxSteps = 12; addStep('route_upgrade', { reason: 'tool_detected' }); }

          const toolJobs = allMatches.map(m => ({ toolName: m[1], toolParam: m[2] || '' }));
          addStep('tool_calls', { count: toolJobs.length, tools: toolJobs.map(j => j.toolName) });
          broadcastProgress({ phase: 'tools', tools: toolJobs.map(j => j.toolName) });

          const executeToolJob = async ({ toolName, toolParam }) => {
            let toolResult;
            try {
              switch (toolName) {
              case 'SCAN_TOKEN': {
                if (!settings.solanaRpc) throw new Error('No Solana RPC configured');
                const scanRes = await tools.solanaScanMint(toolParam.trim(), settings.solanaRpc);
                scanRes.riskScore = computeRiskScore(scanRes);
                const overlaps = await crossReferenceScan(scanRes);
                if (overlaps) scanRes.crossRef = overlaps;
                try { const sp = await getTokenPrice(toolParam.trim(), settings); if (sp.price) await recordFirstScan(toolParam.trim(), sp.price, sp.symbol, 'SCAN_TOKEN'); } catch (_) {}
                return scanRes;
              }
              case 'DETECT_MINTS':
                return tools.detectSolanaMints(toolParam);
              case 'PREPARE_LAUNCH': {
                const cleaned = toolParam.replace(/```json\s*/g, '').replace(/```/g, '').trim();
                const launchInfo = JSON.parse(cleaned);
                await chrome.storage.local.set({ urchinLaunchData: { ...launchInfo, ts: Date.now() } });
                return { success: true, message: `Launch packet prepared: ${launchInfo.name} ($${launchInfo.symbol}). Deploy tab is ready.` };
              }
              case 'BUILD_SITE': {
                const buildReq = extractJSON(toolParam) || { description: toolParam.trim() };
                let imgContext = '';
                if (uploadedFiles && uploadedFiles.length > 0) {
                  const imageFiles = uploadedFiles.filter(f => f.type && f.type.startsWith('image/'));
                  if (imageFiles.length > 0) {
                    imgContext = '\n\nIMAGES AVAILABLE — embed these directly in the HTML using data URLs or as img src:\n' +
                      imageFiles.map(f => `- ${f.name} (${f.type}): use this data URL as the src → ${f.dataUrl.slice(0, 100)}...`).join('\n') +
                      '\nIMPORTANT: Use the FULL data URL (provided below) as the src attribute for <img> tags. Do NOT use placeholder URLs.';
                  }
                }
                const buildResult = await buildSiteViaLLM(buildReq.description || userInput, contextStr + imgContext, settings, addStep, 1, uploadedFiles);
                if (buildResult && buildResult.files) {
                  await chrome.storage.local.set({ urchinCurrentProject: buildResult });
                  return { success: true, projectName: buildResult.projectName, files: buildResult.files.map(f => f.path), message: 'Site built and saved. Visible in Build tab.' };
                }
                return { error: `Build failed: ${buildResult?._buildError || 'LLM did not return valid project JSON'}` };
              }
              case 'EDIT_SITE': {
                const editReq = extractJSON(toolParam) || { changes: toolParam.trim() };
                const { urchinCurrentProject: currentProj } = await chrome.storage.local.get('urchinCurrentProject');
                if (!currentProj) return { error: 'No current project to edit. Build one first.' };
                const editResult = await editSiteViaLLM(currentProj, editReq.changes, settings, addStep);
                if (editResult) {
                  await chrome.storage.local.set({ urchinCurrentProject: editResult });
                  return { success: true, projectName: editResult.projectName, message: 'Site updated. Changes visible in Build tab.' };
                }
                return { error: 'Edit failed — LLM did not return valid project JSON' };
              }
              case 'SCREENSHOT': {
                try {
                  const screenshot = await captureScreenshot();
                  const visionResult = await callLLMVision(
                    'Describe what you see on this webpage screenshot. Focus on: layout, key content, any crypto/token related info, wallet addresses, prices, charts, or relevant data. Be concise and factual.',
                    'What do you see on this page?', screenshot, settings);
                  return { success: true, description: visionResult };
                } catch (e) { return { error: `Screenshot failed: ${e.message}` }; }
              }
              case 'REVERSE_IMAGE_SEARCH': {
                try {
                  addStep('reverse_img', { phase: 'capturing' });
                  const screenshot = await captureScreenshot();
                  addStep('reverse_img', { phase: 'analyzing' });
                  const visionDesc = await callLLMVision(
                    `You are an image identification expert. Analyze this screenshot and provide DETAILED descriptions for reverse-searching:\n1. PEOPLE: Describe each person visible.\n2. TEXT: Transcribe ALL visible text exactly.\n3. LOGOS/BRANDS: Describe any logos or brand imagery.\n4. MEMES: Describe meme format/template and text overlays.\n5. CONTEXT: What platform? Overall scene?\n\nOutput JSON: {"people":[],"text":[],"searchQueries":[],"platform":"","description":""}`,
                    'Identify everything in this image for reverse search purposes.', screenshot, settings);
                  addStep('reverse_img', { phase: 'searching', visionLength: visionDesc.length });
                  let parsed;
                  try { parsed = JSON.parse(visionDesc.replace(/```json\s*/g, '').replace(/```/g, '').trim()); }
                  catch (_) { parsed = { searchQueries: [visionDesc.slice(0, 200)], description: visionDesc }; }
                  const allResults = [];
                  const queries = (parsed.searchQueries || []).slice(0, 4);
                  if (parsed.text?.length > 0) queries.push(...parsed.text.filter(t => t.length > 3 && t.length < 100).slice(0, 2));
                  for (const q of queries.slice(0, 5)) {
                    try { allResults.push({ query: q, results: (await webSearch(q, settings)).slice(0, 3) }); } catch (_) {}
                  }
                  return { success: true, visionAnalysis: parsed, searchResults: allResults,
                    summary: `Analyzed screenshot. Found: ${(parsed.people || []).length} people, ${(parsed.text || []).length} text elements. Ran ${allResults.length} searches.` };
                } catch (e) { return { error: `Reverse image search failed: ${e.message}` }; }
              }
              case 'WEB_SEARCH':
                try { return { success: true, results: await webSearch(toolParam.trim(), settings) }; }
                catch (e) { return { error: `Search failed: ${e.message}` }; }
              case 'GET_TOKEN_PRICE':
                try {
                  const pd = await getTokenPrice(toolParam.trim(), settings);
                  const priceChange = await trackPrice(toolParam.trim(), pd.price);
                  if (pd.price) await recordFirstScan(toolParam.trim(), pd.price, pd.symbol, 'GET_TOKEN_PRICE');
                  return { success: true, ...pd, ...(priceChange ? { priceChange } : {}) };
                } catch (e) { return { error: `Price fetch failed: ${e.message}` }; }
              case 'GET_WALLET_BALANCE':
                try {
                  if (!settings.solanaRpc) throw new Error('No Solana RPC configured');
                  return { success: true, ...(await getWalletBalance(toolParam.trim(), settings.solanaRpc)) };
                } catch (e) { return { error: `Wallet fetch failed: ${e.message}` }; }
              case 'DEPLOY_SITE':
                try {
                  const { urchinCurrentProject } = await chrome.storage.local.get('urchinCurrentProject');
                  if (!urchinCurrentProject?.files) return { error: 'No site built yet. Use BUILD_SITE first, then DEPLOY_SITE.' };
                  const deployInfo = await deployToNetlify(urchinCurrentProject, settings);
                  return { success: true, ...deployInfo, message: `Site deployed! Live at ${deployInfo.url}` };
                } catch (e) { return { error: `Deploy failed: ${e.message}` }; }
              case 'LIST_SITES':
                try {
                  const sites = await listNetlifySites(settings);
                  return sites.length === 0
                    ? { success: true, sites: [], message: 'No Netlify sites found.' }
                    : { success: true, count: sites.length, sites: sites.map((s, i) => ({ number: i + 1, id: s.id, name: s.name, url: s.url, created: new Date(s.created).toLocaleDateString(), updated: new Date(s.updated).toLocaleDateString() })) };
                } catch (e) { return { error: `List sites failed: ${e.message}` }; }
              case 'DELETE_SITE':
                try { if (!toolParam.trim()) throw new Error('No site ID'); await deleteNetlifySite(toolParam.trim(), settings); return { success: true, message: `Site ${toolParam.trim()} deleted.` }; }
                catch (e) { return { error: `Delete failed: ${e.message}` }; }
              case 'MULTI_SCAN':
                try { if (!settings.solanaRpc) throw new Error('No Solana RPC configured'); return await multiTokenScan(toolParam.split(',').map(m => m.trim()).filter(Boolean), settings.solanaRpc); }
                catch (e) { return { error: `Multi-scan failed: ${e.message}` }; }
              case 'FETCH_URL':
                try { const u = toolParam.trim(); const c = await fetchPageContent(u); return { success: true, url: u, contentPreview: c.slice(0, 4000), cryptoData: parsePageForCryptoData(u, c) }; }
                catch (e) { return { error: `Fetch failed: ${e.message}` }; }
              case 'GET_WALLET_HISTORY':
                try { if (!settings.solanaRpc) throw new Error('No Solana RPC configured'); return await getWalletTransactions(toolParam.trim(), settings.solanaRpc); }
                catch (e) { return { error: `Transaction history failed: ${e.message}` }; }
              case 'REMEMBER':
                try {
                  const cl = toolParam.replace(/```json\s*/g, '').replace(/```/g, '').trim();
                  const md = JSON.parse(cl);
                  const { urchinMemory: mem = {} } = await chrome.storage.local.get('urchinMemory');
                  mem[md.key] = md.value;
                  mem[`_ts_${md.key}`] = Date.now();
                  const manualKeys = Object.keys(mem).filter(k => !k.startsWith('session_') && !k.startsWith('_'));
                  if (manualKeys.length > 100) {
                    const oldest = manualKeys.sort((a, b) => (mem[`_ts_${a}`] || 0) - (mem[`_ts_${b}`] || 0));
                    for (const k of oldest.slice(0, manualKeys.length - 100)) {
                      delete mem[k]; delete mem[`_ts_${k}`];
                    }
                  }
                  const { urchinEmbeddingCache = {} } = await chrome.storage.local.get('urchinEmbeddingCache');
                  delete urchinEmbeddingCache[md.key];
                  await chrome.storage.local.set({ urchinMemory: mem, urchinEmbeddingCache });
                  return { success: true, message: `Remembered "${md.key}".` };
                } catch (e) { return { error: `Memory save failed: ${e.message}` }; }
              case 'RECALL':
                try { const k = toolParam.trim(); const { urchinMemory: rm = {} } = await chrome.storage.local.get('urchinMemory'); return k === 'all' ? { success: true, memory: rm } : { success: true, key: k, value: rm[k] || 'Nothing saved under this key.' }; }
                catch (e) { return { error: `Memory recall failed: ${e.message}` }; }
              case 'SEARCH_MEMORY':
                try { const { urchinMemory: sm = {} } = await chrome.storage.local.get('urchinMemory'); const { urchinProfile: sp = {} } = await chrome.storage.local.get('urchinProfile'); const combined = { ...sm, ...Object.fromEntries(Object.entries(sp).map(([k, v]) => [`profile_${k}`, v])) }; return { success: true, ...(await semanticRecallWithEmbeddings(toolParam.trim(), combined, settings)) }; }
                catch (e) { return { error: `Memory search failed: ${e.message}` }; }
              case 'SET_ALERT': {
                try {
                  const alertData = JSON.parse(toolParam.replace(/```json\s*/g, '').replace(/```/g, '').trim());
                  const { urchinWatches = [] } = await chrome.storage.local.get('urchinWatches');
                  const watch = { id: `w-${Date.now()}`, type: alertData.type, target: alertData.target, condition: alertData.condition, created: Date.now() };
                  urchinWatches.push(watch);
                  await chrome.storage.local.set({ urchinWatches });
                  chrome.alarms.create('urchin-watch', { periodInMinutes: 5 });
                  return { success: true, message: `Alert set: ${alertData.type} on ${alertData.target}. You'll get a Chrome notification when triggered.`, watch };
                } catch (e) { return { error: `Alert setup failed: ${e.message}` }; }
              }
              case 'REMIND_ME': {
                try {
                  const reminder = JSON.parse(toolParam.replace(/```json\s*/g, '').replace(/```/g, '').trim());
                  const mins = parseInt(reminder.minutes) || 60;
                  const alarmName = `urchin-remind-${Date.now()}`;
                  const { urchinReminders = [] } = await chrome.storage.local.get('urchinReminders');
                  urchinReminders.push({ id: alarmName, task: reminder.task, triggerAt: Date.now() + mins * 60000 });
                  await chrome.storage.local.set({ urchinReminders });
                  chrome.alarms.create(alarmName, { delayInMinutes: mins });
                  return { success: true, message: `Reminder set for ${mins} minutes from now: "${reminder.task}"` };
                } catch (e) { return { error: `Reminder failed: ${e.message}` }; }
              }
              case 'DEX_DATA':
                try {
                  const dexPairs = await fetchDexScreenerData(toolParam.trim());
                  if (Array.isArray(dexPairs) && dexPairs[0]?.price) await recordFirstScan(toolParam.trim(), dexPairs[0].price, dexPairs[0].baseToken, 'DEX_DATA');
                  return { success: true, pairs: dexPairs };
                } catch (e) { return { error: `DexScreener fetch failed: ${e.message}` }; }
              case 'SET_TIMER': {
                try {
                  const timerData = JSON.parse(toolParam.replace(/```json\s*/g, '').replace(/```/g, '').trim());
                  const mins = parseInt(timerData.minutes) || 30;
                  const taskId = `urchin-autotask-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
                  const { urchinTaskQueue = [] } = await chrome.storage.local.get('urchinTaskQueue');
                  urchinTaskQueue.push({
                    id: taskId, input: timerData.task, status: 'pending',
                    scheduledAt: Date.now() + mins * 60000, createdAt: Date.now(),
                    type: 'timer', autonomous: true
                  });
                  await chrome.storage.local.set({ urchinTaskQueue });
                  chrome.alarms.create(taskId, { delayInMinutes: mins });
                  return { success: true, message: `Autonomous task scheduled for ${mins} minutes from now: "${timerData.task}". I'll run it through the full agent loop and deliver results.`, taskId };
                } catch (e) { return { error: `Timer setup failed: ${e.message}` }; }
              }
              case 'SCHEDULE_TASK': {
                try {
                  const schedData = JSON.parse(toolParam.replace(/```json\s*/g, '').replace(/```/g, '').trim());
                  const delayMins = parseInt(schedData.delayMinutes) || 0;
                  const taskId = `urchin-autotask-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
                  const { urchinTaskQueue = [] } = await chrome.storage.local.get('urchinTaskQueue');
                  urchinTaskQueue.push({
                    id: taskId, input: schedData.task, status: 'pending',
                    scheduledAt: Date.now() + delayMins * 60000, createdAt: Date.now(),
                    type: delayMins === 0 ? 'immediate' : 'scheduled', autonomous: true
                  });
                  await chrome.storage.local.set({ urchinTaskQueue });
                  if (delayMins === 0) {
                    chrome.alarms.create(taskId, { delayInMinutes: 0.1 });
                  } else {
                    chrome.alarms.create(taskId, { delayInMinutes: delayMins });
                  }
                  return { success: true, message: delayMins === 0
                    ? `Background task queued for immediate execution: "${schedData.task}"`
                    : `Background task scheduled for ${delayMins} minutes: "${schedData.task}"`, taskId };
                } catch (e) { return { error: `Task scheduling failed: ${e.message}` }; }
              }
              case 'CONTINUE': {
                return { success: true, continueLoop: true, reason: toolParam.trim() || 'Continuing analysis...' };
              }
              case 'MONITOR': {
                try {
                  const monData = JSON.parse(toolParam.replace(/```json\s*/g, '').replace(/```/g, '').trim());
                  if (!monData.target) return { error: 'MONITOR needs a "target" (mint address, wallet, or keyword).' };
                  const interval = Math.max(5, parseInt(monData.interval) || 15);
                  const stopAfter = parseInt(monData.stopAfter) || 360;
                  const monId = `urchin-monitor-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`;
                  const { urchinMonitors = [] } = await chrome.storage.local.get('urchinMonitors');
                  const monitor = {
                    id: monId, target: monData.target, type: monData.type || 'token',
                    interval, instructions: monData.instructions || `Check ${monData.target} for changes`,
                    createdAt: Date.now(), expiresAt: Date.now() + stopAfter * 60000,
                    checkCount: 0, lastCheckAt: null, status: 'active'
                  };
                  urchinMonitors.push(monitor);
                  await chrome.storage.local.set({ urchinMonitors });
                  chrome.alarms.create(monId, { periodInMinutes: interval });
                  const stopTime = stopAfter >= 60 ? `${(stopAfter / 60).toFixed(1)} hours` : `${stopAfter} minutes`;
                  return { success: true, message: `Monitoring started: "${monData.target}" every ${interval} minutes. Auto-stops in ${stopTime}. I'll run a full analysis each check and notify you of any changes.`, monitorId: monId };
                } catch (e) { return { error: `Monitor setup failed: ${e.message}` }; }
              }
              case 'LIST_MONITORS': {
                try {
                  const { urchinMonitors = [] } = await chrome.storage.local.get('urchinMonitors');
                  const active = urchinMonitors.filter(m => m.status === 'active' && m.expiresAt > Date.now());
                  if (active.length === 0) return { success: true, monitors: [], message: 'No active monitors.' };
                  return { success: true, count: active.length, monitors: active.map(m => ({
                    id: m.id, target: m.target, type: m.type, interval: m.interval,
                    instructions: m.instructions, checksRun: m.checkCount,
                    lastCheck: m.lastCheckAt ? new Date(m.lastCheckAt).toLocaleTimeString() : 'never',
                    timeRemaining: `${Math.round((m.expiresAt - Date.now()) / 60000)} minutes`
                  })) };
                } catch (e) { return { error: `List monitors failed: ${e.message}` }; }
              }
              case 'STOP_MONITOR': {
                try {
                  const query = toolParam.trim().toLowerCase();
                  const { urchinMonitors = [] } = await chrome.storage.local.get('urchinMonitors');
                  const idx = urchinMonitors.findIndex(m =>
                    m.id.toLowerCase() === query ||
                    m.target.toLowerCase().includes(query) ||
                    query.includes(m.target.toLowerCase().slice(0, 8))
                  );
                  if (idx === -1) return { error: `No active monitor found matching "${toolParam.trim()}". Use LIST_MONITORS to see active monitors.` };
                  const stopped = urchinMonitors[idx];
                  chrome.alarms.clear(stopped.id);
                  stopped.status = 'stopped';
                  stopped.stoppedAt = Date.now();
                  await chrome.storage.local.set({ urchinMonitors });
                  return { success: true, message: `Monitor stopped: "${stopped.target}" (ran ${stopped.checkCount} checks). No more recurring checks.` };
                } catch (e) { return { error: `Stop monitor failed: ${e.message}` }; }
              }
              case 'LEARN_SKILL': {
                try {
                  const skillData = JSON.parse(toolParam.replace(/```json\s*/g, '').replace(/```/g, '').trim());
                  if (!skillData.name || !skillData.instruction) return { error: 'Skill needs both "name" and "instruction" fields.' };
                  const { urchinSkills = [] } = await chrome.storage.local.get('urchinSkills');
                  const existing = urchinSkills.findIndex(s => s.name === skillData.name);
                  if (existing !== -1) {
                    urchinSkills[existing].instruction = skillData.instruction;
                    urchinSkills[existing].updatedAt = Date.now();
                    urchinSkills[existing].score = Math.max(urchinSkills[existing].score ?? 50, 50);
                  } else {
                    urchinSkills.push({
                      id: `skill-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
                      name: skillData.name, instruction: skillData.instruction,
                      learnedAt: Date.now(), usageCount: 0, score: 60, evalCount: 0
                    });
                  }
                  if (urchinSkills.length > 50) urchinSkills.shift();
                  await chrome.storage.local.set({ urchinSkills });
                  return { success: true, message: `Skill "${skillData.name}" ${existing !== -1 ? 'updated' : 'learned'}. I'll apply it in all future conversations.`, totalSkills: urchinSkills.length };
                } catch (e) { return { error: `Skill learning failed: ${e.message}` }; }
              }
              case 'LIST_SKILLS': {
                try {
                  const { urchinSkills = [] } = await chrome.storage.local.get('urchinSkills');
                  if (urchinSkills.length === 0) return { success: true, skills: [], message: 'No skills learned yet.' };
                  return { success: true, count: urchinSkills.length, skills: urchinSkills.map(s => ({ name: s.name, instruction: s.instruction, score: s.score ?? 50, learnedAt: new Date(s.learnedAt).toLocaleDateString(), usageCount: s.usageCount || 0, evalCount: s.evalCount || 0 })) };
                } catch (e) { return { error: `Skill list failed: ${e.message}` }; }
              }
              case 'FORGET_SKILL': {
                try {
                  const name = toolParam.trim();
                  const { urchinSkills = [] } = await chrome.storage.local.get('urchinSkills');
                  const idx = urchinSkills.findIndex(s => s.name === name);
                  if (idx === -1) return { error: `No skill named "${name}" found.` };
                  urchinSkills.splice(idx, 1);
                  await chrome.storage.local.set({ urchinSkills });
                  return { success: true, message: `Skill "${name}" forgotten. ${urchinSkills.length} skills remaining.` };
                } catch (e) { return { error: `Skill forget failed: ${e.message}` }; }
              }
              case 'SET_GOAL': {
                try {
                  const plan = JSON.parse(toolParam.replace(/```json\s*/g, '').replace(/```/g, '').trim());
                  if (!plan.project) return { error: 'Project plan needs a "project" name.' };
                  const { urchinProjects = {} } = await chrome.storage.local.get('urchinProjects');
                  urchinProjects[plan.project] = {
                    goals: plan.goals || [],
                    milestones: (plan.milestones || []).map(m => ({
                      name: m.name, tasks: m.tasks || [], status: m.status || 'pending',
                      notes: m.notes || '', updatedAt: Date.now()
                    })),
                    createdAt: urchinProjects[plan.project]?.createdAt || Date.now(),
                    updatedAt: Date.now()
                  };
                  const projectKeys = Object.keys(urchinProjects);
                  if (projectKeys.length > 10) delete urchinProjects[projectKeys[0]];
                  await chrome.storage.local.set({ urchinProjects });
                  return { success: true, message: `Project "${plan.project}" saved with ${plan.milestones?.length || 0} milestones. I'll track this across sessions.` };
                } catch (e) { return { error: `Set goal failed: ${e.message}` }; }
              }
              case 'UPDATE_GOAL': {
                try {
                  const upd = JSON.parse(toolParam.replace(/```json\s*/g, '').replace(/```/g, '').trim());
                  if (!upd.project || !upd.milestone) return { error: 'Need "project" and "milestone" fields.' };
                  const { urchinProjects = {} } = await chrome.storage.local.get('urchinProjects');
                  const proj = urchinProjects[upd.project];
                  if (!proj) return { error: `No project "${upd.project}" found. Use SET_GOAL first.` };
                  const ms = proj.milestones.find(m => m.name === upd.milestone);
                  if (!ms) return { error: `No milestone "${upd.milestone}" in project "${upd.project}".` };
                  if (upd.status) ms.status = upd.status;
                  if (upd.notes) ms.notes = (ms.notes ? ms.notes + ' | ' : '') + upd.notes;
                  ms.updatedAt = Date.now();
                  proj.updatedAt = Date.now();
                  await chrome.storage.local.set({ urchinProjects });
                  const done = proj.milestones.filter(m => m.status === 'done').length;
                  return { success: true, message: `Milestone "${upd.milestone}" → ${upd.status}. Progress: ${done}/${proj.milestones.length} milestones complete.` };
                } catch (e) { return { error: `Update goal failed: ${e.message}` }; }
              }
              case 'GET_GOALS': {
                try {
                  const { urchinProjects = {} } = await chrome.storage.local.get('urchinProjects');
                  const projects = Object.entries(urchinProjects);
                  if (projects.length === 0) return { success: true, projects: [], message: 'No active project plans.' };
                  return { success: true, count: projects.length, projects: projects.map(([name, p]) => ({
                    name, goals: p.goals,
                    milestones: p.milestones.map(m => ({ name: m.name, status: m.status, tasks: m.tasks, notes: m.notes })),
                    progress: `${p.milestones.filter(m => m.status === 'done').length}/${p.milestones.length}`,
                    created: new Date(p.createdAt).toLocaleDateString(),
                    lastUpdated: new Date(p.updatedAt).toLocaleDateString()
                  })) };
                } catch (e) { return { error: `Get goals failed: ${e.message}` }; }
              }
              case 'PNL_CHECK': {
                try {
                  if (!settings.solanaRpc) return { error: 'No Solana RPC configured. Add one in Settings.' };
                  const wallet = toolParam.trim();
                  if (!wallet || wallet.length < 32) return { error: 'Provide a valid Solana wallet address.' };
                  const pnl = await getWalletPnL(wallet, settings.solanaRpc);
                  const { urchinPnlHistory = {} } = await chrome.storage.local.get('urchinPnlHistory');
                  const prevSnapshot = urchinPnlHistory[wallet];
                  let change = null;
                  if (prevSnapshot && pnl.totalPortfolioUsd !== null) {
                    const prevTotal = prevSnapshot.totalPortfolioUsd || 0;
                    change = { previousUsd: prevTotal, currentUsd: pnl.totalPortfolioUsd, deltaUsd: Math.round((pnl.totalPortfolioUsd - prevTotal) * 100) / 100, checkedAgo: prevSnapshot.checkedAt };
                  }
                  pnl.change = change;
                  urchinPnlHistory[wallet] = { totalPortfolioUsd: pnl.totalPortfolioUsd, tokens: pnl.tokens.map(t => ({ mint: t.mint, symbol: t.symbol, valueUsd: t.valueUsd })), solValueUsd: pnl.solValueUsd, checkedAt: pnl.checkedAt };
                  const histKeys = Object.keys(urchinPnlHistory);
                  if (histKeys.length > 20) delete urchinPnlHistory[histKeys[0]];
                  await chrome.storage.local.set({ urchinPnlHistory });
                  return pnl;
                } catch (e) { return { error: `PnL check failed: ${e.message}` }; }
              }
              case 'WATCH_WALLET': {
                try {
                  const data = JSON.parse(toolParam.replace(/```json\s*/g, '').replace(/```/g, '').trim());
                  if (!data.address || data.address.length < 32) return { error: 'Provide a valid wallet address.' };
                  const { urchinWatchlist = [] } = await chrome.storage.local.get('urchinWatchlist');
                  const exists = urchinWatchlist.find(w => w.address === data.address);
                  if (exists) return { success: true, message: `Already watching wallet ${data.address.slice(0, 8)}... as "${exists.label}".` };
                  urchinWatchlist.push({ address: data.address, label: data.label || data.address.slice(0, 8), addedAt: Date.now() });
                  if (urchinWatchlist.length > 20) urchinWatchlist.shift();
                  await chrome.storage.local.set({ urchinWatchlist });
                  return { success: true, message: `Now watching wallet "${data.label || data.address.slice(0, 8)}" (${data.address}). ${urchinWatchlist.length} wallets on watchlist.` };
                } catch (e) { return { error: `Watch wallet failed: ${e.message}` }; }
              }
              case 'UNWATCH_WALLET': {
                try {
                  const addr = toolParam.trim();
                  const { urchinWatchlist = [] } = await chrome.storage.local.get('urchinWatchlist');
                  const idx = urchinWatchlist.findIndex(w => w.address === addr || w.label.toLowerCase() === addr.toLowerCase());
                  if (idx === -1) return { error: `Wallet "${addr}" not found on watchlist.` };
                  const removed = urchinWatchlist.splice(idx, 1)[0];
                  await chrome.storage.local.set({ urchinWatchlist });
                  return { success: true, message: `Removed "${removed.label}" (${removed.address}) from watchlist. ${urchinWatchlist.length} remaining.` };
                } catch (e) { return { error: `Unwatch failed: ${e.message}` }; }
              }
              case 'LIST_WATCHLIST': {
                try {
                  const { urchinWatchlist = [] } = await chrome.storage.local.get('urchinWatchlist');
                  if (urchinWatchlist.length === 0) return { success: true, wallets: [], message: 'Watchlist is empty. Use WATCH_WALLET to add wallets.' };
                  return { success: true, count: urchinWatchlist.length, wallets: urchinWatchlist.map(w => ({ address: w.address, label: w.label, addedAt: new Date(w.addedAt).toLocaleDateString() })) };
                } catch (e) { return { error: `List watchlist failed: ${e.message}` }; }
              }
              case 'SET_DIGEST': {
                try {
                  const data = JSON.parse(toolParam.replace(/```json\s*/g, '').replace(/```/g, '').trim());
                  const hour = data.hour ?? 9;
                  const minute = data.minute ?? 0;
                  const enabled = data.enabled !== false;
                  const trackerInterval = Math.max(1, Math.min(data.trackerInterval ?? 5, 60));
                  const minNotifyUsd = data.minNotifyUsd ?? 10;
                  const trackerEnabled = data.trackerEnabled !== false;

                  const config = { hour, minute, enabled, trackerInterval, trackerEnabled, minNotifyUsd, updatedAt: Date.now() };
                  await chrome.storage.local.set({ urchinDigestConfig: config });

                  const parts = [];
                  if (enabled) {
                    const now = new Date();
                    let next = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hour, minute, 0);
                    if (next <= now) next.setDate(next.getDate() + 1);
                    await chrome.alarms.create('urchin-daily-digest', { when: next.getTime(), periodInMinutes: 1440 });
                    parts.push(`Daily digest at ${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}. Next: ${next.toLocaleString()}`);
                  } else {
                    await chrome.alarms.clear('urchin-daily-digest');
                    parts.push('Daily digest disabled');
                  }
                  if (trackerEnabled) {
                    await chrome.alarms.create('urchin-wallet-tracker', { periodInMinutes: trackerInterval });
                    parts.push(`Wallet tracker polling every ${trackerInterval} min (no LLM cost)`);
                  } else {
                    await chrome.alarms.clear('urchin-wallet-tracker');
                    parts.push('Wallet tracker disabled');
                  }
                  parts.push(`Notification threshold: $${minNotifyUsd}+`);

                  return { success: true, config, message: parts.join('. ') + '.' };
                } catch (e) { return { error: `Set digest failed: ${e.message}` }; }
              }
              case 'GET_DIGEST_CONFIG': {
                try {
                  const { urchinDigestConfig = {} } = await chrome.storage.local.get('urchinDigestConfig');
                  if (!urchinDigestConfig.updatedAt) return { success: true, message: 'No digest/tracker configured yet. Use SET_DIGEST to set it up.' };
                  return { success: true, config: urchinDigestConfig };
                } catch (e) { return { error: `Get digest config failed: ${e.message}` }; }
              }
              case 'WALLET_ACTIVITY': {
                try {
                  const query = toolParam.trim().toLowerCase();
                  const { urchinWalletActivity = [] } = await chrome.storage.local.get('urchinWalletActivity');
                  if (urchinWalletActivity.length === 0) return { success: true, events: [], message: 'No activity recorded yet. Enable the wallet tracker with SET_DIGEST and add wallets to your watchlist.' };
                  let filtered = urchinWalletActivity;
                  if (query && query !== 'all' && query !== '*') {
                    filtered = urchinWalletActivity.filter(e => e.wallet.toLowerCase().includes(query) || (e.label && e.label.toLowerCase().includes(query)));
                  }
                  const recent = filtered.slice(-30);
                  return {
                    success: true,
                    totalEvents: urchinWalletActivity.length,
                    showing: recent.length,
                    events: recent.map(e => ({
                      wallet: e.label || e.wallet.slice(0, 8), event: e.event,
                      token: e.symbol || null, amount: e.amount, valueUsd: e.valueUsd || null,
                      time: new Date(e.time).toLocaleString()
                    }))
                  };
                } catch (e) { return { error: `Wallet activity failed: ${e.message}` }; }
              }
              case 'PNL_CARD': {
                try {
                  const mint = toolParam.trim();
                  if (!mint || mint.length < 32) return { error: 'Provide a valid Solana mint address. Use LIST_SCANS to find the mint for a token.' };
                  return await buildPnlCard(mint, settings);
                } catch (e) { return { error: `PnL card failed: ${e.message}` }; }
              }
              case 'LIST_SCANS': {
                try {
                  const { urchinFirstScans = {} } = await chrome.storage.local.get('urchinFirstScans');
                  const entries = Object.entries(urchinFirstScans);
                  if (entries.length === 0) return { success: true, scans: [], message: 'No tokens scanned yet. Scan a token first with SCAN_TOKEN or GET_TOKEN_PRICE.' };
                  const scans = entries.map(([mint, d]) => ({
                    mint, symbol: d.symbol, entryPrice: d.price,
                    scannedAt: new Date(d.scannedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
                    via: d.via
                  })).sort((a, b) => b.scannedAt - a.scannedAt);
                  return { success: true, count: scans.length, scans };
                } catch (e) { return { error: `List scans failed: ${e.message}` }; }
              }
              case 'SET_MY_WALLET': {
                try {
                  const addr = toolParam.trim();
                  if (!addr || addr.length < 32 || addr.length > 44) return { error: 'Provide a valid Solana wallet address (32-44 chars).' };
                  await chrome.storage.local.set({ urchinMyWallet: addr });
                  return { success: true, message: `Wallet set to ${addr.slice(0, 6)}...${addr.slice(-4)}. PnL cards will now show your holdings automatically.` };
                } catch (e) { return { error: `Set wallet failed: ${e.message}` }; }
              }
              case 'GET_MY_WALLET': {
                try {
                  const { urchinMyWallet } = await chrome.storage.local.get('urchinMyWallet');
                  if (!urchinMyWallet) return { success: true, wallet: null, message: 'No wallet set. Use SET_MY_WALLET to save your wallet address.' };
                  return { success: true, wallet: urchinMyWallet };
                } catch (e) { return { error: `Get wallet failed: ${e.message}` }; }
              }
              case 'SET_DEPLOYER_KEY': {
                try {
                  const parsed = JSON.parse(toolParam);
                  if (!parsed.key || !parsed.pin) return { error: 'Provide {"key":"<base58 private key>","pin":"<your PIN>"}.' };
                  if (parsed.pin.length < 4) return { error: 'PIN must be at least 4 characters.' };
                  return await setDeployerKey(parsed.key, parsed.pin);
                } catch (e) {
                  if (e instanceof SyntaxError) return { error: 'Invalid JSON. Use: {"key":"<base58 private key>","pin":"<your PIN>"}' };
                  return { error: `Set deployer failed: ${e.message}` };
                }
              }
              case 'GET_DEPLOYER_KEY': {
                try {
                  const pub = await getDeployerPubkey();
                  if (!pub) return { success: true, wallet: null, message: 'No deployer wallet set. Use SET_DEPLOYER_KEY to save one.' };
                  let balance = null;
                  if (settings.solanaRpc) {
                    try { balance = await SolanaLite.getBalance(pub, settings.solanaRpc); } catch (_) {}
                  }
                  return { success: true, publicKey: pub, balanceSol: balance !== null ? Math.round(balance * 10000) / 10000 : 'unknown (no RPC)' };
                } catch (e) { return { error: `Get deployer failed: ${e.message}` }; }
              }
              case 'PUMP_TOKEN_INFO': {
                try {
                  const mint = toolParam.trim();
                  if (!mint || mint.length < 32) return { error: 'Provide a valid Solana mint address.' };
                  return await pumpGetCoinInfo(mint);
                } catch (e) { return { error: `Pump token info failed: ${e.message}` }; }
              }
              case 'PUMP_BUY': {
                try {
                  const parsed = JSON.parse(toolParam);
                  if (!parsed.mint || !parsed.amount || !parsed.pin) return { error: 'Provide {"mint":"...","amount":0.1,"pin":"..."}. Amount is in SOL.' };
                  return await pumpTrade('buy', parsed.mint, parsed.amount, parsed.pin, settings);
                } catch (e) {
                  if (e instanceof SyntaxError) return { error: 'Invalid JSON. Use: {"mint":"<mint>","amount":<SOL>,"pin":"<PIN>"}' };
                  return { error: `Pump buy failed: ${e.message}` };
                }
              }
              case 'PUMP_SELL': {
                try {
                  const parsed = JSON.parse(toolParam);
                  if (!parsed.mint || !parsed.amount || !parsed.pin) return { error: 'Provide {"mint":"...","amount":1000000,"pin":"..."}. Amount is in token units.' };
                  return await pumpTrade('sell', parsed.mint, parsed.amount, parsed.pin, settings);
                } catch (e) {
                  if (e instanceof SyntaxError) return { error: 'Invalid JSON. Use: {"mint":"<mint>","amount":<tokens>,"pin":"<PIN>"}' };
                  return { error: `Pump sell failed: ${e.message}` };
                }
              }
              case 'PUMP_DEPLOY': {
                try {
                  const parsed = JSON.parse(toolParam);
                  if (!parsed.name || !parsed.symbol || !parsed.pin) return { error: 'Provide {"name":"...","symbol":"...","pin":"...","description":"...","initialBuy":0}.' };
                  return await pumpDeploy(parsed, parsed.pin, settings);
                } catch (e) {
                  if (e instanceof SyntaxError) return { error: 'Invalid JSON. Use: {"name":"Token Name","symbol":"TICK","description":"...","pin":"<PIN>","initialBuy":0.1}' };
                  const msg = (e && (e.message || e.toString())) || 'Unknown error';
                  console.error('[urchin] PUMP_DEPLOY error:', e);
                  return { error: `Pump deploy failed: ${msg}` };
                }
              }
              case 'X_PROFILE': {
                try {
                  const username = toolParam.trim().replace(/^@/, '');
                  if (!username) return { error: 'Provide a Twitter/X username.' };
                  return await xGetProfile(username);
                } catch (e) { return { error: `X profile failed: ${e.message}` }; }
              }
              case 'X_SEARCH': {
                try {
                  const query = toolParam.trim();
                  if (!query) return { error: 'Provide a search query.' };
                  return { results: await xSearchTweets(query, 15) };
                } catch (e) { return { error: `X search failed: ${e.message}` }; }
              }
              case 'X_USER_TWEETS': {
                try {
                  const username = toolParam.trim().replace(/^@/, '');
                  if (!username) return { error: 'Provide a Twitter/X username.' };
                  return { username, tweets: await xGetUserTweets(username, 15) };
                } catch (e) { return { error: `X tweets failed: ${e.message}` }; }
              }
              default:
                return { error: `Unknown tool: ${toolName}` };
              }
            } catch (e) {
              return { error: e.message };
            }
          };

          // Execute tools — parallel if multiple, sequential if single
          let toolResults;
          if (toolJobs.length > 1) {
            toolResults = await Promise.all(toolJobs.map(j => executeToolJob(j)));
          } else {
            toolResults = [await executeToolJob(toolJobs[0])];
          }

          messages.push({ role: 'assistant', content: cleanedRaw });

          let combinedResults = '';
          let hasError = false;
          let shouldContinue = false;
          for (let ti = 0; ti < toolJobs.length; ti++) {
            const { toolName } = toolJobs[ti];
            const tr = toolResults[ti];
            addStep('tool_result', { tool: toolName, preview: JSON.stringify(tr).slice(0, 200) });
            if (tr && tr.continueLoop) {
              shouldContinue = true;
              combinedResults += `[CONTINUE]: Extending reasoning — ${tr.reason}\n`;
            } else {
              if (tr && tr._pnlCardRender && tr.card) {
                pendingPnlCards.push(tr.card);
              }
              const summarized = summarizeToolResult(toolName, tr);
              combinedResults += `[Tool result for ${toolName}]: ${summarized}\n`;
            }
            if (tr && tr.error) hasError = true;
          }

          if (shouldContinue && maxSteps - step <= 2) {
            maxSteps = Math.min(maxSteps + 6, 24);
            addStep('continue_extend', { newMaxSteps: maxSteps, reason: 'CONTINUE tool used' });
          }

          if (hasError) {
            combinedResults += '\n[HINT: One or more tools failed. Try a different approach, use a different tool, or rephrase the query.]';
          }

          messages.push({ role: 'user', content: combinedResults.trim() });
          broadcastProgress({ phase: 'tool_done', tools: toolJobs.map(j => j.toolName) });
          continue;
        }

        finalAnswer = cleanedRaw.trim() || raw.trim();
        if (pendingPnlCards.length > 0) {
          const cardTags = pendingPnlCards.map(c => `<<PNL_CARD_DATA:${JSON.stringify(c)}>>`).join('\n');
          finalAnswer = finalAnswer.replace(/<<PNL_CARD_DATA:[\s\S]+?>>/g, '');
          finalAnswer += '\n' + cardTags;
          pendingPnlCards.length = 0;
        }
        broadcastProgress({ phase: 'done', answer: finalAnswer });
        break;
      } catch (e) {
        addStep('agent_error', { error: e.message });
        log.endTime = Date.now();
        await saveLog(log);
        return { requestId, success: false, error: e.message, log };
      }
    }

    result = { answer: finalAnswer || 'No response from agent.', actions: [] };

    // ──── POST-RESPONSE: Memory management (fire-and-forget, non-blocking) ────
    const memMessages = [...messages];
    const memHistory = log._history || [];
    const memSettings = { ...settings };
    const memActiveSkills = [...activeSkillNames];
    const memFinalAnswer = finalAnswer;
    const memUserInput = userInput;
    setTimeout(async () => {
      try {
        const { urchinMemory = {} } = await chrome.storage.local.get('urchinMemory');
        const convCount = parseInt(urchinMemory._convCount || '0') + 1;
        urchinMemory._convCount = String(convCount);

        // 0) Implicit satisfaction signal — detect user corrections, frustration, retries
        if (memActiveSkills.length > 0 && memHistory.length >= 2) {
          try {
            const { urchinSkills = [] } = await chrome.storage.local.get('urchinSkills');
            let signal = 0;

            const lastUserMsgs = memHistory.filter(h => h.role === 'user').slice(-3).map(h => h.text.toLowerCase());
            const negativePatterns = [
              /\bno\b.*\bwrong\b/, /\bstop\b.*\bdoing\b/, /\bdon'?t\b.*\bdo that\b/,
              /\bnot what i\b/, /\bi didn'?t ask\b/, /\bthat'?s wrong\b/, /\btry again\b/,
              /\bincorrect\b/, /\bwrong\b/, /\bnot helpful\b/, /\buseless\b/,
              /\bno[,.]?\s*(that|this) is/, /\bactually[,.]?\s*(i|it|the)\b/
            ];
            const positivePatterns = [
              /\bthanks?\b/, /\bthank you\b/, /\bperfect\b/, /\bgreat\b/, /\bexactly\b/,
              /\bnice\b/, /\bawesome\b/, /\bgood job\b/, /\blove it\b/, /\bnailed it\b/
            ];

            for (const msg of lastUserMsgs) {
              if (negativePatterns.some(p => p.test(msg))) signal -= 15;
              if (positivePatterns.some(p => p.test(msg))) signal += 10;
            }

            if (memHistory.length <= 2 && !positivePatterns.some(p => p.test(lastUserMsgs[lastUserMsgs.length - 1] || ''))) {
              signal -= 3;
            }
            if (memHistory.length >= 8) signal += 5;

            if (signal !== 0) {
              let updated = false;
              for (const skill of urchinSkills) {
                if (memActiveSkills.includes(skill.name)) {
                  const oldScore = skill.score ?? 50;
                  const delta = Math.max(-20, Math.min(15, signal));
                  skill.score = Math.max(0, Math.min(100, Math.round(oldScore + delta)));
                  skill.lastSignalAt = Date.now();
                  skill.signalCount = (skill.signalCount || 0) + 1;
                  updated = true;
                }
              }
              if (updated) await chrome.storage.local.set({ urchinSkills });
            }
          } catch (_) {}
        }

        // A) Session summary — every 3rd conversation
        if (convCount % 3 === 0 && memMessages.length >= 3) {
          try {
            const summaryMessages = [...memMessages.slice(-10), { role: 'user', content:
              'Summarize this conversation in 3-5 bullet points. Extract: wallet addresses, token names/symbols/mints, websites built, user preferences, key decisions. Be specific — include actual values.'
            }];
            const summary = await callLLMChat('You are a memory system. Output ONLY the bullet-point summary.', summaryMessages, memSettings);
            urchinMemory[`session_${Date.now()}`] = summary.slice(0, 1500);
            const sessionKeys = Object.keys(urchinMemory).filter(k => k.startsWith('session_')).sort();
            if (sessionKeys.length > 20) {
              for (const old of sessionKeys.slice(0, sessionKeys.length - 20)) delete urchinMemory[old];
            }
          } catch (_) {}
        }
        await chrome.storage.local.set({ urchinMemory });

        // B) User profile — every 5th conversation
        if (convCount % 5 === 0 && memMessages.length >= 3) {
          try {
            const { urchinProfile = {} } = await chrome.storage.local.get('urchinProfile');
            const currentProfile = Object.entries(urchinProfile).map(([k, v]) => `${k}: ${v}`).join('\n') || '(empty)';
            const profileMessages = [{ role: 'user', content:
              `Current profile:\n${currentProfile}\n\nRecent conversation:\n` +
              memMessages.slice(-6).map(m => `${m.role}: ${(m.content || '').slice(0, 300)}`).join('\n') +
              '\n\nExtract NEW user info (name, wallets, tokens, preferences, projects). Return ONLY valid JSON. If nothing new, return {}.'
            }];
            const profileRaw = await callLLMChat('Output ONLY a JSON object.', profileMessages, memSettings);
            const cleaned = profileRaw.replace(/```json\s*/g, '').replace(/```/g, '').trim();
            const newProfile = JSON.parse(cleaned);
            if (Object.keys(newProfile).length > 0) {
              await chrome.storage.local.set({ urchinProfile: { ...urchinProfile, ...newProfile } });
            }
          } catch (_) {}
        }

        // C) Smart condensation — LLM-based compression of old history
        if (memHistory.length > 40) {
          const oldMessages = memHistory.slice(0, memHistory.length - 30);
          const { urchinCondensed = '' } = await chrome.storage.local.get('urchinCondensed');
          try {
            const oldText = oldMessages.map(h => `[${h.role}] ${h.text.slice(0, 300)}`).join('\n');
            const condensePrompt = `Existing condensed history:\n${urchinCondensed || '(none)'}\n\nNew messages to condense:\n${oldText}\n\nCompress ALL of this into a dense narrative summary (max 2000 chars). Preserve: wallet addresses, token names/mints, user preferences, key facts, decisions, URLs built/deployed. Drop greetings and filler.`;
            const condensed = await callLLMChat('You are a memory compressor. Output ONLY the compressed narrative.', [{ role: 'user', content: condensePrompt }], memSettings);
            await chrome.storage.local.set({ urchinCondensed: condensed.slice(0, 4000) });
          } catch (_) {
            const oldText = oldMessages.map(h => `[${h.role}] ${h.text.slice(0, 200)}`).join('\n');
            const newCondensed = (urchinCondensed ? urchinCondensed + '\n---\n' : '') + oldText;
            await chrome.storage.local.set({ urchinCondensed: newCondensed.slice(-4000) });
          }
        }

        // D) Auto-skill learning — every 7th conversation, analyze for learnable patterns
        if (convCount % 7 === 0 && memMessages.length >= 4) {
          try {
            const { urchinSkills = [] } = await chrome.storage.local.get('urchinSkills');
            const existingSkillNames = urchinSkills.map(s => s.name).join(', ') || '(none)';
            const recentConvo = memMessages.slice(-8).map(m => `${m.role}: ${(m.content || '').slice(0, 400)}`).join('\n');
            const skillPrompt = `You are analyzing a conversation for learnable behavioral patterns. Extract NEW actionable skills the agent should learn to serve this user better.\n\nExisting skills: ${existingSkillNames}\n\nRecent conversation:\n${recentConvo}\n\nOutput ONLY valid JSON array of new skills to learn. Each skill: {"name":"kebab-case-name","instruction":"specific actionable instruction"}.\nRules:\n- Only genuinely useful, specific skills (not generic advice)\n- Don't duplicate existing skills\n- Skills should be behavioral instructions, not facts\n- Examples: {"name":"dark-mode-preference","instruction":"Always build websites with dark mode as default"}\n- If nothing worth learning, return []\n- Max 2 new skills per analysis`;
            const skillRaw = await callLLMChat('Output ONLY a JSON array.', [{ role: 'user', content: skillPrompt }], memSettings);
            const cleaned = skillRaw.replace(/```json\s*/g, '').replace(/```/g, '').trim();
            const newSkills = JSON.parse(cleaned);
            if (Array.isArray(newSkills) && newSkills.length > 0) {
              for (const ns of newSkills.slice(0, 2)) {
                if (ns.name && ns.instruction && !urchinSkills.some(s => s.name === ns.name)) {
                  urchinSkills.push({
                    id: `skill-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
                    name: ns.name, instruction: ns.instruction,
                    learnedAt: Date.now(), usageCount: 0, source: 'auto',
                    score: 50
                  });
                }
              }
              if (urchinSkills.length > 50) urchinSkills.splice(0, urchinSkills.length - 50);
              await chrome.storage.local.set({ urchinSkills });
            }
          } catch (_) {}
        }

        // E) Skill self-evaluation — every 10th conversation, score active skills and prune bad ones
        if (convCount % 10 === 0 && memActiveSkills.length > 0 && memMessages.length >= 4) {
          try {
            const { urchinSkills = [] } = await chrome.storage.local.get('urchinSkills');
            const activeForEval = urchinSkills.filter(s => memActiveSkills.includes(s.name));
            if (activeForEval.length > 0) {
              const recentConvo = memMessages.slice(-10).map(m => `${m.role}: ${(m.content || '').slice(0, 400)}`).join('\n');
              const skillList = activeForEval.map(s => `  "${s.name}": "${s.instruction}" (used ${s.usageCount || 0}x, current score: ${s.score ?? 50})`).join('\n');
              const evalPrompt = `You are evaluating whether learned behavioral skills are actually helping in conversations. Analyze the recent conversation and score each skill.\n\nActive skills this session:\n${skillList}\n\nRecent conversation:\n${recentConvo}\n\nFor each skill, output JSON: {"scores":{"skill-name": <number 0-100>}}\nScoring guide:\n- 80-100: Skill was clearly applied and helped the response\n- 50-70: Skill was relevant but hard to tell if it helped\n- 20-49: Skill seems irrelevant to this user's actual needs\n- 0-19: Skill is actively wrong, contradicted, or the user corrected the behavior\n\nAlso check: did the user express frustration, correct the agent, or say "stop doing X"? If so, penalize related skills heavily.\nOutput ONLY the JSON object.`;
              const evalRaw = await callLLMChat('Output ONLY a JSON object with a "scores" field.', [{ role: 'user', content: evalPrompt }], memSettings);
              const evalCleaned = evalRaw.replace(/```json\s*/g, '').replace(/```/g, '').trim();
              const evalResult = JSON.parse(evalCleaned);
              if (evalResult?.scores) {
                for (const [name, newScore] of Object.entries(evalResult.scores)) {
                  const skill = urchinSkills.find(s => s.name === name);
                  if (skill && typeof newScore === 'number') {
                    const oldScore = skill.score ?? 50;
                    skill.score = Math.round(oldScore * 0.6 + Math.max(0, Math.min(100, newScore)) * 0.4);
                    skill.lastEvalAt = Date.now();
                    skill.evalCount = (skill.evalCount || 0) + 1;
                  }
                }
                const before = urchinSkills.length;
                const pruned = urchinSkills.filter(s => {
                  if ((s.score ?? 50) <= 10 && (s.evalCount || 0) >= 2) return false;
                  if ((s.usageCount || 0) > 30 && (s.score ?? 50) <= 20) return false;
                  const age = Date.now() - (s.learnedAt || 0);
                  if (age > 30 * 24 * 60 * 60 * 1000 && (s.usageCount || 0) === 0) return false;
                  return true;
                });
                await chrome.storage.local.set({ urchinSkills: pruned });
                if (pruned.length < before) {
                  const { urchinMemory: evalMem = {} } = await chrome.storage.local.get('urchinMemory');
                  evalMem[`_skill_prune_${Date.now()}`] = `Pruned ${before - pruned.length} low-scoring skills. ${pruned.length} remaining.`;
                  await chrome.storage.local.set({ urchinMemory: evalMem });
                }
              }
            }
          } catch (_) {}
        }
      } catch (_) {}
    }, 100);

  /* ═══ BUILD_SITE: uses the better builder prompt ═══ */
  } else if (task === 'BUILD_SITE') {
    let imgCtx = '';
    if (uploadedFiles && uploadedFiles.length > 0) {
      const imageFiles = uploadedFiles.filter(f => f.type && f.type.startsWith('image/'));
      if (imageFiles.length > 0) {
        imgCtx = '\n\nIMAGES AVAILABLE — use these data URLs as img src attributes in the HTML:\n' +
          imageFiles.map(f => `- ${f.name}: ${f.dataUrl.slice(0, 80)}...`).join('\n');
      }
    }
    const project = await buildSiteViaLLM(userInput + contextStr, imgCtx, settings, addStep, 2, uploadedFiles, true);
    if (!project || !project.files) {
      log.endTime = Date.now();
      await saveLog(log);
      const reason = project?._buildError || 'LLM did not return valid project';
      return { requestId, success: false, error: `Build failed — ${reason}`, log };
    }
    await chrome.storage.local.set({ urchinCurrentProject: project });
    result = project;

  /* ═══ DEPLOY: strict JSON with retries ═══ */
  } else {
    const fullInput = userInput + contextStr;
    let lastError = '';
    for (let attempt = 0; attempt < 3; attempt++) {
      addStep('llm_call', { attempt: attempt + 1 });
      try {
        const prompt = attempt === 0 ? fullInput : `${fullInput}\n\nPrevious attempt had error: ${lastError}\nPlease fix and output valid JSON only.`;
        const raw = await callLLM(systemPrompt, prompt, settings);
        addStep('llm_response', { length: raw.length, preview: raw.slice(0, 200) });
        const cleaned = raw.replace(/```json\s*/g, '').replace(/```\s*/g, '').trim();
        result = JSON.parse(cleaned);
        addStep('parse_ok', { attempt: attempt + 1 });
        break;
      } catch (e) {
        lastError = e.message;
        addStep('parse_error', { attempt: attempt + 1, error: e.message });
      }
    }
    if (!result) {
      addStep('fail', { message: lastError || 'Failed to get valid JSON' });
      log.endTime = Date.now();
      await saveLog(log);
      return { requestId, success: false, error: lastError || 'LLM did not return valid JSON.', log };
    }
  }

  if (task === 'PUMPFUN_LAUNCH_PACKET' && result.website) {
    const v = tools.validateProjectFiles(result.website);
    addStep('validate_pump_website', v);
  }

  addStep('complete', { task });
  log.endTime = Date.now();
  delete log._pageContext;
  delete log._history;

  await saveLog(log);
  return { requestId, success: true, data: result, log };
}

async function handleSolanaScan(userInput, context, settings, log, addStep, requestId) {
  if (!settings.solanaRpc) {
    addStep('error', { message: 'No Solana RPC URL configured.' });
    return { requestId, success: false, error: 'No Solana RPC URL. Set it in Settings.', log };
  }

  let mint = userInput.trim();
  const mints = tools.detectSolanaMints(userInput);
  if (mints.length > 0) mint = mints[0];
  if (!mint || mint.length < 32) {
    return { requestId, success: false, error: 'No valid Solana mint address found.', log };
  }

  addStep('scan_start', { mint });
  try {
    const scanResult = await tools.solanaScanMint(mint, settings.solanaRpc);
    addStep('scan_complete', { mint });

    let summary = `Token ${mint}: Top1 holds ${scanResult.top1Pct}%, Top5 hold ${scanResult.top5Pct}%, Top10 hold ${scanResult.top10Pct}%. Fresh/empty owner accounts in top10: ${scanResult.freshOwnerCount}.`;

    if (settings.enableSummaries && settings.llmApiKey) {
      try {
        addStep('llm_summary', {});
        const raw = await callLLM(
          'You are a crypto analyst. Summarize this token scan data concisely. Output ONLY JSON: {"summary":"string"}',
          JSON.stringify(scanResult), settings
        );
        const cleaned = raw.replace(/```json\s*/g, '').replace(/```\s*/g, '').trim();
        const parsed = JSON.parse(cleaned);
        if (parsed.summary) summary = parsed.summary;
      } catch (_) { /* keep default summary */ }
    }

    addStep('complete', { task: 'SOLANA_SCAN' });
    log.endTime = Date.now();
    await saveLog(log);
    return { requestId, success: true, data: { ...scanResult, summary }, log };
  } catch (e) {
    addStep('scan_error', { error: e.message });
    return { requestId, success: false, error: `Scan failed: ${e.message}`, log };
  }
}

/* ── Log persistence ── */
async function saveLog(log) {
  try {
    const { urchinLogs = [] } = await chrome.storage.local.get('urchinLogs');
    urchinLogs.push(log);
    while (urchinLogs.length > 50) urchinLogs.shift();
    await chrome.storage.local.set({ urchinLogs });
  } catch (_) {}
}

/* ── Message Handler ── */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'URCHINLOOP_REQUEST') {
    (async () => {
      // Keep service worker alive during long LLM calls
      const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(), 20000);
      try {
        const settings = await getSettings();
        const result = await urchinLoop(msg.task, msg.input, msg.context || [], settings, msg.pageContext, msg.history, msg.uploadedFiles);
        sendResponse(result);
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      } finally {
        clearInterval(keepAlive);
      }
    })();
    return true;
  }

  if (msg.action === 'LIST_NETLIFY_SITES') {
    (async () => {
      try {
        const settings = await getSettings();
        const sites = await listNetlifySites(settings);
        sendResponse({ success: true, sites });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }

  if (msg.action === 'DELETE_NETLIFY_SITE') {
    (async () => {
      try {
        const settings = await getSettings();
        await deleteNetlifySite(msg.siteId, settings);
        sendResponse({ success: true });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }

  if (msg.action === 'DEPLOY_NETLIFY') {
    (async () => {
      const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(), 20000);
      try {
        const settings = await getSettings();
        const result = await deployToNetlify(msg.project, settings);
        sendResponse({ success: true, ...result });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      } finally {
        clearInterval(keepAlive);
      }
    })();
    return true;
  }

  if (msg.action === 'UPDATE_NETLIFY') {
    (async () => {
      const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(), 20000);
      try {
        const settings = await getSettings();
        const result = await updateNetlifySite(msg.project, msg.siteId, settings);
        sendResponse({ success: true, ...result });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      } finally {
        clearInterval(keepAlive);
      }
    })();
    return true;
  }

  if (msg.action === 'EDIT_SITE_REQUEST') {
    (async () => {
      const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(), 20000);
      try {
        const settings = await getSettings();
        const { urchinCurrentProject } = await chrome.storage.local.get('urchinCurrentProject');
        if (!urchinCurrentProject || !urchinCurrentProject.files) {
          sendResponse({ success: false, error: 'No site built yet. Build one first.' });
          return;
        }
        const addStep = () => {};
        const edited = await editSiteViaLLM(urchinCurrentProject, msg.changes, settings, addStep);
        if (edited && edited.files) {
          await chrome.storage.local.set({ urchinCurrentProject: edited });
          sendResponse({ success: true, data: edited });
        } else {
          sendResponse({ success: false, error: 'Edit failed — LLM did not return valid project.' });
        }
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      } finally {
        clearInterval(keepAlive);
      }
    })();
    return true;
  }

  if (msg.action === 'GRAB_PAGE_IMAGES') {
    (async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab?.id) { sendResponse({ success: false, error: 'No active tab' }); return; }
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            const imgs = document.querySelectorAll('img[src]');
            const seen = new Set();
            const list = [];
            for (const img of imgs) {
              const src = img.src;
              if (!src || seen.has(src) || src.startsWith('data:') || src.includes('spacer') || src.includes('pixel')) continue;
              if (img.naturalWidth < 32 || img.naturalHeight < 32) continue;
              seen.add(src);
              list.push({ src, alt: img.alt || '', w: img.naturalWidth, h: img.naturalHeight });
              if (list.length >= 30) break;
            }
            return list;
          }
        });
        const images = results?.[0]?.result || [];
        sendResponse({ success: true, images });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }

  if (msg.action === 'CAPTURE_SCREENSHOT') {
    (async () => {
      try {
        const dataUrl = await captureScreenshot();
        sendResponse({ success: true, dataUrl });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }

  if (msg.action === 'ZIP_PROJECT') {
    (async () => {
      try {
        const ab = await tools.zipProject(msg.project);
        const arr = Array.from(new Uint8Array(ab));
        sendResponse({ success: true, data: arr, name: (msg.project.projectName || 'project') + '.zip' });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }

  if (msg.action === 'GET_SETTINGS') {
    getSettings().then(s => sendResponse(s));
    return true;
  }

  if (msg.action === 'USER_FEEDBACK') {
    (async () => {
      try {
        const { urchinSkills = [] } = await chrome.storage.local.get('urchinSkills');
        const delta = msg.positive ? 12 : -18;
        let updated = false;
        for (const skill of urchinSkills) {
          if (skill.lastUsedAt && Date.now() - skill.lastUsedAt < 5 * 60 * 1000) {
            skill.score = Math.max(0, Math.min(100, Math.round((skill.score ?? 50) + delta)));
            skill.feedbackCount = (skill.feedbackCount || 0) + 1;
            skill.lastFeedbackAt = Date.now();
            updated = true;
          }
        }
        if (updated) await chrome.storage.local.set({ urchinSkills });

        const { urchinMemory = {} } = await chrome.storage.local.get('urchinMemory');
        const fbKey = `_feedback_${Date.now()}`;
        urchinMemory[fbKey] = msg.positive ? 'positive' : 'negative';
        const fbKeys = Object.keys(urchinMemory).filter(k => k.startsWith('_feedback_'));
        if (fbKeys.length > 50) {
          for (const k of fbKeys.slice(0, fbKeys.length - 50)) delete urchinMemory[k];
        }
        await chrome.storage.local.set({ urchinMemory });

        sendResponse({ success: true, skillsUpdated: updated });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }

  if (msg.action === 'GET_LOGS') {
    chrome.storage.local.get('urchinLogs').then(r => sendResponse(r.urchinLogs || []));
    return true;
  }

  if (msg.action === 'EXPORT_CHAT') {
    (async () => {
      try {
        const { urchinChatHistory = [] } = await chrome.storage.local.get('urchinChatHistory');
        let md = `# urchinbot Chat Export\n_Exported: ${new Date().toLocaleString()}_\n\n---\n\n`;
        for (const m of urchinChatHistory) {
          const ts = m.ts ? new Date(m.ts).toLocaleString() : '';
          const role = m.role === 'user' ? '**You**' : '**urchinbot**';
          md += `### ${role}${ts ? ' — ' + ts : ''}\n\n${m.text}\n\n---\n\n`;
        }
        sendResponse({ success: true, markdown: md, count: urchinChatHistory.length });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }

  // ──── Scheduled watch: set/list/clear price & wallet alerts ────
  if (msg.action === 'SET_WATCH') {
    (async () => {
      try {
        const { urchinWatches = [] } = await chrome.storage.local.get('urchinWatches');
        const watch = { id: `w-${Date.now()}`, type: msg.watchType, target: msg.target, condition: msg.condition, created: Date.now() };
        urchinWatches.push(watch);
        await chrome.storage.local.set({ urchinWatches });
        chrome.alarms.create('urchin-watch', { periodInMinutes: 5 });
        sendResponse({ success: true, watch });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }

  if (msg.action === 'LIST_WATCHES') {
    chrome.storage.local.get('urchinWatches').then(r => sendResponse({ success: true, watches: r.urchinWatches || [] }));
    return true;
  }

  if (msg.action === 'CLEAR_WATCHES') {
    (async () => {
      await chrome.storage.local.set({ urchinWatches: [] });
      chrome.alarms.clear('urchin-watch');
      sendResponse({ success: true });
    })();
    return true;
  }

  if (msg.action === 'GET_LAUNCH_DATA') {
    chrome.storage.local.get('urchinLaunchData').then(r => sendResponse(r.urchinLaunchData || null));
    return true;
  }

  if (msg.action === 'SAVE_LAUNCH_DATA') {
    chrome.storage.local.set({ urchinLaunchData: msg.data }).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.action === 'AUTOFILL_PUMP') {
    (async () => {
      try {
        const data = msg.data;

        // Get image bytes — from data URL (uploaded) or remote URL
        let imageBytes = null;
        let imageMime = 'image/png';
        if (data.imageDataUrl && data.imageDataUrl.startsWith('data:')) {
          try {
            const [header, b64] = data.imageDataUrl.split(',');
            imageMime = (header.match(/data:([^;]+)/) || [])[1] || 'image/png';
            const binary = atob(b64);
            imageBytes = Array.from({ length: binary.length }, (_, i) => binary.charCodeAt(i));
          } catch (_) { /* data URL parse failed */ }
        } else if (data.imageUrl && !data.imageUrl.startsWith('data:')) {
          try {
            const imgResp = await fetch(data.imageUrl);
            if (imgResp.ok) {
              imageMime = imgResp.headers.get('content-type') || 'image/png';
              const ab = await imgResp.arrayBuffer();
              imageBytes = Array.from(new Uint8Array(ab));
            }
          } catch (_) { /* image fetch failed, skip */ }
        }

        const tab = await chrome.tabs.create({ url: 'https://pump.fun/create', active: true });
        const waitForLoad = (tabId) => new Promise(resolve => {
          const listener = (id, info) => {
            if (id === tabId && info.status === 'complete') {
              chrome.tabs.onUpdated.removeListener(listener);
              resolve();
            }
          };
          chrome.tabs.onUpdated.addListener(listener);
          setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); resolve(); }, 10000);
        });
        await waitForLoad(tab.id);
        await new Promise(r => setTimeout(r, 2000));

        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: (name, symbol, desc, imgBytes, imgMime) => {
            function fillInput(el, value) {
              if (!el) return;
              const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
              const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
              if (setter) setter.call(el, value); else el.value = value;
              el.dispatchEvent(new Event('input', { bubbles: true }));
              el.dispatchEvent(new Event('change', { bubbles: true }));
            }

            const inputs = document.querySelectorAll('input[type="text"], input:not([type]), textarea');
            const all = [...inputs].filter(e => e.type !== 'hidden' && e.type !== 'file');
            const nameEl = all.find(e => /name/i.test(e.placeholder || e.getAttribute('aria-label') || '')) || all[0];
            const symEl = all.find(e => /ticker|symbol/i.test(e.placeholder || e.getAttribute('aria-label') || '')) || all[1];
            const descEl = all.find(e => e.tagName === 'TEXTAREA') || all.find(e => /desc/i.test(e.placeholder || e.getAttribute('aria-label') || '')) || all[2];
            fillInput(nameEl, name || '');
            fillInput(symEl, symbol || '');
            fillInput(descEl, desc || '');

            // Auto-upload image
            if (imgBytes && imgBytes.length > 0) {
              try {
                const ext = (imgMime || '').match(/jpe?g/) ? 'jpg' : (imgMime || '').includes('gif') ? 'gif' : 'png';
                const blob = new Blob([new Uint8Array(imgBytes)], { type: imgMime || 'image/png' });
                const file = new File([blob], `token-image.${ext}`, { type: imgMime || 'image/png', lastModified: Date.now() });
                const dt = new DataTransfer();
                dt.items.add(file);

                // Try setting on <input type="file"> directly
                const fileInput = document.querySelector('input[type="file"]');
                if (fileInput) {
                  fileInput.files = dt.files;
                  fileInput.dispatchEvent(new Event('change', { bubbles: true }));
                  fileInput.dispatchEvent(new Event('input', { bubbles: true }));
                }

                // Also try drag-and-drop on upload zones
                const zones = document.querySelectorAll(
                  '[class*="dropzone"], [class*="upload"], [class*="drag"], [class*="image"], label[for], [class*="file"]'
                );
                for (const zone of zones) {
                  zone.dispatchEvent(new DragEvent('dragenter', { bubbles: true, dataTransfer: dt }));
                  zone.dispatchEvent(new DragEvent('dragover', { bubbles: true, cancelable: true, dataTransfer: dt }));
                  zone.dispatchEvent(new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: dt }));
                }
              } catch (_) { /* image upload best-effort */ }
            }
          },
          args: [
            data.name || data.tokenName || '',
            data.symbol || data.tokenSymbol || '',
            data.description || '',
            imageBytes,
            imageMime
          ]
        });
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
    })();
    return true;
  }

  if (msg.action === 'OPEN_OVERLAY') {
    (async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab?.id) { sendResponse({ ok: false }); return; }

        let reached = false;
        try {
          await chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_OVERLAY', tab: msg.tab });
          reached = true;
        } catch (_) {}

        if (!reached) {
          try { await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['styles.css'] }); } catch (_) {}
          try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] }); } catch (_) {}
          await new Promise(r => setTimeout(r, 300));
          try { await chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_OVERLAY', tab: msg.tab }); } catch (_) {}
        }
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
    })();
    return true;
  }

  if (msg.action === 'OPEN_SIDE_PANEL') {
    (async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab && chrome.sidePanel) {
          await chrome.sidePanel.open({ windowId: tab.windowId });
        }
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
    })();
    return true;
  }

  if (msg.action === 'GET_TASK_QUEUE') {
    (async () => {
      try {
        const { urchinTaskQueue = [] } = await chrome.storage.local.get('urchinTaskQueue');
        const { urchinAutoResults = [] } = await chrome.storage.local.get('urchinAutoResults');
        sendResponse({ success: true, queue: urchinTaskQueue, results: urchinAutoResults });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }

  if (msg.action === 'CLEAR_TASK_QUEUE') {
    (async () => {
      try {
        const { urchinTaskQueue = [] } = await chrome.storage.local.get('urchinTaskQueue');
        for (const t of urchinTaskQueue) {
          if (t.status === 'pending') chrome.alarms.clear(t.id);
        }
        await chrome.storage.local.set({ urchinTaskQueue: [], urchinAutoResults: [] });
        sendResponse({ success: true });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }

  if (msg.action === 'ACK_AUTO_RESULT') {
    (async () => {
      try {
        const { urchinAutoResults = [] } = await chrome.storage.local.get('urchinAutoResults');
        const remaining = urchinAutoResults.filter(r => r.id !== msg.taskId);
        await chrome.storage.local.set({ urchinAutoResults: remaining });
        sendResponse({ success: true });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }

  // Fallback — unknown action, respond immediately to prevent port closure warning
  return false;
});

/* ── Autonomous Task Runner — executes queued tasks through urchinLoop ── */
async function runAutonomousTask(taskInput, taskId) {
  const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(), 20000);
  try {
    const settings = await getSettings();
    if (!settings.llmApiKey) return { success: false, error: 'No LLM API key configured' };

    const { urchinChatHistory = [] } = await chrome.storage.local.get('urchinChatHistory');

    const result = await urchinLoop(
      'ASK',
      `[AUTONOMOUS BACKGROUND TASK] ${taskInput}\n\nYou are running autonomously in the background — the user is NOT waiting for a response. Execute this task fully, use any tools needed, and produce a comprehensive result. If this task warrants scheduling follow-ups, use SET_TIMER or SCHEDULE_TASK.`,
      [],
      settings,
      null,
      urchinChatHistory.slice(-10),
      null
    );

    const answer = result?.success && result?.data?.answer
      ? result.data.answer
      : (result?.error || 'Autonomous task produced no result.');

    await pushAutonomousResult(taskId, taskInput, answer);
    return { success: true, answer };
  } catch (e) {
    await pushAutonomousResult(taskId, taskInput, `Task failed: ${e.message}`);
    return { success: false, error: e.message };
  } finally {
    clearInterval(keepAlive);
  }
}

async function pushAutonomousResult(taskId, taskInput, answer) {
  chrome.notifications.create(`urchin-auto-${Date.now()}`, {
    type: 'basic', iconUrl: 'icons/icon128.png',
    title: 'urchinbot — Background Task Complete',
    message: answer.slice(0, 200)
  });

  const { urchinAutoResults = [] } = await chrome.storage.local.get('urchinAutoResults');
  urchinAutoResults.push({ id: taskId, input: taskInput, answer, completedAt: Date.now() });
  while (urchinAutoResults.length > 30) urchinAutoResults.shift();
  await chrome.storage.local.set({ urchinAutoResults });

  try {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      try {
        chrome.tabs.sendMessage(tab.id, {
          action: 'URCHIN_AUTONOMOUS_RESULT',
          taskId, input: taskInput, answer, completedAt: Date.now()
        });
      } catch (_) {}
    }
  } catch (_) {}
}

/* ── Scheduled Watches + Autonomous Task Alarms ── */
chrome.alarms.onAlarm.addListener(async (alarm) => {

  // ── Autonomous task alarms (SET_TIMER / SCHEDULE_TASK) ──
  if (alarm.name.startsWith('urchin-autotask-')) {
    try {
      const { urchinTaskQueue = [] } = await chrome.storage.local.get('urchinTaskQueue');
      const task = urchinTaskQueue.find(t => t.id === alarm.name);
      if (task && task.status === 'pending') {
        task.status = 'running';
        task.startedAt = Date.now();
        await chrome.storage.local.set({ urchinTaskQueue });

        const result = await runAutonomousTask(task.input, task.id);

        const { urchinTaskQueue: q2 = [] } = await chrome.storage.local.get('urchinTaskQueue');
        const idx = q2.findIndex(t => t.id === task.id);
        if (idx !== -1) {
          q2[idx].status = result.success ? 'done' : 'failed';
          q2[idx].completedAt = Date.now();
          q2[idx].result = result.success ? result.answer?.slice(0, 2000) : result.error;
          while (q2.length > 50) q2.shift();
          await chrome.storage.local.set({ urchinTaskQueue: q2 });
        }
      }
    } catch (_) {}
    return;
  }

  // ── Recurring monitor alarms (MONITOR tool) ──
  if (alarm.name.startsWith('urchin-monitor-')) {
    try {
      const { urchinMonitors = [] } = await chrome.storage.local.get('urchinMonitors');
      const monitor = urchinMonitors.find(m => m.id === alarm.name);
      if (monitor && monitor.status === 'active') {
        if (Date.now() >= monitor.expiresAt) {
          chrome.alarms.clear(monitor.id);
          monitor.status = 'expired';
          monitor.stoppedAt = Date.now();
          await chrome.storage.local.set({ urchinMonitors });
          chrome.notifications.create(`urchin-mon-expire-${Date.now()}`, {
            type: 'basic', iconUrl: 'icons/icon128.png',
            title: 'urchinbot Monitor Expired',
            message: `Monitor for "${monitor.target}" has expired after ${monitor.checkCount} checks. Say "monitor ${monitor.target}" to restart.`
          });
          await pushAutonomousResult(monitor.id, `Monitor expired: ${monitor.target}`,
            `Monitor for **${monitor.target}** has expired after ${monitor.checkCount} checks over ${Math.round((monitor.expiresAt - monitor.createdAt) / 60000)} minutes. Say "monitor ${monitor.target}" if you want to restart it.`);
          return;
        }

        monitor.checkCount++;
        monitor.lastCheckAt = Date.now();
        await chrome.storage.local.set({ urchinMonitors });

        const checksLeft = Math.ceil((monitor.expiresAt - Date.now()) / (monitor.interval * 60000));
        const taskInput = `${monitor.instructions}\n\nTarget: ${monitor.target}\nThis is check #${monitor.checkCount} (recurring every ${monitor.interval} min, ~${checksLeft} checks remaining).\nCompare with any previous results. Highlight what CHANGED since last check. If nothing significant changed, keep it brief.`;

        await runAutonomousTask(taskInput, `${monitor.id}-check-${monitor.checkCount}`);
      }
    } catch (_) {}
    return;
  }

  // ── Wallet activity tracker alarm (zero LLM) ──
  if (alarm.name === 'urchin-wallet-tracker') {
    await runWalletTrackerCycle();
    return;
  }

  // ── Daily digest alarm ──
  if (alarm.name === 'urchin-daily-digest') {
    try {
      const { urchinDigestConfig = {} } = await chrome.storage.local.get('urchinDigestConfig');
      if (!urchinDigestConfig.enabled) { chrome.alarms.clear('urchin-daily-digest'); return; }
      const { urchinWatchlist = [] } = await chrome.storage.local.get('urchinWatchlist');
      if (urchinWatchlist.length === 0) {
        await pushAutonomousResult('daily-digest', 'Daily Digest', 'Your watchlist is empty — add wallets with "watch wallet ADDRESS" to get PnL in your daily digest.');
        return;
      }
      const settings = await getSettings();
      if (!settings.solanaRpc || !settings.llmApiKey) return;

      const { urchinWalletActivity = [] } = await chrome.storage.local.get('urchinWalletActivity');
      const last24h = urchinWalletActivity.filter(e => Date.now() - e.time < 86400000);
      let activitySummary = '';
      if (last24h.length > 0) {
        activitySummary = '\n\nRecent wallet activity (last 24h, already collected — DO NOT re-fetch):\n' +
          last24h.slice(-30).map(e => `- ${e.label}: ${e.event} ${e.symbol || ''} ${e.amount || ''} ${e.valueUsd ? '$' + e.valueUsd : ''} (${new Date(e.time).toLocaleTimeString()})`).join('\n');
      }

      const walletList = urchinWatchlist.map(w => `${w.label}: ${w.address}`).join('\n');
      const taskInput = `[DAILY DIGEST] Run a PnL check on each of these watched wallets and produce a concise morning digest:\n${walletList}\n\nFor each wallet: use PNL_CHECK to get current value. Compare to previous snapshot if available. Highlight biggest movers (tokens that gained or lost the most).${activitySummary}\n\nInclude the activity summary in your digest. End with a brief portfolio summary across all wallets. Keep it readable and concise — this is a morning briefing.`;

      await runAutonomousTask(taskInput, `daily-digest-${Date.now()}`);
    } catch (_) {}
    return;
  }

  // ── Reminder alarms — now run through urchinLoop for intelligent execution ──
  if (alarm.name.startsWith('urchin-remind-')) {
    try {
      const { urchinReminders = [] } = await chrome.storage.local.get('urchinReminders');
      const reminder = urchinReminders.find(r => r.id === alarm.name);
      if (reminder) {
        const remaining = urchinReminders.filter(r => r.id !== alarm.name);
        await chrome.storage.local.set({ urchinReminders: remaining });

        await runAutonomousTask(reminder.task, alarm.name);
      }
    } catch (_) {}
    return;
  }

  // ── Price/wallet watch alarms ──
  if (alarm.name !== 'urchin-watch') return;
  try {
    const { urchinWatches = [] } = await chrome.storage.local.get('urchinWatches');
    if (urchinWatches.length === 0) { chrome.alarms.clear('urchin-watch'); return; }
    const settings = await getSettings();
    const triggered = [];

    for (const w of urchinWatches) {
      try {
        if (w.type === 'price') {
          const priceData = await getTokenPrice(w.target, settings);
          if (priceData.price) {
            const price = parseFloat(priceData.price);
            if (w.condition.below && price < w.condition.below) {
              triggered.push({ watch: w, message: `${priceData.symbol || w.target} dropped to $${price} (below $${w.condition.below})` });
            }
            if (w.condition.above && price > w.condition.above) {
              triggered.push({ watch: w, message: `${priceData.symbol || w.target} rose to $${price} (above $${w.condition.above})` });
            }
          }
        } else if (w.type === 'wallet') {
          if (!settings.solanaRpc) continue;
          const balance = await getWalletBalance(w.target, settings.solanaRpc);
          if (w.condition.solBelow && balance.solBalance < w.condition.solBelow) {
            triggered.push({ watch: w, message: `Wallet ${w.target.slice(0, 8)}… SOL dropped to ${balance.solBalance.toFixed(4)}` });
          }
        }
      } catch (_) {}
    }

    if (triggered.length > 0) {
      for (const t of triggered) {
        chrome.notifications.create(`urchin-alert-${Date.now()}`, {
          type: 'basic', iconUrl: 'icons/icon128.png',
          title: 'urchinbot Alert', message: t.message
        });
      }
      const remaining = urchinWatches.filter(w => !triggered.some(t => t.watch.id === w.id));
      await chrome.storage.local.set({ urchinWatches: remaining });
      if (remaining.length === 0) chrome.alarms.clear('urchin-watch');
    }
  } catch (_) {}
});

/* ── Briefing handler ── */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'GET_BRIEFING') {
    (async () => {
      try {
        const settings = await getSettings();
        const briefing = await generateBriefing(settings);
        sendResponse({ success: true, briefing });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }
});
