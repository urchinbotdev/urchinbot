/* test-deploy.js — Validates the direct pump.fun deploy flow against mainnet.
   Run: node test-deploy.js [rpc_url]
   Uses a throwaway keypair (no real SOL spent). Tests PDA derivation,
   global account parsing, tx building, and RPC simulation. */

// --- Bootstrap: load solana-lite.js in Node context ---
const crypto = require('crypto');
globalThis.self = globalThis;
globalThis.crypto = { subtle: crypto.webcrypto.subtle, getRandomValues: crypto.randomFillSync.bind(crypto) };
globalThis.nacl = require('./lib/nacl-fast.min.js') || globalThis.nacl;
if (!globalThis.nacl && typeof nacl !== 'undefined') globalThis.nacl = nacl;
require('./lib/solana-lite.js');

const RPC = process.argv[2] || 'https://api.mainnet-beta.solana.com';
const { PublicKey, Keypair, findProgramAddress, getAssociatedTokenAddress,
  concatBytes, borshString, borshU64, buildLegacyTransaction, signSerializedTx,
  sendRawTx, bs58encode, rpc } = SolanaLite;

const PUMP = new PublicKey('6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P');
const MAYHEM = new PublicKey('MAyhSmzXzV1pTf7LsNkrNwkWKTo4ougAJ1PPg47MD4e');
const FEE_PROG = new PublicKey('pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ');
const COMPUTE_BUDGET = new PublicKey('ComputeBudget111111111111111111111111111111');
const te = (s) => new TextEncoder().encode(s);

let passed = 0, failed = 0;
function ok(label) { passed++; console.log(`  ✓ ${label}`); }
function fail(label, err) { failed++; console.log(`  ✗ ${label}: ${err}`); }

async function main() {
  console.log(`\n🧪 Pump.fun Direct Deploy Test — RPC: ${RPC}\n`);

  // 1. PDA derivation
  console.log('1. PDA Derivation');
  const [globalPda, globalBump] = await findProgramAddress([te('global')], PUMP);
  console.log(`   Global PDA: ${globalPda.toBase58()} (bump ${globalBump})`);
  ok('Global PDA derived');

  const testMint = Keypair.generate();
  const mint = testMint.publicKey;
  const [mintAuth] = await findProgramAddress([te('mint-authority')], PUMP);
  const [bondingCurve] = await findProgramAddress([te('bonding-curve'), mint.toBytes()], PUMP);
  const assocBC = await getAssociatedTokenAddress(mint, bondingCurve, PublicKey.TOKEN_2022);
  const [eventAuth] = await findProgramAddress([te('__event_authority')], PUMP);
  const [globalParams] = await findProgramAddress([te('global-params')], MAYHEM);
  const [solVault] = await findProgramAddress([te('sol-vault')], MAYHEM);
  const [mayhemState] = await findProgramAddress([te('mayhem-state'), mint.toBytes()], MAYHEM);
  const mayhemTokenVault = await getAssociatedTokenAddress(mint, solVault, PublicKey.TOKEN_2022);
  ok('All createV2 PDAs derived');

  // 2. Fetch & parse global account
  console.log('\n2. Global Account Fetch');
  let globalData;
  try {
    const info = await rpc('getAccountInfo', [
      globalPda.toBase58(), { encoding: 'base64', commitment: 'confirmed' }
    ], RPC);
    if (!info?.value?.data) throw new Error('Account not found');
    const raw = Uint8Array.from(atob(info.value.data[0]), c => c.charCodeAt(0));
    const dv = new DataView(raw.buffer, raw.byteOffset, raw.byteLength);
    globalData = {
      feeRecipient: new PublicKey(raw.slice(41, 73)),
      initialVirtualTokenReserves: dv.getBigUint64(73, true),
      initialVirtualSolReserves: dv.getBigUint64(81, true),
      initialRealTokenReserves: dv.getBigUint64(89, true),
      tokenTotalSupply: dv.getBigUint64(97, true),
      feeBasisPoints: dv.getBigUint64(105, true),
    };
    console.log(`   feeRecipient: ${globalData.feeRecipient.toBase58()}`);
    console.log(`   initialVirtualTokenReserves: ${globalData.initialVirtualTokenReserves}`);
    console.log(`   initialVirtualSolReserves: ${globalData.initialVirtualSolReserves} (${Number(globalData.initialVirtualSolReserves) / 1e9} SOL)`);
    console.log(`   initialRealTokenReserves: ${globalData.initialRealTokenReserves}`);
    console.log(`   tokenTotalSupply: ${globalData.tokenTotalSupply}`);
    console.log(`   feeBasisPoints: ${globalData.feeBasisPoints}`);
    if (globalData.initialVirtualSolReserves > 0n && globalData.initialVirtualTokenReserves > 0n) {
      ok('Global account parsed successfully');
    } else {
      fail('Global account', 'Reserves are zero');
    }
  } catch (e) {
    fail('Global account fetch', e.message);
    console.log('   ⚠ Continuing with hardcoded defaults...');
    globalData = {
      feeRecipient: new PublicKey('CebN5WGQ4jvEPvsVU4EoHEpgzq1VV7AbCJ5GP1pA59Cp'),
      initialVirtualTokenReserves: 1073000000000000n,
      initialVirtualSolReserves: 30000000000n,
      initialRealTokenReserves: 793100000000000n,
      tokenTotalSupply: 1000000000000000n,
      feeBasisPoints: 100n,
    };
  }

  // 3. Buy amount calculation
  console.log('\n3. Buy Amount Calculation');
  const devBuySol = 0.1;
  const solLamports = BigInt(Math.round(devBuySol * 1e9));
  const vtr = globalData.initialVirtualTokenReserves;
  const vsr = globalData.initialVirtualSolReserves;
  const feeBps = globalData.feeBasisPoints;
  const adjustedSol = solLamports * 10000n / (10000n + feeBps);
  const tokenAmount = adjustedSol * vtr / (vsr + adjustedSol);
  const maxSolCost = solLamports + solLamports * 25n / 100n;
  console.log(`   ${devBuySol} SOL → ~${tokenAmount} tokens (maxSolCost ${maxSolCost} lamports w/ 25% slippage)`);
  console.log(`   adjustedSol after fees: ${adjustedSol} lamports`);
  if (tokenAmount > 0n) ok('Buy amount calculation (using SDK buy formula)'); else fail('Buy calc', 'zero tokens');

  // 4. Build full transaction
  console.log('\n4. Transaction Building');
  const user = Keypair.generate();
  const instructions = [];

  // Compute budget
  const cuLimitData = new Uint8Array(5);
  cuLimitData[0] = 2;
  new DataView(cuLimitData.buffer).setUint32(1, 600000, true);
  instructions.push({ programId: COMPUTE_BUDGET, keys: [], data: cuLimitData });
  const cuPriceData = new Uint8Array(9);
  cuPriceData[0] = 3;
  cuPriceData.set(borshU64(833333n), 1);
  instructions.push({ programId: COMPUTE_BUDGET, keys: [], data: cuPriceData });

  // createV2
  const createData = concatBytes(
    new Uint8Array([214, 144, 76, 236, 95, 139, 49, 180]),
    borshString('TestToken'), borshString('TEST'),
    borshString('https://example.com/metadata.json'),
    user.publicKey.toBytes(),
    new Uint8Array([0]), new Uint8Array([0])
  );
  instructions.push({
    programId: PUMP,
    keys: [
      { pubkey: mint, isSigner: true, isWritable: true },
      { pubkey: mintAuth, isSigner: false, isWritable: false },
      { pubkey: bondingCurve, isSigner: false, isWritable: true },
      { pubkey: assocBC, isSigner: false, isWritable: true },
      { pubkey: globalPda, isSigner: false, isWritable: false },
      { pubkey: user.publicKey, isSigner: true, isWritable: true },
      { pubkey: PublicKey.SYSTEM_PROGRAM, isSigner: false, isWritable: false },
      { pubkey: PublicKey.TOKEN_2022, isSigner: false, isWritable: false },
      { pubkey: PublicKey.ASSOCIATED_TOKEN, isSigner: false, isWritable: false },
      { pubkey: MAYHEM, isSigner: false, isWritable: true },
      { pubkey: globalParams, isSigner: false, isWritable: false },
      { pubkey: solVault, isSigner: false, isWritable: true },
      { pubkey: mayhemState, isSigner: false, isWritable: true },
      { pubkey: mayhemTokenVault, isSigner: false, isWritable: true },
      { pubkey: eventAuth, isSigner: false, isWritable: false },
      { pubkey: PUMP, isSigner: false, isWritable: false },
    ],
    data: createData
  });

  // extendAccount
  instructions.push({
    programId: PUMP,
    keys: [
      { pubkey: bondingCurve, isSigner: false, isWritable: true },
      { pubkey: user.publicKey, isSigner: true, isWritable: false },
      { pubkey: PublicKey.SYSTEM_PROGRAM, isSigner: false, isWritable: false },
      { pubkey: eventAuth, isSigner: false, isWritable: false },
      { pubkey: PUMP, isSigner: false, isWritable: false },
    ],
    data: new Uint8Array([234, 102, 194, 203, 150, 72, 62, 229])
  });

  // createAssociatedTokenAccountIdempotent
  const associatedUser = await getAssociatedTokenAddress(mint, user.publicKey, PublicKey.TOKEN_2022);
  instructions.push({
    programId: PublicKey.ASSOCIATED_TOKEN,
    keys: [
      { pubkey: user.publicKey, isSigner: true, isWritable: true },
      { pubkey: associatedUser, isSigner: false, isWritable: true },
      { pubkey: user.publicKey, isSigner: false, isWritable: false },
      { pubkey: mint, isSigner: false, isWritable: false },
      { pubkey: PublicKey.SYSTEM_PROGRAM, isSigner: false, isWritable: false },
      { pubkey: PublicKey.TOKEN_2022, isSigner: false, isWritable: false },
    ],
    data: new Uint8Array([1])
  });

  // buy_exact_sol_in
  const [creatorVault] = await findProgramAddress([te('creator-vault'), user.publicKey.toBytes()], PUMP);
  const [globalVolAccum] = await findProgramAddress([te('global_volume_accumulator')], PUMP);
  const [userVolAccum] = await findProgramAddress([te('user_volume_accumulator'), user.publicKey.toBytes()], PUMP);
  const [feeConfig] = await findProgramAddress([te('fee_config'), PUMP.toBytes()], FEE_PROG);
  ok('Buy PDAs derived (creatorVault, globalVolAccum, userVolAccum, feeConfig)');

  const buyData = concatBytes(
    new Uint8Array([102, 6, 61, 18, 1, 218, 235, 234]),
    borshU64(tokenAmount), borshU64(maxSolCost), new Uint8Array([0])
  );
  instructions.push({
    programId: PUMP,
    keys: [
      { pubkey: globalPda, isSigner: false, isWritable: false },
      { pubkey: globalData.feeRecipient, isSigner: false, isWritable: true },
      { pubkey: mint, isSigner: false, isWritable: false },
      { pubkey: bondingCurve, isSigner: false, isWritable: true },
      { pubkey: assocBC, isSigner: false, isWritable: true },
      { pubkey: associatedUser, isSigner: false, isWritable: true },
      { pubkey: user.publicKey, isSigner: true, isWritable: true },
      { pubkey: PublicKey.SYSTEM_PROGRAM, isSigner: false, isWritable: false },
      { pubkey: PublicKey.TOKEN_2022, isSigner: false, isWritable: false },
      { pubkey: creatorVault, isSigner: false, isWritable: true },
      { pubkey: eventAuth, isSigner: false, isWritable: false },
      { pubkey: PUMP, isSigner: false, isWritable: false },
      { pubkey: globalVolAccum, isSigner: false, isWritable: false },
      { pubkey: userVolAccum, isSigner: false, isWritable: true },
      { pubkey: feeConfig, isSigner: false, isWritable: false },
      { pubkey: FEE_PROG, isSigner: false, isWritable: false },
    ],
    data: buyData
  });

  console.log(`   Instructions: ${instructions.length} (computeBudget x2, createV2, extendAccount, createATA, buy_exact_sol_in)`);

  // Build and sign
  const fakeBlockhash = 'GmVwgoZ3VVfBqBux4VSoP23baw2UwHdjKFHLEmdLNbHS';
  const tx = buildLegacyTransaction(user.publicKey, fakeBlockhash, instructions);
  const signed = signSerializedTx(tx, [user, testMint]);
  console.log(`   TX size: ${signed.length} bytes (max 1232)`);
  if (signed.length > 1232) {
    fail('TX size', `${signed.length} exceeds 1232 byte limit`);
  } else {
    ok(`TX built and signed (${signed.length} bytes)`);
  }

  // 5. RPC Simulation
  console.log('\n5. RPC Simulation');
  try {
    const b64Tx = btoa(String.fromCharCode(...signed));
    const simResult = await rpc('simulateTransaction', [b64Tx, {
      encoding: 'base64',
      sigVerify: false,
      commitment: 'confirmed',
      replaceRecentBlockhash: true,
    }], RPC);

    if (simResult.err) {
      const errStr = JSON.stringify(simResult.err);
      const logs = (simResult.logs || []).slice(-10);
      console.log(`   Simulation error: ${errStr}`);
      if (logs.length) console.log('   Last logs:', logs.join('\n             '));

      if (errStr.includes('InsufficientFundsForRent') || errStr.includes('InsufficientFunds') || errStr.includes('AccountNotFound')) {
        ok('Instruction format VALID (failed only due to unfunded test wallet)');
      } else if (errStr.includes('InvalidInstructionData') || errStr.includes('InvalidAccountData')) {
        fail('Instruction format', 'Program rejected instruction data — check discriminators/args');
      } else if (errStr.includes('MissingRequiredSignature')) {
        ok('Instruction format likely valid (signature verification issue with test keys)');
      } else if (errStr.includes('ProgramFailedToComplete') || errStr.includes('custom')) {
        const customCode = errStr.match(/Custom.*?(\d+)/)?.[1];
        console.log(`   Program custom error code: ${customCode || 'unknown'}`);
        if (logs.some(l => l.includes('insufficient') || l.includes('lamport'))) {
          ok('Instruction format VALID (program-level funds check failed as expected)');
        } else {
          fail('Simulation', `Program error — review logs above. May need instruction fixes.`);
        }
      } else {
        console.log(`   ⚠ Unexpected error — review above. Could be format issue or RPC quirk.`);
      }
    } else {
      ok('Simulation PASSED (unexpected for unfunded wallet!)');
    }
  } catch (e) {
    if (e.message.includes('429') || e.message.includes('rate')) {
      console.log('   ⚠ RPC rate limited — simulation skipped. Use a private RPC for testing.');
    } else if (e.message.includes('too large') || e.message.includes('base64')) {
      fail('Simulation', e.message);
    } else {
      console.log(`   ⚠ Simulation RPC error: ${e.message}`);
      console.log('   This is normal for public RPC — use your private Helius/QuickNode URL.');
    }
  }

  // Summary
  console.log(`\n${'═'.repeat(50)}`);
  console.log(`Results: ${passed} passed, ${failed} failed`);
  if (failed === 0) {
    console.log('🎉 All checks passed! Direct deploy should work.');
    console.log('\nTo do a real deploy, use the extension:');
    console.log('  1. SET_DEPLOYER_KEY with your private key + PIN');
    console.log('  2. PUMP_DEPLOY with name, symbol, description, image');
  } else {
    console.log('⚠ Some checks failed — review errors above.');
  }
  console.log();
}

main().catch(e => { console.error('Fatal:', e); process.exit(1); });
