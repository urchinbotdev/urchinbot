/* inspect-tx.js — Fetch and analyze a real pump.fun create+buy transaction */
const crypto = require('crypto');
globalThis.self = globalThis;
globalThis.crypto = { subtle: crypto.webcrypto.subtle, getRandomValues: crypto.randomFillSync.bind(crypto) };
require('./lib/nacl-fast.min.js');
require('./lib/solana-lite.js');

const RPC = process.argv[2] || 'https://api.mainnet-beta.solana.com';
const PUMP = '6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P';

async function main() {
  console.log('Fetching recent Pump program transactions...');
  const sigs = await SolanaLite.rpc('getSignaturesForAddress', [PUMP, { limit: 50 }], RPC);
  const success = sigs.filter(s => s.err === null);
  console.log(`Found ${success.length} successful out of ${sigs.length}`);

  for (const entry of success.slice(0, 10)) {
    const sig = entry.signature;
    const tx = await SolanaLite.rpc('getTransaction', [sig, { encoding: 'json', maxSupportedTransactionVersion: 0 }], RPC);
    if (!tx || !tx.transaction) continue;

    const msg = tx.transaction.message;
    const keys = msg.accountKeys || [];
    const ixs = msg.instructions || [];

    const pumpIxs = ixs.filter(ix => keys[ix.programIdIndex] === PUMP);
    const discList = pumpIxs.map(ix => {
      const data = Buffer.from(ix.data, 'base58');
      return Array.from(data.slice(0, 8)).join(',');
    });

    const hasCreate = discList.some(d => d === '214,144,76,236,95,139,49,180');
    const hasBuy = discList.some(d => d === '102,6,61,18,1,218,235,234');

    if (hasCreate && hasBuy) {
      console.log('\n=== FOUND CREATE+BUY TX ===');
      console.log('Sig:', sig);
      console.log('Accounts:', keys.length);

      for (let i = 0; i < pumpIxs.length; i++) {
        const ix = pumpIxs[i];
        const data = Buffer.from(ix.data, 'base58');
        const disc = Array.from(data.slice(0, 8));
        const discStr = disc.join(',');

        if (discStr === '214,144,76,236,95,139,49,180') {
          console.log('\n--- createV2 ---');
          console.log('  Num accounts:', ix.accounts.length);
          ix.accounts.forEach((idx, j) => console.log(`  [${j}] ${keys[idx]}`));
        }

        if (discStr === '234,102,194,203,150,72,62,229') {
          console.log('\n--- extendAccount ---');
          console.log('  Num accounts:', ix.accounts.length);
        }

        if (discStr === '102,6,61,18,1,218,235,234') {
          console.log('\n--- buy ---');
          console.log('  Num accounts:', ix.accounts.length);
          const amount = data.readBigUInt64LE(8);
          const maxSolCost = data.readBigUInt64LE(16);
          const trackVol = data[24];
          console.log(`  amount: ${amount} tokens`);
          console.log(`  maxSolCost: ${maxSolCost} (${(Number(maxSolCost)/1e9).toFixed(4)} SOL)`);
          console.log(`  trackVolume: ${trackVol}`);
          ix.accounts.forEach((idx, j) => console.log(`  [${j}] ${keys[idx]}`));
        }
      }
      return;
    }
  }
  console.log('No create+buy transaction found in recent 10 successful txs');
  console.log('Trying to find any buy tx...');

  for (const entry of success.slice(0, 10)) {
    const sig = entry.signature;
    const tx = await SolanaLite.rpc('getTransaction', [sig, { encoding: 'json', maxSupportedTransactionVersion: 0 }], RPC);
    if (!tx || !tx.transaction) continue;
    const msg = tx.transaction.message;
    const keys = msg.accountKeys || [];
    const ixs = msg.instructions || [];
    const pumpIxs = ixs.filter(ix => keys[ix.programIdIndex] === PUMP);

    for (const ix of pumpIxs) {
      const data = Buffer.from(ix.data, 'base58');
      const disc = Array.from(data.slice(0, 8)).join(',');
      if (disc === '102,6,61,18,1,218,235,234') {
        console.log('\n=== FOUND BUY TX ===');
        console.log('Sig:', sig);
        const amount = data.readBigUInt64LE(8);
        const maxSolCost = data.readBigUInt64LE(16);
        console.log(`  amount: ${amount} tokens`);
        console.log(`  maxSolCost: ${maxSolCost} (${(Number(maxSolCost)/1e9).toFixed(4)} SOL)`);
        console.log(`  Num accounts: ${ix.accounts.length}`);
        ix.accounts.forEach((idx, j) => console.log(`  [${j}] ${keys[idx]}`));
        return;
      }
    }
  }
  console.log('No buy tx found either');
}

main().catch(e => console.error('Error:', e.message));
